# AUDITORIA DE REGRESSÃO FINAL — RC2

**Livro:** *PYTHON DO ZERO — Do primeiro raciocínio à Central Horizonte 2.0*  
**Autor:** Ronaldo Lavestein  
**Coleção:** Mundo bit Byte  
**Release avaliado:** RC2  
**Data:** 15 de setembro de 2026  
**Regra desta passagem:** nenhum arquivo do release candidate foi alterado.

## 1. Resultado executivo

Os três bloqueadores da auditoria anterior foram corrigidos e passaram nos retestes. Não foi encontrada nova falha de classe A. O PDF RC2, os códigos, as suítes, a Central Horizonte 2.0 e o fluxo público estão funcionalmente aptos.

Dos 12 achados anteriores, **11 estão corrigidos** e **1 está parcialmente corrigido**. O achado B-05 foi resolvido no PDF comercial, que passou de 85 para 84 páginas, mas permanece no DOCX: ao renderizá-lo neste ambiente, a referência “SQLite INSERT” ainda ocupa sozinha a página 46, produzindo 85 páginas.

Também foi comprovada uma nova pendência operacional de classe B: em um ZIP recém-extraído, o comando documentado `python scripts/migrar_v12_v20.py` falha porque a base `central-horizonte-v1.2/dados/horizonte.db` não acompanha o pacote e o README 2.0 não instrui o leitor a inicializar primeiro o checkpoint 1.2. A migração funciona e preserva os dados quando essa base é preparada. Portanto, a correção mínima é documental.

O ZIP público é byte a byte idêntico ao ZIP RC2 anexado: ambos têm 255.630 bytes e SHA-256 `a296c002c14a9692c34c1ff75d54921219730bbf893a4fda74a10b71d6ab2ee4`.

## 2. Estado dos 12 achados anteriores

| ID | Estado atual | Verificação independente no RC2 | Correção mínima ainda necessária |
|---|---|---|---|
| **A-01** | **CORRIGIDO** | O trecho do cap. 18, agora na p. 64, converte `equipamento_id` e `prioridade` com `int(...)`. Executado contra o serviço real 1.0, cadastrou `NB-07`, prioridade `1`, estado `aberto`. | Nenhuma. |
| **A-02** | **CORRIGIDO** | O trecho do cap. 19, p. 68, contém os imports de `Repositorio` e `ServicoCentral`. O bloco executou 1/1 teste; a saída impressa agora cita os testes reais `test_fluxo_atendimento` e `test_prioridade_invalida`. | Nenhuma. |
| **A-03** | **CORRIGIDO** | Em `v2.0/app.py`, `cadastrar_pessoa()` captura `novo_id`, mostra confirmação e preenche `emp_pessoa_id`. O callback real foi exercitado com repositório SQLite: pessoa ID 1 e empréstimo de Ana para NB-07 foram persistidos. | Nenhuma. |
| **B-01** | **CORRIGIDO** | Livro, README raiz e os 13 READMEs indicam Python 3.10 ou superior. Todos os 77 arquivos `.py` compilaram em Python 3.12.14. | Nenhuma. |
| **B-02** | **CORRIGIDO** | O checkpoint 0.8 contém base fictícia migrada. Em extração limpa, `python central.py` exibiu NB-07 com 13 dias, PC-12 concluído, exportou 2 linhas e terminou sem erro de FK. | Nenhuma. |
| **B-03** | **CORRIGIDO** | `ServicoCentral.devolver()` compara devolução e retirada. A suíte 2.0 contém e aprova `test_devolucao_nao_pode_anteceder_retirada`; a data inválida é rejeitada e não é persistida. | Nenhuma. |
| **B-04** | **CORRIGIDO** | A narrativa da p. 68 agora corresponde ao código: nome, tamanho e SHA-256 no manifesto; data no nome; hash conferido na restauração; contagens no roteiro. Backup, restauração, hash e contagens passaram. | Nenhuma. |
| **B-05** | **PARCIALMENTE CORRIGIDO** | No PDF, as três referências ficaram juntas na p. 45 e o cap. 13 começa na p. 46. No DOCX renderizado, a referência “SQLite INSERT” continua isolada na p. 46; o cap. 13 começa na p. 47. O PDF tem 84 páginas e o DOCX renderizado tem 85. | Aplicar ao DOCX a mesma correção local de quebra/espaçamento já presente no PDF e renderizar novamente as páginas 44–47. Não alterar o conteúdo. |
| **B-06** | **CORRIGIDO** | As quatro marcas de Markdown foram substituídas por negrito editorial real. A única ocorrência `**` remanescente no DOCX é `**kwargs`, sintaxe Python legítima. | Nenhuma. |
| **C-01** | **CORRIGIDO** | O parágrafo “Há duas perguntas diferentes...” está com estilo `Normal`; inspeção das pp. 19–21 não mostrou regressão de hierarquia ou paginação. | Nenhuma. |
| **C-02** | **CORRIGIDO** | “Movimento A”, “Movimento B” e “Movimento C” têm a mesma hierarquia de subtítulo. As pp. 53–55 permanecem legíveis e equilibradas. | Nenhuma. |
| **C-03** | **CORRIGIDO** | O PDF contém 59 anotações de link, 50 URLs únicas, distribuídas pelas referências técnicas e material de apoio. Os endereços são `http`/`https` e o link de apoio é o oficial. | Nenhuma. |

**Contagem:** 11 corrigidos; 1 parcialmente corrigido; 0 não corrigidos; 0 regressões introduzidas nos 12 itens anteriores.

## 3. Testes repetidos e resultados

### Código, Python e checkpoints

| Teste | Resultado | Evidência observada |
|---|---|---|
| Descoberta dos checkpoints | **PASS** | 13 pastas: 0.1 a 1.2 e 2.0. |
| Compilação Python | **PASS** | 77/77 arquivos `.py` compilados em Python 3.12.14. |
| Fluxos 0.1–0.7 | **PASS** | Primeira execução, entrada, menu, coleções, módulos, diagnóstico, CRUD e persistência. |
| Checkpoint 0.8 isolado | **PASS** | NB-07 aberto = 13 dias; PC-12 concluído; CSV = 2 registros; `foreign_key_check` vazio. |
| Checkpoints 0.9–1.2 | **PASS** | Imports, serviços, repositórios e smokes de CLI aprovados. |
| Trecho Tkinter do cap. 18 | **PASS** | Resultado real: `('NB-07', 1, 'aberto')`. |
| Trecho de teste do cap. 19 | **PASS** | 1 teste executado, 0 falhas e 0 erros. |
| `unittest` 1.1 | **PASS** | 2/2: `test_fluxo_atendimento`, `test_prioridade_invalida`. |
| `unittest` 1.2 | **PASS** | 2/2: mesmos contratos preservados. |
| `unittest` 2.0 | **PASS** | 3/3: conflito/devolução, devolução cronologicamente inválida e preservação do suporte. |
| GUI 2.0 — cadastro e empréstimo | **PASS funcional** | Callback de cadastro preencheu ID `1`, mostrou confirmação e o mesmo serviço persistiu `Ana / NB-07 / 2026-09-01 / 2026-09-08`. |
| Devolução anterior à retirada | **PASS** | Rejeitada com `ValueError`; teste automático específico aprovado. |
| Backup/restauração 1.1 | **PASS** | Hash origem = backup = restaurado; contagens de equipamento e atendimento iguais; manifesto válido. |
| Migração 0.7→0.8 | **PASS** | 2 atendimentos antes/depois, 2 equipamentos, `foreign_key_check` vazio. |
| Migração 1.2→2.0 com base preparada | **PASS** | 1 equipamento e 1 atendimento preservados; tabelas `pessoa` e `emprestimo` criadas; `foreign_key_check` vazio. |
| Migração 1.2→2.0 pelo comando do README, em extração limpa | **FAIL documental/operacional** | `FileNotFoundError: Base 1.2 não encontrada`; o pacote traz apenas `.gitkeep` em `v1.2/dados`. |
| Git do checkpoint 1.2 | **PASS** | `init`, `add`, `commit`, `status`, `diff`, `log`; banco ignorado conforme `.gitignore`. |

### Integridade do ZIP

- ZIP RC2: **PASS**, sem erro de compressão.
- 212 entradas: 175 arquivos e 37 diretórios.
- 13 checkpoints presentes.
- Nenhum caminho absoluto ou com `..`.
- Nenhum link simbólico ou arquivo criptografado.
- Nenhum cache, `.pyc`, arquivo temporário, manuscrito ou relatório interno no ZIP distribuído.
- As ocorrências de `relatorios.py` são módulos legítimos das versões 0.5 e 0.6, não documentos de bastidor.
- ZIP público e ZIP anexado: **idênticos byte a byte**.

### PDF e DOCX

- PDF RC2: 84 páginas, formato Letter, sem criptografia, fontes incorporadas e metadados de título/autor presentes.
- DOCX: sem comentários, alterações controladas ou macros detectadas.
- O texto normalizado do PDF e do DOCX renderizado contém os mesmos 15.025 tokens, sem diferença textual detectada.
- A paginação não é equivalente: PDF = 84 páginas; renderização do DOCX neste ambiente = 85 páginas, devido à referência isolada na p. 46.

## 4. Regressões

### Regressões introduzidas pelas correções

**Nenhuma regressão funcional, técnica, pedagógica ou visual material foi comprovada.**

As páginas corrigidas e suas vizinhas foram inspecionadas em resolução integral: 8–10, 19–21, 44–47, 50–55, 63–65, 67–70 e 74–80. Também foi feita uma passada visual geral pelas 84 páginas. Não foram observados novos títulos órfãos, estouro de código/tabela, corte de figuras, perda de rodapé, numeração quebrada ou aparência de rascunho no PDF.

### Correção anterior incompleta

**B-05 permanece apenas no DOCX.** Isso não é uma nova regressão do PDF: o PDF comercial está corrigido. É uma divergência entre os dois artefatos do RC2 e contraria o relatório MbB, que afirma que o DOCX renderizado também teria 84 páginas.

### Novo achado não bloqueador — RC2-N1

- **Classificação:** B — importante antes de publicar.
- **Recurso:** `checkpoints/central-horizonte-v2.0/README.md` e `scripts/migrar_v12_v20.py`.
- **Problema:** o README manda executar a migração 1.2→2.0, mas o ZIP não inclui `v1.2/dados/horizonte.db` e não instrui como criá-lo.
- **Evidência:** em uma extração nova, o comando exato encerrou com status 1 e `FileNotFoundError`. Depois de inicializar uma base 1.2 com um equipamento e um atendimento, o mesmo script passou e preservou ambos.
- **Impacto:** um iniciante que tenta a atividade diretamente recebe traceback, embora o código da migração esteja correto.
- **Correção mínima:** acrescentar ao README 2.0 uma etapa explícita para abrir/executar primeiro o checkpoint 1.2, gerar `dados/horizonte.db`, trabalhar sobre uma cópia e só então executar o script. Não é necessário alterar schema, código ou arquitetura.
- **Risco da correção:** praticamente nulo; validar o comando novamente em uma extração limpa.

## 5. Auditoria do fluxo público

Fluxo validado:

1. [Página oficial](https://www.mundobitbyte.com.br/python-do-zero/) — HTTP 200, título correto, linguagem pública, mapa com 13 checkpoints e botão visível.
2. Botão **Baixar material complementar** — link habilitado e visível; a ação de download foi concluída pelo navegador.
3. [Download direto](https://www.mundobitbyte.com.br/python-do-zero/download/Python_do_Zero_Material_de_Apoio_v1.0.zip) — HTTP 200, `Content-Type: application/x-zip-compressed`, nome correto e 255.630 bytes.
4. ZIP baixado — íntegro, aberto e comparado ao anexo.
5. Checkpoint 0.8 do ZIP baixado — executado isoladamente com sucesso.

Comparação criptográfica:

| Artefato | Tamanho | SHA-256 |
|---|---:|---|
| ZIP RC2 anexado | 255.630 bytes | `a296c002c14a9692c34c1ff75d54921219730bbf893a4fda74a10b71d6ab2ee4` |
| ZIP público baixado | 255.630 bytes | `a296c002c14a9692c34c1ff75d54921219730bbf893a4fda74a10b71d6ab2ee4` |

No repositório público `mundobitbyte/site`, o HTML da página aponta exatamente para `download/Python_do_Zero_Material_de_Apoio_v1.0.zip`. O commit público mais recente relacionado ao pacote é [`39189ccd7cf2d1ca9d43beb8d9cc3f67f70e9a1b`](https://github.com/mundobitbyte/site/commit/39189ccd7cf2d1ca9d43beb8d9cc3f67f70e9a1b), com a mensagem “Zip atualizado do livro”. O CSS possui regras responsivas explícitas abaixo de 720 px; não foi encontrado texto de bastidor na página.

## 6. Novos bloqueadores comprovados

**Nenhum.**

O problema de migração RC2-N1 é real, mas não invalida o checkpoint 2.0 nem a migração em si; exige somente explicitar um pré-requisito no README. A divergência B-05 está restrita ao DOCX, pois o PDF destinado ao comprador já está corrigido.

## 7. Checklist de liberação comercial

| Critério | Estado |
|---|---|
| A-01, A-02 e A-03 corrigidos e retestados | **OK** |
| Nenhum novo bloqueador técnico ou funcional | **OK** |
| 13 checkpoints presentes | **OK** |
| Compilação dos 77 arquivos Python | **OK** |
| Suítes 1.1, 1.2 e 2.0 | **OK** |
| Checkpoint 0.8 independente | **OK** |
| Regras de empréstimo e devolução | **OK** |
| Backup e restauração | **OK** |
| Migrações preservam dados quando os pré-requisitos existem | **OK** |
| README 2.0 explica como preparar a origem da migração | **PENDENTE — correção pontual** |
| PDF comercial sem a página órfã | **OK** |
| DOCX correspondente sem a página órfã | **PENDENTE — correção pontual** |
| Páginas alteradas e adjacentes sem regressão | **OK no PDF** |
| Passada visual geral pelas 84 páginas | **OK** |
| URLs do PDF clicáveis | **OK** |
| Página pública e botão de download | **OK** |
| ZIP público igual ao ZIP RC2 | **OK** |
| ZIP sem lixo ou arquivos de bastidor | **OK** |

### Correções mínimas antes de encerrar o release

1. Ajustar somente a quebra/espaçamento do DOCX para manter “SQLite INSERT” na página anterior, igual ao PDF; rerenderizar e conferir as páginas 44–47.
2. Acrescentar ao README 2.0 a etapa explícita de criação/preparação da base 1.2 antes de `python scripts/migrar_v12_v20.py`; retestar em ZIP recém-extraído.

Nenhuma reescrita ampla, alteração dos 22 capítulos ou mudança na arquitetura pedagógica é necessária.

## 8. Limitações desta revalidação

- O ambiente disponível possui Python 3.12.14; a execução exata em 3.10 e 3.13.5 não foi repetida. A compatibilidade mínima 3.10 foi verificada por requisito sintático e todos os códigos passaram em 3.12.14.
- Não havia servidor X nem `xvfb-run`. A janela Tkinter completa não pôde ser construída visualmente; seus imports, compilação, callbacks, serviço, repositório e fluxo cadastro de pessoa→ID→empréstimo foram exercitados sem display.
- A página pública foi inspecionada ao vivo em viewport desktop de 1363×936. O CSS responsivo foi conferido, mas não houve emulação visual de dispositivo móvel nesta passagem.
- O QR Code não foi escaneado com câmera/decoder nesta passagem; o endereço impresso, o hyperlink do PDF e a página de destino foram confirmados.

## 9. Veredito final

**APROVADO COM CORREÇÕES PONTUAIS**

