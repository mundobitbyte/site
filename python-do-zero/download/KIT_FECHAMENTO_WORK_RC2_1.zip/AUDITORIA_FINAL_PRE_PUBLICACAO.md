# AUDITORIA FINAL INDEPENDENTE DE PRÉ-PUBLICAÇÃO

**Livro:** *PYTHON DO ZERO — Do primeiro raciocínio à Central Horizonte 2.0*  
**Autor:** Ronaldo Lavestein  
**Coleção:** Mundo bit Byte  
**Data da auditoria:** 15 de setembro de 2026  
**Escopo:** PDF release candidate, DOCX correspondente, `Python_do_Zero_Material_de_Apoio_v1.0.zip`, página pública, download e repositório público  
**Regra desta passagem:** nenhum arquivo do release candidate foi alterado.

## 1. Veredito executivo

**NÃO PUBLICAR AINDA.**

O release candidate está próximo de um produto comercial concluído: a arquitetura pedagógica é coerente, os 22 capítulos formam uma progressão reconhecível, o projeto Central Horizonte permanece como fio condutor, a diagramação é majoritariamente limpa, os 13 checkpoints estão presentes, o ZIP público é íntegro e idêntico ao anexo, as migrações preservam dados nos cenários executados, as suítes incluídas passam e a Central Horizonte 2.0 funciona pela CLI.

Ainda assim, três falhas justificam reprovar esta versão antes do lançamento:

1. o código de GUI impresso no capítulo 18 passa strings do Tkinter a um serviço que exige inteiros e, portanto, não produz a saída prometida;
2. o teste impresso no capítulo 19 omite dois imports indispensáveis e a saída esperada não corresponde à suíte entregue;
3. a GUI da Central Horizonte 2.0 cadastra uma pessoa, mas não mostra o ID criado nem oferece uma lista de pessoas, embora exija esse ID para retirar um equipamento. Um iniciante que usa somente a GUI não consegue concluir o fluxo prometido de forma determinística.

São correções pequenas e localizadas. Não há justificativa para reescrever capítulos, mudar a arquitetura, alterar a voz editorial ou substituir a Central Horizonte.

## 2. Quantidade total de achados A, B e C

| Classificação | Quantidade | Decisão |
|---|---:|---|
| A — Bloqueador de publicação | 3 | corrigir e retestar antes de publicar |
| B — Importante antes de publicar | 6 | corrigir no mesmo ciclo de fechamento |
| C — Opcional / polimento | 3 | não deve, isoladamente, atrasar a publicação |
| **Total** | **12** | — |

## 3. Bloqueadores de publicação

### A-01 — Trecho de GUI do capítulo 18 falha com os valores reais do Tkinter

- **Arquivo ou recurso:** PDF e DOCX.
- **Capítulo:** 18 — “Uma tela não basta”.
- **Página:** 66.
- **Elemento ou trecho exato:** `servico.abrir_atendimento(equipamento_id.get(), descricao.get(), prioridade.get())`, sob “Trecho inserido na tela de atendimentos”.
- **Classificação:** A — Bloqueador de publicação.
- **Problema:** `StringVar.get()` devolve texto. O serviço de referência exige prioridade inteira em `(1, 2, 3)` e o repositório trabalha com ID numérico. O trecho impresso não converte `equipamento_id` nem `prioridade` para `int`.
- **Evidência:** executando o mesmo contrato do checkpoint 1.0 com os valores textuais equivalentes, `abrir_atendimento(str(eid), "Não liga", "1")`, foi obtido `ValueError: Prioridade deve estar entre 1 e 3.` O próprio checkpoint correto usa `int(self.equipamento_id.get())` e `int(self.prioridade.get())`.
- **Impacto para o leitor:** quem digitar o trecho como mostrado não obtém “Treeview atualizada: NB-07 | 1 | aberto”. A primeira tentativa de salvar falha justamente no capítulo que promete integrar formulário, serviço, banco e lista.
- **Correção mínima recomendada:** alterar somente a chamada para `int(equipamento_id.get())` e `int(prioridade.get())`; se o trecho pretende ser operacional, conservar também o tratamento de `ValueError` já usado no checkpoint.
- **Risco de alterar algo que já está funcionando:** baixo. A correção alinha o livro ao checkpoint funcional; retestar prioridade inválida e campo vazio para garantir que a mensagem de erro continue amigável.

### A-02 — Teste impresso no capítulo 19 não executa e a saída esperada não pertence à suíte entregue

- **Arquivo ou recurso:** PDF, DOCX e checkpoint `central-horizonte-v1.1`.
- **Capítulo:** 19 — “Proteger e provar”.
- **Página:** 70.
- **Elemento ou trecho exato:** bloco “Trecho de `tests/test_central.py`” e caixa “Saída esperada”.
- **Classificação:** A — Bloqueador de publicação.
- **Problema:** o bloco importa `tempfile`, `unittest` e `Path`, mas usa `Repositorio` e `ServicoCentral` sem importá-los. Além disso, a saída prometida cita `test_persistencia`; a suíte realmente entregue contém `test_fluxo_atendimento` e `test_prioridade_invalida`.
- **Evidência:** o bloco, executado como mostrado, falhou em `setUp` com `NameError: name 'Repositorio' is not defined`. No checkpoint 1.1, `python -m unittest -v` executou 2 testes com sucesso: `test_fluxo_atendimento` e `test_prioridade_invalida`; não existe `test_persistencia`.
- **Impacto para o leitor:** o exemplo central do capítulo de testes não chega à asserção e a comparação visual com a “saída esperada” nunca pode coincidir. Isso destrói a prova pedagógica proposta naquele ponto.
- **Correção mínima recomendada:** inserir `from horizonte.repositorio import Repositorio` e `from horizonte.servicos import ServicoCentral`; substituir `test_persistencia` por `test_fluxo_atendimento` na saída esperada, ou então entregar de fato o teste de persistência com esse nome. A menor mudança é alinhar texto e saída ao arquivo já funcional.
- **Risco de alterar algo que já está funcionando:** baixo. Não modificar a suíte além do necessário; rerodar `python -m unittest -v` e copiar os nomes reais para a prova.

### A-03 — A GUI 2.0 não fornece o ID da pessoa necessário para fazer o empréstimo

- **Arquivo ou recurso:** ZIP, `checkpoints/central-horizonte-v2.0/app.py`; promessa editorial no capítulo 21.
- **Capítulo:** 21 — “Central Horizonte 2.0”.
- **Páginas:** 77–79, especialmente “CLI e GUI executam o mesmo fluxo” e “confira CLI/GUI”.
- **Elemento ou trecho exato:** `cadastrar_pessoa()` chama `self.servico.cadastrar_pessoa(...)`, descarta o retorno e apenas limpa o campo; o formulário seguinte exige entrada manual em “ID pessoa”. Não há tabela ou seletor de pessoas.
- **Classificação:** A — Bloqueador de publicação.
- **Problema:** a GUI cria a pessoa, mas não revela seu ID. A tabela de empréstimos só mostra pessoas depois que já existe um empréstimo. Assim, um usuário iniciante operando somente a GUI não tem fonte visível para o valor exigido em “ID pessoa”.
- **Evidência:** inspeção de `app.py`, linhas 84–118 e 172–188. O serviço retorna o novo ID, mas a GUI não o armazena nem o apresenta. O fluxo pela CLI funciona porque ela imprime `Pessoa #<id>`; a GUI não oferece equivalente.
- **Impacto para o leitor:** o fluxo comercialmente mais visível da “Central Horizonte 2.0” fica bloqueado ou depende de adivinhação/consulta externa ao banco. Contradiz a promessa de equivalência entre CLI e GUI e pode gerar suporte e avaliação negativa.
- **Correção mínima recomendada:** capturar o retorno (`novo_id = ...`) e mostrar confirmação explícita com o ID, idealmente preenchendo `emp_pessoa_id` automaticamente. Uma lista/combobox seria melhor experiência, mas não é necessária para remover o bloqueio.
- **Risco de alterar algo que já está funcionando:** baixo a moderado. Não mexer no domínio nem no schema; testar cadastro de duas pessoas e confirmar que o ID exibido/preenchido corresponde a cada registro.

## 4. Itens importantes antes de publicar

### B-01 — “Python 3” é amplo demais para checkpoints que exigem Python 3.10+

- **Arquivo ou recurso:** `LEIA-ME.md` do ZIP, READMEs dos checkpoints e orientação inicial do livro.
- **Capítulo:** 2 e material de apoio; repercute nos capítulos 16–21.
- **Página:** 2 informa “validado em Python 3.13.5”; os requisitos do ZIP dizem apenas “Python 3”.
- **Elemento ou trecho exato:** `id: int | None` e `devolvido_em: str | None` em `modelos.py` das versões 0.9 a 2.0.
- **Classificação:** B — Importante antes de publicar.
- **Problema:** a união de tipos com `|` em anotações depende de Python 3.10 ou superior. “Python 3” inclui versões anteriores ainda encontradas em computadores e ambientes escolares.
- **Evidência:** ocorrências confirmadas em v0.9, v1.0, v1.1, v1.2 e v2.0. A auditoria foi executada em Python 3.12.14; o livro registra validação editorial em 3.13.5.
- **Impacto para o leitor:** alguém com Python 3.8 ou 3.9 pode falhar ao importar os checkpoints avançados mesmo tendo seguido literalmente o requisito informado.
- **Correção mínima recomendada:** trocar “Python 3” por “Python 3.10 ou superior; edição validada em Python 3.13.5” no README raiz e nos pontos de instalação mais visíveis.
- **Risco de alterar algo que já está funcionando:** praticamente nulo; é correção de requisito, não de código.

### B-02 — O checkpoint 0.8 não é independente, ao contrário do que o livro e o pacote afirmam

- **Arquivo ou recurso:** página 83 do livro, `LEIA-ME.md` do ZIP e checkpoint `central-horizonte-v0.8`.
- **Capítulo:** 15 e mapa final dos checkpoints.
- **Páginas:** 52, 56 e 83.
- **Elemento ou trecho exato:** “Cada pasta do pacote é independente” e “treze fotografias funcionais”; ao executar v0.8 limpo, `central.py` exige primeiro a migração de uma cópia da base 0.7.
- **Classificação:** B — Importante antes de publicar.
- **Problema:** o checkpoint 0.8 não contém uma base pronta e não inicia sozinho. Ele depende do checkpoint 0.7 e do procedimento de migração.
- **Evidência:** `python central.py` em uma cópia intacta de v0.8 terminou apenas com “Execute primeiro `scripts/migrar_v07_v08.py` sobre uma cópia da base 0.7.” Depois da migração, funcionou, exportou CSV e carregou JSON.
- **Impacto para o leitor:** quem abre a pasta “independente” indicada no mapa encontra uma barreira não anunciada naquele ponto; isso é especialmente prejudicial para retomada de estudos, uma das finalidades declaradas dos checkpoints.
- **Correção mínima recomendada:** ou incluir em v0.8 uma base fictícia já migrada/reset reproduzível, mantendo o script de migração para a atividade, ou substituir a afirmação absoluta por uma exceção explícita: “todos são executáveis isoladamente, exceto o 0.8, que demonstra a migração a partir de uma cópia do 0.7”. A segunda opção é a menor.
- **Risco de alterar algo que já está funcionando:** baixo se for apenas texto; moderado se uma base pronta for adicionada, pois será preciso garantir que não neutralize o exercício de migração.

### B-03 — A devolução aceita data anterior à retirada

- **Arquivo ou recurso:** `checkpoints/central-horizonte-v2.0/horizonte/servicos.py` e CLI 2.0.
- **Capítulo:** 21.
- **Páginas:** 76–79.
- **Elemento ou trecho exato:** `ServicoCentral.devolver`, linhas 78–82, valida apenas o formato ISO e o estado aberto.
- **Classificação:** B — Importante antes de publicar.
- **Problema:** não existe regra que compare `devolvido_em` com `retirado_em`.
- **Evidência:** foi criado empréstimo com retirada `2026-09-10` e devolvido pela camada de serviço em `2026-09-01`; o registro persistido ficou cronologicamente impossível e a comparação confirmou `devolvido_em < retirado_em`.
- **Impacto para o leitor:** a versão final aceita dado inválido por uma interface pública do domínio. Pode corromper relatórios futuros e ensina validação assimétrica: a previsão é comparada com a retirada, mas a devolução não.
- **Correção mínima recomendada:** antes do `UPDATE`, recuperar o empréstimo aberto, converter as duas datas e rejeitar devolução anterior à retirada com `ValueError`; acrescentar um teste unitário específico.
- **Risco de alterar algo que já está funcionando:** moderado. Preservar a mensagem para “inexistente ou já devolvido” e testar devolução igual/posterior à retirada.

### B-04 — A descrição do backup não corresponde à implementação entregue

- **Arquivo ou recurso:** PDF/DOCX e `central-horizonte-v1.1/horizonte/backup.py`.
- **Capítulo:** 19.
- **Página:** 70.
- **Elemento ou trecho exato:** “registra nome, tamanho, data e SHA-256 em manifesto” e “compara contagens”.
- **Classificação:** B — Importante antes de publicar.
- **Problema:** o manifesto contém `arquivo`, `tamanho` e `sha256`, sem campo `data`. A restauração abre/inicializa as tabelas e compara hash, mas a função não compara contagens.
- **Evidência:** inspeção de `backup.py`, linhas 19–56. O teste externo de auditoria confirmou que a cópia restaurada abre, preserva contagem e tem hash igual; a divergência é entre a explicação e o código, não uma perda observada de dados.
- **Impacto para o leitor:** o aluno procura evidências que o programa não produz e pode acreditar que uma verificação de contagens foi automatizada quando, na implementação, ela depende do roteiro/manual.
- **Correção mínima recomendada:** alinhar duas frases ao comportamento real: “nome, tamanho e SHA-256; a data está no nome do arquivo” e “abre a restauração e compara hash”. Se a intenção editorial é manter a promessa atual, implementar campo de data e comparação de contagens e cobri-los por teste.
- **Risco de alterar algo que já está funcionando:** mínimo para correção textual; moderado para ampliar código e manifesto.

### B-05 — Página 46 parece sobra de paginação editorial

- **Arquivo ou recurso:** PDF e renderização do DOCX.
- **Capítulo:** 12 — “Amanhã os dados ainda precisam existir”.
- **Página:** 46.
- **Elemento ou trecho exato:** somente o último item das referências técnicas, “SQLite INSERT”, aparece no topo; quase toda a página fica vazia.
- **Classificação:** B — Importante antes de publicar.
- **Problema:** uma referência isolada foi empurrada para uma página própria. Não é uma página divisória nem um encerramento de seção planejado.
- **Evidência:** inspeção visual em resolução integral; foi a página de conteúdo com menor ocupação visual de todo o PDF. O mesmo ocorre no PDF renderizado do DOCX.
- **Impacto para o leitor:** transmite aparência de prova não fechada e desperdiça uma página física, reduzindo percepção de acabamento comercial.
- **Correção mínima recomendada:** manter o bloco “Referências técnicas” junto, reduzir apenas o espaçamento anterior ou ajustar a quebra para que o item volte à página 45. Não recompor o capítulo inteiro.
- **Risco de alterar algo que já está funcionando:** moderado, pois uma pequena mudança pode repaginar páginas posteriores. Aplicar quebra/localização controlada e rerenderizar as 85 páginas.

### B-06 — Quatro marcas de Markdown ficaram visíveis no miolo

- **Arquivo ou recurso:** PDF e DOCX.
- **Capítulos:** 13, 14, 18 e 21.
- **Páginas:** 48, 52, 66 e 76.
- **Elemento ou trecho exato:** `**não fecha automaticamente**`, `**cópia**`, `**as duas áreas existem de verdade**` e `**ao lado**`.
- **Classificação:** B — Importante antes de publicar.
- **Problema:** os asteriscos de ênfase foram impressos literalmente em quatro trechos de prosa.
- **Evidência:** inspeção visual e busca estrutural no XML do DOCX. `**kwargs` também existe, mas é código Python legítimo e não deve ser alterado.
- **Impacto para o leitor:** é um sinal inequívoco de conversão editorial incompleta e aparência de rascunho.
- **Correção mínima recomendada:** remover somente os pares de asteriscos e aplicar negrito real às quatro expressões, preservando `**kwargs`.
- **Risco de alterar algo que já está funcionando:** baixo; conferir as quatro páginas após renderização para evitar mudança de linha indesejada.

## 5. Polimentos opcionais

### C-01 — Um parágrafo inteiro foi classificado como Heading 2

- **Arquivo ou recurso:** PDF e DOCX.
- **Capítulo:** 5 — “Nem todo chamado tem a mesma prioridade”.
- **Página:** 20.
- **Elemento ou trecho exato:** parágrafo iniciado por “Há duas perguntas diferentes e vale separá-las.”
- **Classificação:** C — Opcional / polimento.
- **Problema:** o parágrafo aparece inteiro em cor/tamanho de subtítulo e consta estruturalmente como `Heading 2`.
- **Evidência:** inspeção visual e leitura do estilo no DOCX.
- **Impacto para o leitor:** interrompe a hierarquia, mas o conteúdo continua legível e correto.
- **Correção mínima recomendada:** aplicar estilo de corpo (`Normal`) ao parágrafo.
- **Risco de alterar algo que já está funcionando:** baixo; pode mudar a paginação local, então revisar páginas 19–21.

### C-02 — “Movimento B” não tem a mesma hierarquia visual de A e C

- **Arquivo ou recurso:** PDF e DOCX.
- **Capítulo:** 15 — “Dados precisam responder perguntas”.
- **Páginas:** 54–55.
- **Elemento ou trecho exato:** “Movimento B - tempo como dado” está no início de um parágrafo normal; “Movimento A” e “Movimento C” são subtítulos.
- **Classificação:** C — Opcional / polimento.
- **Problema:** uma sequência explicitamente dividida em três movimentos apresenta hierarquia inconsistente.
- **Evidência:** inspeção visual e estilos do DOCX.
- **Impacto para o leitor:** pequena perda de escaneabilidade; não impede a atividade.
- **Correção mínima recomendada:** separar “Movimento B — tempo como dado” como Heading 2, sem alterar o texto restante.
- **Risco de alterar algo que já está funcionando:** moderado por possível repaginação em páginas 54–56.

### C-03 — Referências técnicas são texto, não hyperlinks no PDF digital

- **Arquivo ou recurso:** PDF.
- **Capítulo:** todos os capítulos com referências técnicas; referências gerais.
- **Páginas:** 8–85.
- **Elemento ou trecho exato:** 49 URLs técnicas. Apenas os links do material de apoio nas páginas 4 e 83 possuem anotações clicáveis.
- **Classificação:** C — Opcional / polimento.
- **Problema:** as URLs são legíveis, mas não clicáveis no PDF.
- **Evidência:** inspeção das anotações do PDF encontrou links clicáveis somente para a página do material de apoio.
- **Impacto para o leitor:** exige copiar/digitar endereços longos, sobretudo em celular. Não afeta a edição impressa.
- **Correção mínima recomendada:** converter automaticamente URLs explícitas em hyperlinks, sem mudar aparência.
- **Risco de alterar algo que já está funcionando:** baixo; validar links e acessibilidade após exportar.

## 6. Auditoria técnica e resultados dos testes executados

### Ambiente e integridade

- Auditoria executada em Linux x86_64, Python 3.12.14 e SQLite da biblioteca padrão desse interpretador.
- PDF: 85 páginas Letter, sem criptografia, fontes incorporadas e metadados de título/autor presentes.
- DOCX: 85 páginas após renderização pelo LibreOffice; sem comentários, alterações controladas, VBA ou objetos incorporados suspeitos.
- Texto normalizado do PDF entregue e do PDF renderizado a partir do DOCX: SHA-256 idêntico, `15cc6186efdbd5de74e9bc8a8157b393c33da6552c2eb1a6a794bf330d1a753e`.
- ZIP de apoio anexo: 235.164 bytes, SHA-256 `539a06314452a68294e201e3a34c5bfdda09e31d35c65196a3aa6c1b6db80634`.

### Código impresso no livro

- Foram extraídos 22 blocos centrais, um por capítulo.
- Dezenove blocos são sintaticamente válidos quando tratados como Python: capítulos 2–19 e o scaffold do capítulo 22.
- Três blocos não são Python por intenção editorial: algoritmo em linguagem natural (cap. 1), comandos Git (cap. 20) e bloco misto SQL/Python (cap. 21).
- A compilação sintática não detecta os defeitos A-01 e A-02; ambos foram reproduzidos em execução/contexto real.
- Resultados fixos conferidos: cálculo de 13 dias entre 2026-09-01 e 2026-09-14, transições de prioridade/estado, consultas e contagens das massas fictícias.

### Checkpoints e testes dinâmicos

O harness independente registrou **30 PASS, 1 FAIL e 1 SKIP**. O FAIL é a independência do v0.8; o SKIP é a construção visual das janelas Tkinter por ausência de display virtual. Os imports e a compilação das GUIs passaram.

| Área | Resultado |
|---|---|
| descoberta dos 13 diretórios | PASS |
| compilação de todos os 77 arquivos `.py` | PASS |
| v0.1 primeira execução | PASS |
| v0.2 entrada válida | PASS |
| v0.2 `ValueError` didático documentado | PASS |
| v0.3 menu contínuo e opção inválida | PASS |
| v0.4 busca, filtro, listagem e resumo | PASS |
| v0.5 módulos e mesmas consultas | PASS |
| v0.6 erro de conversão tratado | PASS |
| v0.7 reset, CRUD e persistência entre processos | PASS |
| v0.8 execução isolada | **FAIL — exige base 0.7 migrada** |
| migração 0.7 → 0.8, contagens e `foreign_key_check` | PASS |
| CSV e JSON de v0.8 | PASS |
| v0.9/v1.0/v1.1/v1.2, CLI/serviço/repositório | PASS |
| `unittest` v1.1 | PASS — 2/2 |
| `unittest` v1.2 | PASS — 2/2 |
| backup, restauração, hash e contagem externa | PASS |
| Git init/add/commit/status e banco ignorado | PASS |
| migração 1.2 → 2.0 e preservação do suporte | PASS |
| `unittest` v2.0 | PASS — 2/2 |
| empréstimo pela CLI, conflito, atraso e devolução | PASS |
| data inválida e previsão anterior à retirada | PASS — rejeitadas |
| devolução anterior à retirada | **falha exploratória — aceita; B-03** |
| construção visual Tkinter | SKIP — sem `xvfb-run`/display |

### SQLite e persistência

- `PRAGMA foreign_keys = ON` está ativado nas conexões relevantes.
- CRUD v0.7 persistiu alteração após encerramento e reabertura do processo.
- Migração 0.7 → 0.8 preservou 2 atendimentos, criou 2 equipamentos e terminou sem violações de chave estrangeira.
- Migração 1.2 → 2.0 preservou 1 equipamento e 1 atendimento da massa de prova e criou `pessoa` e `emprestimo`.
- Conflito de dois empréstimos abertos foi recusado pela camada de serviço.
- A ausência de devolução é representada por `NULL`/`None`, e a consulta de atrasos deixou de listar o empréstimo após devolução.
- Não foi observada corrupção em backup/restauração; o problema B-04 é de correspondência entre narrativa e implementação.

### Git

- Os comandos do capítulo 20 existem e foram exercitados numa cópia do checkpoint 1.2.
- `git init`, `git add`, `git commit`, `git status`, `git diff`, `git diff --staged` e `git log --oneline` comportaram-se como descrito.
- `dados/horizonte.db` permaneceu ignorado conforme `.gitignore`.

## 7. Auditoria pedagógica capítulo a capítulo

| Cap. | Avaliação como professor e iniciante | Checkpoint / achado |
|---:|---|---|
| 1 | A necessidade nasce das anotações inconsistentes; entrada → processamento → saída e algoritmo aparecem antes da sintaxe. Atividade clara e compatível com absoluto iniciante. | Sem checkpoint, coerente. |
| 2 | A primeira execução tem objetivo observável e separa arquivo, interpretador, terminal e saída. Boa primeira conquista. | 0.1 executado com sucesso. |
| 3 | Variáveis, tipos e `None` surgem porque os registros precisam ser reencontrados. Não há uso essencial anterior ao ensino. | Sem checkpoint, coerente. |
| 4 | `input`, limpeza e conversão são introduzidos na fronteira com o usuário; o erro intencional prepara o capítulo 11 sem escondê-lo. | 0.2 passou nos cenários válido e inválido documentado. |
| 5 | Condições emergem da prioridade; separa validade do valor e regra de decisão. O conteúdo é bom, com defeito de hierarquia C-01. | Sem checkpoint. |
| 6 | `while`, estado e saída do menu respondem à necessidade de continuidade. O iniciante sabe o que digitar e observar. | 0.3 passou. |
| 7 | Lista, dicionário e `for` aparecem quando um único atendimento deixa de bastar. A advertência sobre mutabilidade é oportuna. | Sem checkpoint. |
| 8 | Busca, filtro, normalização e resumo são ensinados como perguntas sobre a coleção, não como sintaxe isolada. | 0.4 passou. |
| 9 | Funções nascem da repetição da regra; contrato, parâmetro e retorno são diferenciados com precisão suficiente. | Sem checkpoint. |
| 10 | A divisão em módulos resolve crescimento do arquivo; `pathlib` é apresentado para retirar dependência da pasta corrente. | 0.5 passou. |
| 11 | Traceback e hipótese/teste transformam erro em evidência. O tratamento chega depois do erro intencional, na ordem pedagógica correta. | 0.6 passou. |
| 12 | SQLite surge por necessidade de sobreviver ao processo. O experimento mínimo antecede a incorporação à Central. | Conceito passou; página 46 tem falha editorial B-05. |
| 13 | CRUD e transação evoluem naturalmente da persistência básica. `with` é explicado sem afirmar que fecha a conexão. | 0.7 passou; marca Markdown B-06 na p. 48. |
| 14 | Normalização de equipamento/atendimento e migração são motivadas pela duplicação. Preservar e provar é enfatizado. | Migração passou; marca Markdown B-06 na p. 52. |
| 15 | SQL de gestão, datas ISO, CSV e JSON seguem perguntas concretas. A sequência A/B/C é útil, embora B tenha hierarquia C-02. | 0.8 funciona após migração; independência contradita em B-02. |
| 16 | Objetos, dataclasses, serviço e repositório surgem da necessidade de separar responsabilidades. É o maior salto, mas foi preparado por módulos, funções e persistência. | 0.9 passou; requisito de versão B-01. |
| 17 | Evento, callback, `mainloop` e estado compartilhado são introduzidos antes da tela maior. A progressão terminal → janela é compreensível. | Import/compile da GUI passaram; construção visual não executada. |
| 18 | A necessidade de múltiplas telas e Treeview é clara; o roteiro de aceitação é adequado. O trecho central, porém, falha com strings do Tkinter. | 1.0 CLI passou; A-01 e B-06. |
| 19 | Caso manual → teste automatizado → backup → restauração é excelente encadeamento conceitual. A prova impressa não executa e a narrativa de backup diverge. | 1.1 testes e backup passaram; A-02 e B-04. |
| 20 | Git nasce da necessidade de histórico e entrega; staging/diff/commit são relacionados a evidências. Empacotamento permanece opcional. | 1.2 Git e testes passaram. |
| 21 | Pessoas e empréstimos ampliam o domínio sem apagar suporte. NULL/None e conflito aparecem no momento adequado. A regra de devolução e a GUI final ainda têm lacunas. | 2.0 CLI/testes/migração passaram; A-03, B-03 e B-06. |
| 22 | A prova de transferência muda o domínio e oferece rubrica em vez de solução pronta; é compatível com o repertório acumulado e não adiciona arquitetura nova. | Sem checkpoint, por intenção. |

### Síntese pedagógica

A progressão **Entender → Experimentar → Programar → Aplicar** acontece de forma consistente: contexto/problema, “Antes de executar”, “Hora de praticar”, código, “Saída esperada”, “Veja a evidência”, “Pratique” e “Transfira” formam um ciclo repetível. A repetição é funcional, não cansativa, porque cada capítulo acrescenta uma limitação real. Não foi encontrada justificativa para alterar os 22 capítulos ou a arquitetura pedagógica.

Para o iniciante absoluto, os maiores riscos não são saltos conceituais gerais, mas instruções que prometem uma evidência impossível nos achados A-01/A-02 e o dado invisível da GUI no A-03.

## 8. Auditoria visual/editorial das 85 páginas

Todas as páginas foram rasterizadas e inspecionadas visualmente; páginas suspeitas foram reabertas em resolução integral. A comparação PDF ↔ DOCX confirmou a mesma paginação e o mesmo conteúdo textual.

| Páginas | Conteúdo | Resultado visual/editorial |
|---|---|---|
| 1 | capa | limpa, título/autor/coleção legíveis; boa primeira impressão |
| 2–4 | ficha, como ler, sumário, QR e material | hierarquia e tabelas consistentes; QR nítido; URL visível e clicável |
| 5 | divisória da Parte I | vazio intencional e coerente |
| 6–17 | capítulos 1–4 | sem clipping, órfãos graves ou código ilegível |
| 18 | divisória da Parte II | vazio intencional |
| 19–31 | capítulos 5–8 | íntegros; p. 20 contém C-01 |
| 32 | divisória da Parte III | vazio intencional |
| 33–41 | capítulos 9–11 | consistentes e legíveis |
| 42 | divisória da Parte IV | vazio intencional |
| 43–45 | capítulo 12 | consistente até o bloco de referências |
| 46 | fim do capítulo 12 | B-05: um único bullet no topo e página quase vazia |
| 47–57 | capítulos 13–15 | código/tabelas legíveis; B-06 nas pp. 48/52 e C-02 nas pp. 54–55 |
| 58 | divisória da Parte V | vazio intencional |
| 59–64 | capítulos 16–17 | figuras, código e margens consistentes |
| 65–68 | capítulo 18 | A-01 e B-06 na p. 66; sem falha de renderização adicional |
| 69–71 | capítulo 19 | A-02/B-04 na p. 70; tabelas e blocos permanecem legíveis |
| 72–74 | capítulo 20 | Git e entrega bem hierarquizados |
| 75 | divisória da Parte VI | vazio intencional |
| 76–79 | capítulo 21 | B-06 na p. 76; figura e tabelas legíveis; falha funcional A-03 está no código do ZIP, não na renderização |
| 80–82 | capítulo 22 | fechamento e rubrica claros |
| 83–85 | mapa, glossário, índice e referências | tabelas corretas; p. 85 termina com espaço natural de fim de livro, não tratado como defeito |

### Controles visuais específicos

- Não foram observados texto cortado, sobreposição, tabela fora da margem, código truncado, glyphs ausentes, numeração duplicada ou rodapé incompatível.
- Cabeçalhos/rodapés e números seguem padrão; divisórias de parte não foram confundidas com páginas vazias acidentais.
- Contraste de corpo, caixas, tabelas e código é suficiente em tela na inspeção realizada.
- A capa, a ficha e as primeiras páginas passam confiança, salvo a ausência de informações comerciais externas que dependem do canal (ver seção 15).
- As figuras têm legenda, numeração e escala legível.
- O QR do PDF foi comparado módulo a módulo com o SVG público: **0 divergências em 1.089 módulos**. A decodificação independente do SVG retornou exatamente `https://www.mundobitbyte.com.br/python-do-zero/`.

## 9. Auditoria dos 13 checkpoints

| Versão | Capítulo | README/CHANGELOG | Execução e resultado | Situação |
|---|---:|---|---|---|
| 0.1 | 2 | coerentes | primeira execução e menu informativo | PASS |
| 0.2 | 4 | coerentes; erro intencional documentado | entrada válida e `ValueError` didático | PASS |
| 0.3 | 6 | coerentes | menu contínuo, cadastro, consulta e saída | PASS |
| 0.4 | 8 | coerentes | listar, buscar, filtrar e resumir | PASS |
| 0.5 | 10 | coerentes | imports/módulos e consultas | PASS |
| 0.6 | 11 | coerentes | conversão inválida tratada e diagnóstico | PASS |
| 0.7 | 13 | coerentes | reset, SQLite, CRUD, transação e persistência | PASS |
| 0.8 | 15 | explica migração | migração/CSV/JSON passam; execução isolada falha | **B-02** |
| 0.9 | 16 | coerentes | modelos, serviço, repositório e CLI | PASS |
| 1.0 | 18 | coerentes | CLI passa; GUI compila/importa | A-01 é divergência do livro, não do checkpoint |
| 1.1 | 19 | coerentes com os arquivos | 2/2 testes, backup/restauração passam | A-02/B-04 são divergências do livro |
| 1.2 | 20 | coerentes | 2/2 testes, Git e `.gitignore` passam | PASS |
| 2.0 | 21 | coerentes em alto nível | 2/2 testes, CLI, migração e empréstimos passam | **A-03/B-03** |

Os nomes de versão e capítulos do mapa do livro, do `LEIA-ME.md`, dos READMEs e CHANGELOGs coincidem. Não foram encontrados checkpoint faltante, versão extra ou número de capítulo divergente.

## 10. Auditoria do ZIP

### Estrutura e higiene

- Arquivo válido: `unzip -t` terminou sem erros.
- 174 arquivos: 77 `.py`, 38 `.md`, 25 `.png`, 25 `.svg`, 4 `.gitkeep`, 1 `.gitignore`, 1 `.db`, 1 `.json` e 2 `.txt`.
- Os 13 checkpoints esperados estão presentes: 0.1–0.9, 1.0–1.2 e 2.0.
- Há 25 pares SVG/PNG de visuais, incluindo figuras e marcos da Central.
- Não foram encontrados `__pycache__`, `.pyc`, `.DS_Store`, caches de teste, ambientes virtuais, relatórios internos, prompts, manuscrito editável ou arquivos de bastidor.
- Nomes de pastas e arquivos são compreensíveis; `.gitkeep` e `.gitignore` são tecnicamente apropriados e não constituem lixo.

### Correspondência e independência

- Mapa raiz, READMEs e CHANGELOGs correspondem à evolução descrita no livro.
- Scripts de migração existem nos pontos corretos: 0.7 → 0.8 e 1.2 → 2.0.
- O único desvio da promessa de independência é v0.8, descrito em B-02.
- A versão 2.0 preserva funcionalidades de suporte e acrescenta pessoas/empréstimos; não é um projeto desconectado.

### Comparação anexo ↔ site

| Origem | Tamanho | SHA-256 |
|---|---:|---|
| ZIP dentro do kit anexo | 235.164 bytes | `539a06314452a68294e201e3a34c5bfdda09e31d35c65196a3aa6c1b6db80634` |
| ZIP baixado do site | 235.164 bytes | `539a06314452a68294e201e3a34c5bfdda09e31d35c65196a3aa6c1b6db80634` |

Conclusão: são byte a byte idênticos.

## 11. Auditoria da página, QR/URL e download

### Fluxo verificado

1. O endereço `https://www.mundobitbyte.com.br/python-do-zero/` respondeu e carregou a página intitulada “Python do Zero — Material de apoio | Mundo bit Byte”.
2. A página apresenta “Material do livro”, mapa de checkpoints, instruções, aviso de dados fictícios e QR sem linguagem de bastidor.
3. O botão “Baixar material complementar” aponta para `download/Python_do_Zero_Material_de_Apoio_v1.0.zip` e possui atributo `download`.
4. O download direto respondeu HTTP 200, `application/x-zip-compressed`, nome correto e 235.164 bytes.
5. O ZIP baixado abriu, passou no teste de integridade e é idêntico ao anexo.
6. Um checkpoint foi aberto e executado; os testes detalhados estão nas seções 6 e 9.

### Desktop

- Viewport observado: 1.363 × 936 CSS pixels.
- Sem rolagem horizontal; botão principal visível, com área aproximada de 283 × 51 pixels.
- Hierarquia, espaçamento, contraste, texto e mapa transmitem aparência de produto comercial.
- Não foram encontrados links quebrados na página nem divergência de nome/versão do arquivo.

### Mobile

- A página contém `meta viewport`.
- A folha de estilos possui regra responsiva em `max-width: 720px`, empilha cabeçalho/card/botão, ajusta o grid e encapsula a tabela com rolagem horizontal.
- Não foi possível produzir uma captura mobile real no navegador disponível, pois ele não expôs emulação de viewport/dispositivo. Portanto, a responsividade foi validada estruturalmente, não pixel a pixel; consta também na seção 15.

### QR e URLs

- QR público respondeu HTTP 200.
- O payload foi decodificado de forma independente: `https://www.mundobitbyte.com.br/python-do-zero/`.
- A matriz do QR no PDF coincide exatamente com a do SVG público.
- As 49 referências técnicas do livro foram verificadas. Trinta e seis responderam diretamente HTTP 200 no lote de `curl`; as 13 afetadas por timeout/erro do proxy de auditoria foram reabertas com o navegador de pesquisa e todas se mostraram páginas válidas. Não foi confirmado link técnico quebrado.

### Repositório público

- Repositório: `https://github.com/mundobitbyte/site`, público, branch padrão `main`.
- Estado observado: commit `1aa0c57d63d2b44082b242c5dba8aadab915fb61`, mensagem “Liga material de apoio Python do Zero ao ZIP v1.0”.
- `python-do-zero/index.html` contém o href e o atributo de download corretos.
- O blob do ZIP no repositório informa 235.164 bytes, coerente com site e anexo.
- CSS e SVG do QR estão presentes no repositório. Nenhuma escrita foi feita.

## 12. Matriz livro ↔ checkpoint ↔ ZIP ↔ site

| Cap. | Exercício/conquista | Código e resultado esperado | Checkpoint | README/CHANGELOG / ZIP / site | Consistência |
|---:|---|---|---|---|---|
| 1 | algoritmo e evidência | pseudocódigo, sem execução | — | mapa não promete checkpoint | OK |
| 2 | primeira execução | `print`/terminal | 0.1 | presente e publicado | OK |
| 3 | valores, tipos, `None` | variáveis em memória | — | sem checkpoint previsto | OK |
| 4 | entrada e conversão | inclui erro intencional | 0.2 | erro explicado no README raiz | OK |
| 5 | prioridade/condições | ramos 1–3 | — | sem checkpoint previsto | OK; C-01 visual |
| 6 | menu contínuo | `while`, sair e inválido | 0.3 | presente | OK |
| 7 | múltiplos registros | lista/dicionário/`for` | — | sem checkpoint previsto | OK |
| 8 | busca/filtro/resumo | coleção consultável | 0.4 | presente | OK |
| 9 | funções | contrato e retorno | — | sem checkpoint previsto | OK |
| 10 | módulos/caminhos | imports e `pathlib` | 0.5 | presente | OK |
| 11 | diagnóstico | traceback/validação | 0.6 | presente | OK |
| 12 | persistência | SQLite básico | — | prepara 0.7 | OK; B-05 visual |
| 13 | CRUD/transação | atualizar/concluir | 0.7 | presente com DB/reset | OK; B-06 editorial |
| 14 | relação/migração | PK/FK/JOIN | — | atividade converge para 0.8 | OK; B-06 editorial |
| 15 | consulta/data/CSV/JSON | exportação e config | 0.8 | presente, mas depende de 0.7 | **B-02**, C-02 |
| 16 | objetos/camadas | modelos/serviço/repo | 0.9 | presente | B-01 requisito |
| 17 | janela/eventos | Tkinter básico | — | prepara 1.0 | OK |
| 18 | CLI + GUI/Treeview | saída prometida não ocorre com trecho impresso | 1.0 | checkpoint contém conversão correta | **A-01**, B-06 |
| 19 | unittest + backup | snippet/saída e narrativa divergentes | 1.1 | suíte e backup funcionam | **A-02**, B-04 |
| 20 | Git/entrega | comandos existem | 1.2 | Git/testes presentes | OK |
| 21 | pessoas/empréstimos | CLI funciona; GUI não revela pessoa ID | 2.0 | presente, publicado e migrável | **A-03**, B-03, B-06 |
| 22 | transferência | contratos/rubrica | — | nenhum checkpoint prometido | OK |

O mapa de versões da página pública, do livro e do README raiz é idêntico. O site entrega exatamente o ZIP auditado. As divergências reais estão localizadas nos achados referenciados, não na numeração global.

## 13. Checklist final de liberação comercial

### Obrigatório antes de liberar

- [ ] Corrigir conversões do trecho Tkinter do capítulo 18 (A-01).
- [ ] Corrigir imports e saída esperada do capítulo 19 (A-02).
- [ ] Tornar visível/preenchível o ID da pessoa na GUI 2.0 (A-03).
- [ ] Declarar Python 3.10+ nos requisitos (B-01).
- [ ] Resolver ou explicitar a exceção de independência do v0.8 (B-02).
- [ ] Rejeitar devolução anterior à retirada e adicionar teste (B-03).
- [ ] Alinhar descrição e implementação do backup/restauração (B-04).
- [ ] Refluir a página 46 (B-05).
- [ ] Remover as quatro marcas Markdown residuais (B-06).
- [ ] Rerenderizar PDF e conferir novamente todas as páginas alteradas e as páginas seguintes.
- [ ] Reexecutar compilação, suítes, migrações, backup/restauração, CLI e empréstimos.
- [ ] Gerar novo ZIP, publicar, baixar de novo e comparar hash com o artefato aprovado.

### Recomendado, sem bloquear isoladamente

- [ ] Corrigir o estilo do parágrafo da página 20 (C-01).
- [ ] Uniformizar “Movimento B” no capítulo 15 (C-02).
- [ ] Tornar referências técnicas clicáveis no PDF digital (C-03).
- [ ] Fazer smoke test visual real das GUIs em ambiente com display.
- [ ] Fazer captura e interação real em viewport mobile.

### Condicional ao canal comercial

- [ ] Confirmar ISBN, ficha catalográfica/CIP, créditos editoriais e dados de editora exigidos pelo canal escolhido.
- [ ] Confirmar termos de uso/licença do código de apoio para o comprador.
- [ ] Validar prova impressa física, se houver edição impressa.

## 14. Lista explícita de tudo que foi realmente testado

1. Inventário e SHA-256 do kit, PDF, DOCX e ZIP anexo.
2. Integridade do ZIP com leitura completa de todas as entradas.
3. Extração e inspeção de 174 arquivos do material de apoio.
4. Presença exata dos 13 checkpoints.
5. Leitura dos READMEs e CHANGELOGs e conferência de versão/capítulo.
6. Compilação de todos os 77 arquivos Python do ZIP.
7. Extração e compile check dos 22 blocos centrais do livro, respeitando blocos não Python.
8. Execução v0.1.
9. Entrada válida e erro didático de v0.2.
10. Menu contínuo, opção inválida, cadastro e consulta de v0.3.
11. Listagem, busca, filtro e resumo de v0.4 e v0.5.
12. Validação tratada de v0.6.
13. Reset, CRUD, alteração, conclusão e persistência entre processos de v0.7.
14. Execução isolada de v0.8.
15. Migração v0.7 → v0.8 sobre cópia.
16. Schema, contagens e `PRAGMA foreign_key_check` após migração.
17. Exportação CSV e reabertura/conferência das linhas.
18. Leitura JSON e conferência de configuração.
19. Fluxos CLI/serviço/repositório v0.9, v1.0, v1.1 e v1.2.
20. Suítes `unittest` v1.1, v1.2 e v2.0, 2 testes em cada.
21. Backup v1.1, restauração em diretório separado, abertura, hash e contagem.
22. `git init`, status, diff, add, diff staged, commit e log em cópia de v1.2.
23. Regra `.gitignore` para a base de trabalho.
24. Migração v1.2 → v2.0 e preservação de equipamento/atendimento.
25. Cadastro de pessoa e empréstimo pela CLI 2.0.
26. Recusa de segundo empréstimo aberto.
27. Identificação de atraso e remoção da lista após devolução.
28. Rejeição de data ISO inválida e de previsão anterior à retirada.
29. Teste exploratório de devolução anterior à retirada, que revelou B-03.
30. Teste de contrato reproduzindo o tipo textual do Tkinter, que revelou A-01.
31. Execução do snippet impresso de unittest, que revelou A-02.
32. Inspeção estática integral das GUIs e do caminho pessoa → empréstimo.
33. Renderização das 85 páginas do PDF e inspeção visual de todas.
34. Renderização do DOCX em 85 páginas e comparação textual/layout com o PDF.
35. Estrutura do DOCX: estilos, tabelas, comentários, revisões, objetos e macros.
36. Metadados, fontes, hyperlinks, dimensões e segurança do PDF.
37. QR público decodificado e QR do PDF comparado módulo a módulo.
38. Página pública em navegador desktop, dimensões, overflow e botão.
39. Href real do botão e resposta HTTP do download direto.
40. Validade e hash do ZIP baixado.
41. Comparação byte a byte implícita por SHA-256 anexo ↔ site.
42. HTML, CSS responsivo, asset QR e rota do download.
43. As 49 URLs técnicas do livro, por HTTP direto e revalidação das respostas afetadas pelo proxy.
44. Repositório público, branch, commit, HTML, CSS, QR e blob do ZIP por integração GitHub em modo leitura.

## 15. Lista do que não pôde ser testado e por quê

1. **Construção e interação visual real das janelas Tkinter:** o ambiente não possui servidor gráfico nem `xvfb-run`. Imports, compilação, rotas de callbacks e lógica foram testados/inspecionados; não houve clique real nas janelas.
2. **Renderização mobile pixel a pixel:** o navegador controlado não expôs emulação de viewport. HTML, `meta viewport`, media query, grid e overflow foram inspecionados, mas falta captura/interação em aparelho ou viewport real.
3. **Python 3.13.5 exato:** o ambiente disponível usa 3.12.14. A edição declara 3.13.5; não foi possível reproduzir esse interpretador específico. Os testes passaram em 3.12.14.
4. **Windows e macOS:** comandos, Tkinter e empacotamento não foram executados nesses sistemas.
5. **Executável PyInstaller:** a etapa é declarada opcional; não foi construído binário, e empacotamento multiplataforma exigiria o sistema-alvo.
6. **Clique/download pelo gerenciador do navegador controlado:** o evento de download foi bloqueado pelo cliente da automação. O href foi inspecionado e o mesmo recurso foi baixado por HTTP real, validado e comparado por hash; portanto, o arquivo público foi testado, mas não a UI nativa de download daquele navegador.
7. **Compra/pagamento e entrega pós-compra:** nenhuma loja ou fluxo de pagamento foi fornecido.
8. **Prova física impressa:** não foi fornecido exemplar físico; sangria, corte, encadernação e reprodução de cor não podem ser julgados pelo PDF.
9. **ISBN, CIP, registro, direitos de terceiros e licença do código:** não podem ser validados sem requisitos do canal, contratos e dados editoriais externos. A ausência não foi promovida automaticamente a erro, mas deve ser confirmada antes da venda.
10. **Carga, concorrência e corrupção intencional de banco:** fora do escopo didático declarado; foram feitos smoke tests e cenários funcionais, não ensaios de produção multiusuário.

## 16. Veredito final

Os elementos centrais estão sólidos e as correções necessárias são pontuais. Contudo, dois exemplos impressos fundamentais não produzem a evidência prometida e a GUI final não oferece um caminho completo para o empréstimo. Publicar assim expõe o iniciante a falhas nos momentos de maior confiança e compromete a promessa comercial da Central Horizonte 2.0.

**NÃO PUBLICAR AINDA**
