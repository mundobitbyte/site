# Fechamento RC2.1 - Mundo bit Byte

Livro: *Python do Zero - Do primeiro raciocínio à Central Horizonte 2.0*  
Autor: Ronaldo Lavestein  
Data: 15/09/2026

## Situação após a regressão do Work

A regressão do Work avaliou o RC2 antigo e concluiu **APROVADO COM CORREÇÕES PONTUAIS**. Os três bloqueadores A-01, A-02 e A-03 passaram nos retestes. Dos 12 achados originais, 11 foram considerados corrigidos e B-05 permaneceu parcial apenas porque o DOCX antigo ainda renderizava 85 páginas.

## B-05 - resolvido no RC2.1

O DOCX RC2.1 foi renderizado novamente com o renderizador oficial do fluxo de QA e produziu **84 páginas**. As referências do capítulo 12 ficam juntas na página 45 e o capítulo 13 começa na página 46. O PDF RC2.1 também possui 84 páginas.

## RC2-N1 - resolvido no material de apoio

O README do checkpoint 2.0 agora explica explicitamente como preparar a base 1.2 antes da migração:

1. abrir `central-horizonte-v1.2`;
2. executar `python central.py` para criar `dados/horizonte.db` (com dados fictícios ou saindo pelo menu);
3. voltar a `central-horizonte-v2.0`;
4. executar `python scripts/migrar_v12_v20.py`.

A sequência foi retestada em uma extração limpa. A base 1.2 foi criada, a migração 1.2 -> 2.0 terminou com sucesso, as tabelas `pessoa` e `emprestimo` foram criadas, `PRAGMA foreign_key_check` retornou vazio e a suíte 2.0 passou 3/3 testes.

## Integridade do novo ZIP

Arquivo: `Python_do_Zero_Material_de_Apoio_v1.0.zip`  
Tamanho: 254960 bytes  
SHA-256: `46e45484e72dad2b900da186e6537fb54e8b79bbd5637b960f076f5cdf07bc00`  
Teste de integridade ZIP: PASS

## Pendência externa

O site público ainda deve receber este novo ZIP no mesmo caminho e com o mesmo nome. Depois do upload, é necessário baixar o arquivo público e confirmar que o SHA-256 é o mesmo acima.

## Próxima revalidação recomendada

Não é necessária nova auditoria ampla. Quando o Work estiver disponível, pedir somente uma checagem de fechamento de dois pontos:

- confirmar B-05 no DOCX/PDF RC2.1 (84 páginas e página 46 iniciando o capítulo 13);
- confirmar RC2-N1 no README 2.0 e repetir a migração em extração limpa.

Se os dois passarem e o ZIP público tiver o mesmo hash do artefato acima, o release pode ser congelado para publicação.
