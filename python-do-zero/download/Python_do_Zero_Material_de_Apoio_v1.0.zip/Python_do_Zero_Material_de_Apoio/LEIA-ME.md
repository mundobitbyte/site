# Python do Zero — Material de apoio

Material complementar oficial de **Python do Zero — Do primeiro raciocínio à Central Horizonte 2.0**, de Ronaldo Lavestein.

O portal estável do livro é **https://www.mundobitbyte.com.br/python-do-zero/**. Ele reúne o download deste pacote, vídeos práticos publicados progressivamente por capítulo e eventuais atualizações. O livro permanece completo sem esses recursos.

## Como usar este pacote

O livro constrói a Central Horizonte passo a passo. A pasta `checkpoints/` contém treze fotografias funcionais desse projeto. Use o checkpoint correspondente ao capítulo quando quiser conferir o resultado, retomar um ponto anterior ou comparar sua implementação com a versão de referência.

A orientação pedagógica continua sendo: **faça primeiro a atividade do livro, observe a evidência e use o checkpoint como apoio**.

## Mapa dos checkpoints

| Versão | Capítulo | Conquista principal |
|---|---:|---|
| 0.1 | 2 | Primeira execução |
| 0.2 | 4 | Entrada interativa |
| 0.3 | 6 | Menu contínuo |
| 0.4 | 8 | Coleções em memória |
| 0.5 | 10 | Funções e módulos |
| 0.6 | 11 | Diagnóstico manual |
| 0.7 | 13 | SQLite e CRUD |
| 0.8 | 15 | Relações, datas, CSV e JSON |
| 0.9 | 16 | Objetos, serviço e repositório |
| 1.0 | 18 | CLI e Tkinter |
| 1.1 | 19 | unittest e backup |
| 1.2 | 20 | Git e entrega |
| 2.0 | 21 | Pessoas e empréstimos |

## Requisitos

- Python 3.10 ou superior. Ao instalar, escolha a versão estável atual disponível no site oficial; esta edição foi validada em Python 3.13.5.
- Os checkpoints usam principalmente a biblioteca padrão do Python.
- A interface gráfica usa Tkinter; a instalação do Python precisa ter suporte a Tkinter para abrir `app.py`.
- PyInstaller aparece apenas como recurso opcional na etapa de entrega da versão 1.2.

## Primeiro uso no Windows 10/11

1. Baixe o ZIP e escolha **Extrair tudo**. Não execute os arquivos dentro da pasta compactada.
2. Abra a pasta extraída `Python_do_Zero_Material_de_Apoio`.
3. Entre em `checkpoints` e escolha a versão indicada no capítulo, por exemplo `central-horizonte-v0.1`.
4. No VS Code, use **Arquivo > Abrir Pasta** e abra a pasta desse checkpoint.
5. Leia o `README.md` que está dentro dela.
6. No VS Code, use **Terminal > Novo Terminal**. O caminho mostrado no prompt deve terminar com o nome do checkpoint.
7. Execute `python --version`. Se esse comando não funcionar, tente `py --version`. Prossiga com o lançador que responder com Python 3.10 ou superior.
8. Execute o comando indicado pelo README, trocando `python` por `py` quando esse tiver sido o lançador válido.

Se aparecer “arquivo não encontrado”, execute `dir` e confirme se o arquivo e o README estão na pasta atual. Se Python não for reconhecido por nenhum dos dois comandos, repare a instalação e habilite a inclusão de Python no PATH; depois feche e reabra o terminal.

## Estrutura

- `checkpoints/` — as treze versões históricas da Central Horizonte, com código, READMEs, CHANGELOGs, testes e migrações quando aplicáveis;
- `visuais/` — diagramas e capturas usadas no livro, com fontes registradas quando aplicável.

## Importante

- Use somente dados fictícios.
- Em migrações, trabalhe sobre cópias; não use sua única base de dados.
- O checkpoint 0.2 permite observar um `ValueError` de propósito quando a prioridade não é numérica. O tratamento consciente desse erro é ensinado depois, no capítulo 11.

**Versão do material:** 1.0 — setembro de 2026  
© 2026 Ronaldo Lavestein · Mundo bit Byte
