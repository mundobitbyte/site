# Python do Zero — Material de apoio

Material complementar oficial de **Python do Zero — Do primeiro raciocínio à Central Horizonte 2.0**, de Ronaldo Lavestein.

## Como usar este pacote

O livro constrói a Central Horizonte passo a passo. A pasta `checkpoints/` contém treze fotografias funcionais desse projeto. Use o checkpoint correspondente ao capítulo quando quiser conferir o resultado, retomar um ponto anterior ou comparar sua implementação com a versão de referência.

A orientação pedagógica continua sendo: **faça primeiro a atividade do livro, observe a evidência e use o checkpoint como apoio**.

## Mapa dos checkpoints

| Versão | Capítulo | Conquista principal |
|---|---:|---|
| 0.1 | 2 | Primeira execução |
| 0.2 | 4 | Entrada interativa |
| 0.3 | 6 | Menu contínuo |
| 0.4 | 8 | Coleções em memória |
| 0.5 | 10 | Funções e módulos |
| 0.6 | 11 | Diagnóstico manual |
| 0.7 | 13 | SQLite e CRUD |
| 0.8 | 15 | Relações, datas, CSV e JSON |
| 0.9 | 16 | Objetos, serviço e repositório |
| 1.0 | 18 | CLI e Tkinter |
| 1.1 | 19 | unittest e backup |
| 1.2 | 20 | Git e entrega |
| 2.0 | 21 | Pessoas e empréstimos |

## Requisitos

- Python 3.10 ou superior; esta edição foi validada em Python 3.13.5.
- Os checkpoints usam principalmente a biblioteca padrão do Python.
- A interface gráfica usa Tkinter; a instalação do Python precisa ter suporte a Tkinter para abrir `app.py`.
- PyInstaller aparece apenas como recurso opcional na etapa de entrega da versão 1.2.

## Estrutura

- `checkpoints/` — as treze versões históricas da Central Horizonte, com código, READMEs, CHANGELOGs, testes e migrações quando aplicáveis;
- `visuais/` — figuras do livro em SVG e PNG.

## Importante

- Use somente dados fictícios.
- Em migrações, trabalhe sobre cópias; não use sua única base de dados.
- O checkpoint 0.2 permite observar um `ValueError` de propósito quando a prioridade não é numérica. O tratamento consciente desse erro é ensinado depois, no capítulo 11.

**Versão do material:** 1.0 — setembro de 2026  
© 2026 Ronaldo Lavestein · Mundo bit Byte
