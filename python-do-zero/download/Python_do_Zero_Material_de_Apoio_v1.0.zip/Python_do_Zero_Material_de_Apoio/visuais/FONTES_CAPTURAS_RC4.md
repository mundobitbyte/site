# Fontes das capturas inseridas no RC4

As capturas abaixo mostram interfaces reais e foram obtidas em 15 de setembro de 2026. Números de versão e detalhes visuais podem mudar; as orientações do livro usam endereços estáveis e mandam escolher sempre a versão estável atual.

| Arquivo | Origem oficial | Finalidade pedagógica |
|---|---|---|
| `fig-c02-01.jpg` | https://www.python.org/downloads/windows/ | localizar a versão estável do Python para Windows |
| `fig-c02-02.jpg` | https://code.visualstudio.com/download | localizar o download do VS Code para Windows 10/11 |
| `fig-c02-03.png` | https://code.visualstudio.com/docs/editing/getting-started | localizar a pasta aberta e o botão Novo Arquivo no Explorer |
| `fig-c02-05.png` | https://code.visualstudio.com/docs/editing/getting-started | reconhecer o terminal integrado e a pasta atual no prompt |
| `fig-c20-01.jpg` | https://git-scm.com/install/windows | localizar o download mantido do Git for Windows |

As imagens de interface são usadas como orientação visual. Os nomes de menus podem aparecer em português ou inglês, conforme o idioma instalado.
