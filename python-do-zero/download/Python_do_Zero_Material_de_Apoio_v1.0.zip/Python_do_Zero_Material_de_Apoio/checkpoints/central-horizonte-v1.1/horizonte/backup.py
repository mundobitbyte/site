import hashlib
import json
import shutil
from datetime import datetime
from pathlib import Path

from .repositorio import Repositorio

RAIZ = Path(__file__).resolve().parent.parent
ORIGEM = RAIZ / "dados" / "horizonte.db"
PASTA_BACKUPS = RAIZ / "backups"


def hash_arquivo(caminho):
    dados = Path(caminho).read_bytes()
    return hashlib.sha256(dados).hexdigest()


def criar(origem=ORIGEM, pasta=PASTA_BACKUPS):
    origem = Path(origem)
    pasta = Path(pasta)
    pasta.mkdir(parents=True, exist_ok=True)
    if not origem.exists():
        raise FileNotFoundError(origem)

    nome = f"horizonte-{datetime.now():%Y%m%d-%H%M%S}.db"
    destino = pasta / nome
    shutil.copy2(origem, destino)

    manifesto = {
        "arquivo": destino.name,
        "tamanho": destino.stat().st_size,
        "sha256": hash_arquivo(destino),
    }
    caminho_manifesto = destino.with_suffix(".json")
    caminho_manifesto.write_text(
        json.dumps(manifesto, indent=2, ensure_ascii=False),
        encoding="utf-8",
    )
    return destino


def restaurar(backup, pasta_destino):
    backup = Path(backup)
    pasta_destino = Path(pasta_destino)
    pasta_destino.mkdir(parents=True, exist_ok=True)
    restaurado = pasta_destino / "horizonte-restaurado.db"
    shutil.copy2(backup, restaurado)

    repositorio = Repositorio(restaurado)
    repositorio.inicializar()
    repositorio.listar_equipamentos()
    repositorio.listar_atendimentos()

    if hash_arquivo(backup) != hash_arquivo(restaurado):
        raise RuntimeError("Hash da restauração diverge.")
    return restaurado
