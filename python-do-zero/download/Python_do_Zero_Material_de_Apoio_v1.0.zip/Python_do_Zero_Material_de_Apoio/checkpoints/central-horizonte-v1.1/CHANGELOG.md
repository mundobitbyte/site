# CHANGELOG

## 1.1 — 2026-09-14

### Adicionado
- automatiza regressões com unittest
- cria backup com manifesto e hash
- restaura em destino separado e verifica

### Limitações conhecidas
- ainda não há histórico Git nem pacote reproduzível

### Migração
Evolução documentada a partir da 1.0; a versão anterior não é alterada.
