import tempfile
import unittest
from pathlib import Path

from horizonte.repositorio import Repositorio
from horizonte.servicos import ServicoCentral

class TestCentral(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.caminho = Path(self.tmp.name) / "teste.db"
        self.servico = ServicoCentral(Repositorio(self.caminho)); self.servico.preparar()
        self.eid = self.servico.cadastrar_equipamento("NB-07", "notebook")

    def tearDown(self): self.tmp.cleanup()

    def test_fluxo_atendimento(self):
        aid = self.servico.abrir_atendimento(self.eid, "Não liga", 1, "2026-09-01")
        self.assertEqual(self.servico.listar_atendimentos()[0].descricao, "Não liga")
        self.servico.alterar_prioridade(aid, 2)
        self.servico.concluir_atendimento(aid)
        item = self.servico.listar_atendimentos()[0]
        self.assertEqual(item.prioridade, 2); self.assertEqual(item.estado, "concluído")

    def test_prioridade_invalida(self):
        with self.assertRaises(ValueError): self.servico.abrir_atendimento(self.eid, "x", 4)

if __name__ == "__main__": unittest.main()
