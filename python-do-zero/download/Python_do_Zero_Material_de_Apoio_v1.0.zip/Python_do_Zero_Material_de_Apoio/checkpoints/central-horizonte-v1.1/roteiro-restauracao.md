# Restauração

Crie o backup, restaure em pasta temporária, abra o banco restaurado e compare contagens e SHA-256. Nunca sobrescreva a base de trabalho durante o teste.
