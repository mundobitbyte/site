# Central Horizonte 1.1

Checkpoint do capítulo **19** de *Python do Zero — Mundo bit Byte*.

## O que esta versão representa

Testes automatizados e backup. Este diretório é uma fotografia funcional do projeto naquele ponto da leitura; ele serve para conferência, retomada ou continuidade, não para substituir a construção proposta no capítulo.

## Como executar

1. Abra o terminal nesta pasta.
2. Use Python 3.10 ou superior.
3. Execute `python central.py`.

Para abrir a interface gráfica, execute `python app.py`. Para executar a suíte automática, use `python -m unittest discover -v`.

Para executar o ciclo completo de backup em uma base temporária, use `python scripts/verificar_backup.py`. O roteiro cria dados fictícios, gera backup e manifesto, restaura em outra pasta e compara hash e contagens sem tocar na base de trabalho.

## Dados de prática

Use somente dados fictícios nos experimentos. Os exemplos NB-07, PC-12 e IMP-03 usados no livro são fictícios.

## Continuidade

Cada checkpoint preserva o repertório conquistado até aqui. Em migrações, mantenha a versão anterior intacta e trabalhe sempre sobre uma cópia da base.
