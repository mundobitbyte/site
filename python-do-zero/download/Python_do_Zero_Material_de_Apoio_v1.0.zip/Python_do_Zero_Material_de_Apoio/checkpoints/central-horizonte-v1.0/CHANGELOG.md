# CHANGELOG

## 1.0 — 2026-09-14

### Adicionado
- oferece GUI Tkinter
- CLI e GUI compartilham serviço, repositório e SQLite

### Limitações conhecidas
- testes ainda são manuais
- uma cópia isolada ainda não é backup confiável

### Migração
Evolução documentada a partir da 0.9; a versão anterior não é alterada.
