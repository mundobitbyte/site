# Aceitação 1.0

Cadastre na GUI, feche e execute `python central.py`; confirme os mesmos dados. Cadastre pela CLI, reabra a GUI e confirme a atualização. Revise rótulos, foco e mensagens.
