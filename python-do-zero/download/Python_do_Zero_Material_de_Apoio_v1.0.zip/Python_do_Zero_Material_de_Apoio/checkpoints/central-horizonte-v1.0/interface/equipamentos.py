import sqlite3
import tkinter as tk
from tkinter import messagebox, ttk


class AbaEquipamentos(ttk.Frame):
    def __init__(self, mestre, servico, ao_mudar=None):
        super().__init__(mestre, padding=12)
        self.servico = servico
        self.ao_mudar = ao_mudar
        self.patrimonio = tk.StringVar()
        self.tipo = tk.StringVar(value="notebook")
        self._montar()

    def _montar(self):
        ttk.Label(self, text="Patrimônio").grid(row=0, column=0, sticky="w")
        ttk.Entry(self, textvariable=self.patrimonio).grid(row=1, column=0, sticky="ew")
        ttk.Label(self, text="Tipo").grid(row=0, column=1, sticky="w")
        ttk.Entry(self, textvariable=self.tipo).grid(row=1, column=1, sticky="ew")
        ttk.Button(self, text="Cadastrar", command=self.cadastrar).grid(row=1, column=2, padx=8)

        self.tabela = ttk.Treeview(
            self,
            columns=("id", "patrimonio", "tipo"),
            show="headings",
            height=16,
        )
        self.tabela.heading("id", text="ID")
        self.tabela.heading("patrimonio", text="Patrimônio")
        self.tabela.heading("tipo", text="Tipo")
        self.tabela.grid(row=2, column=0, columnspan=3, pady=12, sticky="nsew")

        self.columnconfigure(0, weight=1)
        self.columnconfigure(1, weight=1)
        self.rowconfigure(2, weight=1)

    def cadastrar(self):
        try:
            self.servico.cadastrar_equipamento(self.patrimonio.get(), self.tipo.get())
        except ValueError as erro:
            messagebox.showerror("Equipamento", str(erro))
            return
        except sqlite3.IntegrityError:
            messagebox.showerror("Equipamento", "Já existe um equipamento com esse patrimônio.")
            return

        self.patrimonio.set("")
        self.atualizar()
        if self.ao_mudar is not None:
            self.ao_mudar()

    def atualizar(self):
        self.tabela.delete(*self.tabela.get_children())
        for equipamento in self.servico.listar_equipamentos():
            self.tabela.insert(
                "",
                "end",
                values=(equipamento.id, equipamento.patrimonio, equipamento.tipo),
            )
