import tkinter as tk
from tkinter import messagebox, ttk


class AbaAtendimentos(ttk.Frame):
    def __init__(self, mestre, servico):
        super().__init__(mestre, padding=12)
        self.servico = servico
        self.equipamento_id = tk.StringVar()
        self.descricao = tk.StringVar()
        self.prioridade = tk.StringVar(value="2")
        self._montar()

    def _montar(self):
        ttk.Label(self, text="ID do equipamento").grid(row=0, column=0, sticky="w")
        ttk.Entry(self, textvariable=self.equipamento_id).grid(row=1, column=0, sticky="ew")
        ttk.Label(self, text="Descrição").grid(row=0, column=1, sticky="w")
        ttk.Entry(self, textvariable=self.descricao).grid(row=1, column=1, sticky="ew")
        ttk.Label(self, text="Prioridade").grid(row=0, column=2, sticky="w")
        ttk.Entry(self, textvariable=self.prioridade, width=8).grid(row=1, column=2, sticky="w")
        ttk.Button(self, text="Abrir atendimento", command=self.abrir).grid(row=1, column=3, padx=8)

        self.tabela = ttk.Treeview(
            self,
            columns=("id", "patrimonio", "descricao", "prioridade", "estado"),
            show="headings",
            height=15,
        )
        for coluna, titulo in (
            ("id", "ID"),
            ("patrimonio", "Patrimônio"),
            ("descricao", "Descrição"),
            ("prioridade", "Prioridade"),
            ("estado", "Estado"),
        ):
            self.tabela.heading(coluna, text=titulo)
        self.tabela.grid(row=2, column=0, columnspan=4, pady=12, sticky="nsew")

        ttk.Button(self, text="Concluir selecionado", command=self.concluir).grid(row=3, column=0, sticky="w")
        ttk.Button(self, text="Prioridade 1", command=self.prioridade_1).grid(row=3, column=1, sticky="w")
        ttk.Button(self, text="Prioridade 2", command=self.prioridade_2).grid(row=3, column=2, sticky="w")
        ttk.Button(self, text="Prioridade 3", command=self.prioridade_3).grid(row=3, column=3, sticky="w")

        self.columnconfigure(0, weight=1)
        self.columnconfigure(1, weight=1)
        self.rowconfigure(2, weight=1)

    def abrir(self):
        try:
            equipamento_id = int(self.equipamento_id.get())
            prioridade = int(self.prioridade.get())
            self.servico.abrir_atendimento(equipamento_id, self.descricao.get(), prioridade)
        except ValueError as erro:
            messagebox.showerror("Atendimento", str(erro))
            return
        self.descricao.set("")
        self.atualizar()

    def _id_selecionado(self):
        selecionados = self.tabela.selection()
        if not selecionados:
            raise ValueError("Selecione um atendimento.")
        valores = self.tabela.item(selecionados[0], "values")
        return int(valores[0])

    def concluir(self):
        try:
            self.servico.concluir_atendimento(self._id_selecionado())
        except ValueError as erro:
            messagebox.showerror("Atendimento", str(erro))
            return
        self.atualizar()

    def _mudar_prioridade(self, prioridade):
        try:
            self.servico.alterar_prioridade(self._id_selecionado(), prioridade)
        except ValueError as erro:
            messagebox.showerror("Atendimento", str(erro))
            return
        self.atualizar()

    def prioridade_1(self):
        self._mudar_prioridade(1)

    def prioridade_2(self):
        self._mudar_prioridade(2)

    def prioridade_3(self):
        self._mudar_prioridade(3)

    def atualizar(self):
        self.tabela.delete(*self.tabela.get_children())
        for atendimento in self.servico.listar_atendimentos():
            self.tabela.insert(
                "",
                "end",
                values=(
                    atendimento.id,
                    atendimento.patrimonio,
                    atendimento.descricao,
                    atendimento.prioridade,
                    atendimento.estado,
                ),
            )
