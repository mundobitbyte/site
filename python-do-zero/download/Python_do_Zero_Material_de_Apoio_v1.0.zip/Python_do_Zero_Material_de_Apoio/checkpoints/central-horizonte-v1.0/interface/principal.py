import tkinter as tk
from tkinter import ttk

from horizonte.repositorio import Repositorio
from horizonte.servicos import ServicoCentral
from .atendimentos import AbaAtendimentos
from .equipamentos import AbaEquipamentos


class JanelaCentral(tk.Tk):
    def __init__(self, caminho=None):
        super().__init__()
        self.title("Central Horizonte 1.0")
        self.geometry("940x560")

        self.servico = ServicoCentral(Repositorio(caminho))
        self.servico.preparar()

        abas = ttk.Notebook(self)
        abas.pack(fill="both", expand=True, padx=12, pady=12)

        self.aba_atendimentos = AbaAtendimentos(abas, self.servico)
        self.aba_equipamentos = AbaEquipamentos(
            abas,
            self.servico,
            ao_mudar=self.aba_atendimentos.atualizar,
        )
        abas.add(self.aba_equipamentos, text="Equipamentos")
        abas.add(self.aba_atendimentos, text="Atendimentos")

        self.aba_equipamentos.atualizar()
        self.aba_atendimentos.atualizar()
