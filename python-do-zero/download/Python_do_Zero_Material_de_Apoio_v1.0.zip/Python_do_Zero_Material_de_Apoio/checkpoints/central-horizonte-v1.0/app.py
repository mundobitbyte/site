from interface.principal import JanelaCentral


if __name__ == "__main__":
    JanelaCentral().mainloop()
