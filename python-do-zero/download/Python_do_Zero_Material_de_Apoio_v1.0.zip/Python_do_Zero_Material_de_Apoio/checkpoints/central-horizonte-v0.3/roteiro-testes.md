# Roteiro manual

Informe as opções `9`, `1` e `0`. Cadastre NB-07 e confirme que o menu volta a aparecer e que 0 encerra o laço.
