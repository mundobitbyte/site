# CHANGELOG

## 0.3 — 2026-09-14

### Adicionado
- mantém o menu aberto com while
- decide ações com if/elif/else
- encerra de forma controlada

### Limitações conhecidas
- conserva somente um atendimento por vez
- não há coleção

### Migração
Evolução documentada a partir da 0.2; a versão anterior não é alterada.
