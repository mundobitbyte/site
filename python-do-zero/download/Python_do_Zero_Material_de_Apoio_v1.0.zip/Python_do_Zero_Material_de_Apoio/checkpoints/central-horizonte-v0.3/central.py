print("Central Horizonte - versão 0.3")

opcao = ""
ultimo_patrimonio = ""
ultima_descricao = ""
ultima_prioridade = 0
ultimo_estado = ""
ha_atendimento = False

while opcao != "0":
    print("\n1 - Registrar atendimento")
    print("2 - Mostrar último atendimento")
    print("0 - Sair")
    opcao = input("Opção: ").strip()

    if opcao == "1":
        patrimonio = input("Patrimônio: ").strip().upper()
        descricao = input("Descrição: ").strip()
        prioridade = int(input("Prioridade (1 a 3): ").strip())

        if prioridade in (1, 2, 3):
            ultimo_patrimonio = patrimonio
            ultima_descricao = descricao
            ultima_prioridade = prioridade
            ultimo_estado = "aberto"
            ha_atendimento = True
            print(f"Registrado: {patrimonio} | {descricao} | prioridade {prioridade} | aberto")
        else:
            print("Prioridade inválida. Use 1, 2 ou 3.")

    elif opcao == "2":
        if ha_atendimento:
            print(f"{ultimo_patrimonio} | {ultima_descricao} | prioridade {ultima_prioridade} | {ultimo_estado}")
        else:
            print("Nenhum atendimento registrado nesta execução.")

    elif opcao != "0":
        print("Opção inválida.")

print("Central encerrada.")
