"""Executa backup e restauração 1.2 somente em diretório temporário."""
import json
import sys
import tempfile
from pathlib import Path


RAIZ = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(RAIZ))

from horizonte.backup import criar, hash_arquivo, restaurar  # noqa: E402
from horizonte.repositorio import Repositorio  # noqa: E402
from horizonte.servicos import ServicoCentral  # noqa: E402


with tempfile.TemporaryDirectory() as pasta:
    laboratorio = Path(pasta)
    origem = laboratorio / "origem" / "horizonte.db"
    servico = ServicoCentral(Repositorio(origem))
    servico.preparar()
    equipamento_id = servico.cadastrar_equipamento("NB-07", "notebook")
    servico.abrir_atendimento(equipamento_id, "não liga", 1, "2026-09-01")

    backup = criar(origem, laboratorio / "backups")
    restaurado = restaurar(backup, laboratorio / "restaurado")
    manifesto = json.loads(backup.with_suffix(".json").read_text(encoding="utf-8"))

    repo = Repositorio(restaurado)
    equipamentos = len(repo.listar_equipamentos())
    atendimentos = len(repo.listar_atendimentos())
    assert hash_arquivo(backup) == hash_arquivo(restaurado) == manifesto["sha256"]
    assert (equipamentos, atendimentos) == (1, 1)

    print("Backup:", backup.name)
    print("Manifesto: tamanho e SHA-256 conferidos")
    print("Restauração: 1 equipamento; 1 atendimento")
    print("backup e restauração verificados")
