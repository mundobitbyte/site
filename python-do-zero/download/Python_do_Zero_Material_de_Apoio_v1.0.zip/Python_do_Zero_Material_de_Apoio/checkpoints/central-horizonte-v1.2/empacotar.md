# Pacote reproduzível

1. Crie e ative um ambiente virtual.
2. Instale `requirements.txt`.
3. Execute os testes.
4. Gere com `pyinstaller --onefile --windowed app.py`.
5. Teste o resultado em outra pasta, usando somente este README.
