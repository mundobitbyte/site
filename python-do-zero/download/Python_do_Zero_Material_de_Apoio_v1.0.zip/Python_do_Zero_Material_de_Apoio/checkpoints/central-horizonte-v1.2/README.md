# Central Horizonte 1.2

Checkpoint do capítulo **20** de *Python do Zero — Mundo bit Byte*.

## O que esta versão representa

Git, entrega e empacotamento opcional. Este diretório é uma fotografia funcional do projeto naquele ponto da leitura; ele serve para conferência, retomada ou continuidade, não para substituir a construção proposta no capítulo.

## Como executar

1. Abra o terminal nesta pasta.
2. Use Python 3.10 ou superior.
3. Execute `python central.py`.

Para abrir a interface gráfica, execute `python app.py`. Para executar a suíte automática, use `python -m unittest discover -v`. O PyInstaller é opcional e aparece apenas na etapa de entrega.

Para executar o ciclo completo de backup em uma base temporária, use `python scripts/verificar_backup.py`. O roteiro não altera a base de trabalho.

## Dados de prática

Use somente dados fictícios nos experimentos. Os exemplos NB-07, PC-12 e IMP-03 usados no livro são fictícios.

## Continuidade

Cada checkpoint preserva o repertório conquistado até aqui. Em migrações, mantenha a versão anterior intacta e trabalhe sempre sobre uma cópia da base.
