# CHANGELOG

## 1.2 — 2026-09-14

### Adicionado
- documenta Git e ambiente reproduzível
- prepara pacote verificável
- mantém suíte e backup
- mantém o roteiro executável de verificação de backup

### Limitações conhecidas
- ainda não existem Pessoa e Empréstimo

### Migração
Evolução documentada a partir da 1.1; a versão anterior não é alterada.
