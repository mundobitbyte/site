# CHANGELOG

## 0.1 — 2026-09-14

### Adicionado
- exibe nome, versão e opções informativas
- prova o caminho arquivo → interpretador → saída

### Limitações conhecidas
- ainda não recebe dados
- as opções não executam ações

### Migração
Não se aplica; esta é a primeira versão.
