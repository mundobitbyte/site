# CHANGELOG

## 0.5 — 2026-09-14

### Adicionado
- separa funções em módulos concretos
- executa pela raiz com imports estáveis

### Limitações conhecidas
- dados continuam em memória
- diagnóstico ainda depende de tentativa e erro

### Migração
Evolução documentada a partir da 0.4; a versão anterior não é alterada.
