from horizonte.atendimentos import ATENDIMENTOS_EXEMPLO
from horizonte.consultas import buscar, filtrar, ordenar
from horizonte.regras import normalizar_descricao, normalizar_patrimonio, prioridade_valida
from horizonte.relatorios import resumo

atendimentos = []
for item in ATENDIMENTOS_EXEMPLO:
    atendimentos.append(item.copy())

print("Central Horizonte - versão 0.5")
opcao = ""
while opcao != "0":
    print("\n1-Cadastrar 2-Listar 3-Buscar 4-Filtrar 5-Resumo 0-Sair")
    opcao = input("Opção: ").strip()

    if opcao == "1":
        patrimonio = normalizar_patrimonio(input("Patrimônio: "))
        descricao = normalizar_descricao(input("Descrição: "))
        prioridade = int(input("Prioridade (1 a 3): ").strip())
        if prioridade_valida(prioridade):
            atendimentos.append({
                "patrimonio": patrimonio,
                "descricao": descricao,
                "prioridade": prioridade,
                "estado": "aberto",
            })
            print("Atendimento cadastrado.")
        else:
            print("Prioridade inválida. Use 1, 2 ou 3.")

    elif opcao == "2":
        for item in ordenar(atendimentos):
            print(item)

    elif opcao == "3":
        encontrado = buscar(atendimentos, input("Patrimônio: "))
        if encontrado is None:
            print("Patrimônio não encontrado.")
        else:
            print(encontrado)

    elif opcao == "4":
        estado = input("Estado: ").strip().lower()
        for item in filtrar(atendimentos, estado):
            print(item)

    elif opcao == "5":
        print(resumo(atendimentos))

    elif opcao != "0":
        print("Opção inválida.")
