def buscar(atendimentos, patrimonio):
    procurado = patrimonio.strip().upper()
    for atendimento in atendimentos:
        if atendimento["patrimonio"] == procurado:
            return atendimento
    return None


def filtrar(atendimentos, estado):
    encontrados = []
    for atendimento in atendimentos:
        if atendimento["estado"] == estado:
            encontrados.append(atendimento)
    return encontrados


def ordenar(atendimentos):
    ordenados = []
    for prioridade in (1, 2, 3):
        for atendimento in atendimentos:
            if atendimento["prioridade"] == prioridade:
                ordenados.append(atendimento)
    return ordenados
