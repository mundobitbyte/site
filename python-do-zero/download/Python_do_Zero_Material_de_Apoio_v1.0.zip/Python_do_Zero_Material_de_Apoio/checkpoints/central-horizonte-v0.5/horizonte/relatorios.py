def resumo(atendimentos):
    abertos = 0
    for atendimento in atendimentos:
        if atendimento["estado"] == "aberto":
            abertos = abertos + 1
    return f"{len(atendimentos)} atendimentos; {abertos} abertos"
