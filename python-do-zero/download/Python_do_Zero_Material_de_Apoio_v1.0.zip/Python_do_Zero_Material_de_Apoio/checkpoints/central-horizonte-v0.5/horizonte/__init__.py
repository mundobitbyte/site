"""Núcleo da Central Horizonte."""
