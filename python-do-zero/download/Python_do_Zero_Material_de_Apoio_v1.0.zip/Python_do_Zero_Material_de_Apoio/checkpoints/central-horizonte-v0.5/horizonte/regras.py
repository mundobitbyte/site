def prioridade_valida(valor):
    return valor in (1, 2, 3)


def normalizar_patrimonio(valor):
    return valor.strip().upper()


def normalizar_descricao(valor):
    return valor.strip()
