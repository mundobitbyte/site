# Roteiro manual

Repita integralmente o roteiro da 0.4 e compare as saídas.
