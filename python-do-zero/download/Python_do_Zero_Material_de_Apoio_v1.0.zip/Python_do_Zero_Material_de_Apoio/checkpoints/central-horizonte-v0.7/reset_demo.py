from pathlib import Path
from horizonte.banco import BANCO, inicializar_banco, cadastrar
if Path(BANCO).exists(): Path(BANCO).unlink()
inicializar_banco(); cadastrar("NB-07", "não liga", 1); cadastrar("PC-12", "sem acesso à rede", 2)
print("Base fictícia 0.7 recriada com 2 atendimentos.")
