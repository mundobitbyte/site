# Roteiro manual

Recrie a base; feche e reabra; altere somente o id 2; conclua o id 1; confirme que nada ficou pela metade.
