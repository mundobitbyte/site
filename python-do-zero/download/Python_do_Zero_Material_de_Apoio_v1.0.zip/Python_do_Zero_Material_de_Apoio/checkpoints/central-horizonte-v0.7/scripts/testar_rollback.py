"""Demonstra rollback em uma base temporária sem tocar na base do checkpoint."""
import sqlite3
import tempfile
from pathlib import Path


with tempfile.TemporaryDirectory() as pasta:
    banco = Path(pasta) / "transacao.db"
    conexao = sqlite3.connect(banco)
    conexao.execute("""
        CREATE TABLE atendimento (
            id INTEGER PRIMARY KEY,
            patrimonio TEXT NOT NULL,
            prioridade INTEGER NOT NULL,
            estado TEXT NOT NULL
        )
    """)
    conexao.execute(
        "INSERT INTO atendimento VALUES (?, ?, ?, ?)",
        (1, "PC-12", 2, "aberto"),
    )
    conexao.commit()

    antes = conexao.execute(
        "SELECT prioridade, estado FROM atendimento WHERE id = 1"
    ).fetchone()

    try:
        with conexao:
            conexao.execute(
                "UPDATE atendimento SET prioridade = 1 WHERE id = 1"
            )
            raise RuntimeError("falha controlada")
            conexao.execute(
                "UPDATE atendimento SET estado = 'concluído' WHERE id = 1"
            )
    except RuntimeError as erro:
        print(erro)

    depois = conexao.execute(
        "SELECT prioridade, estado FROM atendimento WHERE id = 1"
    ).fetchone()
    conexao.close()

    print("Antes:", antes)
    print("Depois:", depois)
    assert antes == depois
    print("rollback confirmado")
