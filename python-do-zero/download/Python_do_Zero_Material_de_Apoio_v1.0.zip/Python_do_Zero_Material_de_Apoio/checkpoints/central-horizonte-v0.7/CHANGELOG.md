# CHANGELOG

## 0.7 — 2026-09-14

### Adicionado
- persiste atendimentos em SQLite
- cadastra, busca, atualiza e conclui
- usa transação e rollback nas escritas

### Limitações conhecidas
- uma tabela repete dados de equipamento

### Migração
Evolução documentada a partir da 0.6; a versão anterior não é alterada.
