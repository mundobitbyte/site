import sqlite3
from pathlib import Path

RAIZ = Path(__file__).resolve().parent.parent
PASTA_DADOS = RAIZ / "dados"
BANCO = PASTA_DADOS / "horizonte.db"


def conectar(caminho=BANCO):
    caminho = Path(caminho)
    caminho.parent.mkdir(parents=True, exist_ok=True)
    conexao = sqlite3.connect(caminho)
    conexao.row_factory = sqlite3.Row
    return conexao


def inicializar_banco(caminho=BANCO):
    conexao = conectar(caminho)
    conexao.execute("""
        CREATE TABLE IF NOT EXISTS atendimento (
            id INTEGER PRIMARY KEY,
            patrimonio TEXT NOT NULL,
            descricao TEXT NOT NULL,
            prioridade INTEGER NOT NULL CHECK (prioridade BETWEEN 1 AND 3),
            estado TEXT NOT NULL DEFAULT 'aberto'
        )
    """)
    conexao.commit()
    conexao.close()


def cadastrar(patrimonio, descricao, prioridade, estado="aberto", caminho=BANCO):
    conexao = conectar(caminho)
    cursor = conexao.execute("""
        INSERT INTO atendimento (patrimonio, descricao, prioridade, estado)
        VALUES (?, ?, ?, ?)
    """, (
        patrimonio.strip().upper(),
        descricao.strip(),
        prioridade,
        estado.strip().lower(),
    ))
    conexao.commit()
    novo_id = cursor.lastrowid
    conexao.close()
    return novo_id


def _linhas_para_dicionarios(linhas):
    resultado = []
    for linha in linhas:
        resultado.append(dict(linha))
    return resultado


def listar(caminho=BANCO):
    conexao = conectar(caminho)
    linhas = conexao.execute("""
        SELECT id, patrimonio, descricao, prioridade, estado
        FROM atendimento
        ORDER BY prioridade, id
    """).fetchall()
    conexao.close()
    return _linhas_para_dicionarios(linhas)


def buscar(atendimento_id, caminho=BANCO):
    conexao = conectar(caminho)
    linha = conexao.execute(
        "SELECT * FROM atendimento WHERE id = ?",
        (atendimento_id,),
    ).fetchone()
    conexao.close()
    if linha is None:
        return None
    return dict(linha)


def buscar_patrimonio(patrimonio, caminho=BANCO):
    conexao = conectar(caminho)
    linhas = conexao.execute(
        "SELECT * FROM atendimento WHERE patrimonio = ? ORDER BY id",
        (patrimonio.strip().upper(),),
    ).fetchall()
    conexao.close()
    return _linhas_para_dicionarios(linhas)


def filtrar_estado(estado, caminho=BANCO):
    conexao = conectar(caminho)
    linhas = conexao.execute(
        "SELECT * FROM atendimento WHERE estado = ? ORDER BY prioridade, id",
        (estado.strip().lower(),),
    ).fetchall()
    conexao.close()
    return _linhas_para_dicionarios(linhas)


def resumo(caminho=BANCO):
    conexao = conectar(caminho)
    total = conexao.execute("SELECT COUNT(*) FROM atendimento").fetchone()[0]
    abertos = conexao.execute(
        "SELECT COUNT(*) FROM atendimento WHERE estado = 'aberto'"
    ).fetchone()[0]
    conexao.close()
    return {"total": total, "abertos": abertos}


def atualizar_prioridade(atendimento_id, prioridade, caminho=BANCO):
    conexao = conectar(caminho)
    try:
        with conexao:
            cursor = conexao.execute(
                "UPDATE atendimento SET prioridade = ? WHERE id = ?",
                (prioridade, atendimento_id),
            )
            if cursor.rowcount != 1:
                raise ValueError("Atendimento inexistente.")
    finally:
        conexao.close()


def concluir(atendimento_id, caminho=BANCO):
    conexao = conectar(caminho)
    try:
        with conexao:
            cursor = conexao.execute(
                "UPDATE atendimento SET estado = 'concluído' WHERE id = ?",
                (atendimento_id,),
            )
            if cursor.rowcount != 1:
                raise ValueError("Atendimento inexistente.")
    finally:
        conexao.close()
