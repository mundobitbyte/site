from horizonte.banco import (
    inicializar_banco, cadastrar, listar, buscar, buscar_patrimonio,
    filtrar_estado, resumo, atualizar_prioridade, concluir,
)

inicializar_banco()
print("Central Horizonte - versão 0.7")
opcao = ""
while opcao != "0":
    print("\n1-Cadastrar 2-Listar 3-Buscar id 4-Filtrar estado 5-Resumo 6-Prioridade 7-Concluir 0-Sair")
    opcao = input("Opção: ").strip()
    try:
        if opcao == "1":
            patrimonio = input("Patrimônio: ").strip().upper()
            descricao = input("Descrição: ").strip()
            prioridade = int(input("Prioridade (1 a 3): ").strip())
            if prioridade not in (1, 2, 3):
                print("Prioridade inválida.")
            else:
                print("Atendimento #", cadastrar(patrimonio, descricao, prioridade), "cadastrado.")
        elif opcao == "2":
            for item in listar(): print(item)
        elif opcao == "3":
            print(buscar(int(input("ID: ").strip())))
        elif opcao == "4":
            for item in filtrar_estado(input("Estado: ")): print(item)
        elif opcao == "5":
            print(resumo())
        elif opcao == "6":
            atualizar_prioridade(int(input("ID: ").strip()), int(input("Nova prioridade: ").strip()))
        elif opcao == "7":
            concluir(int(input("ID: ").strip()))
        elif opcao != "0":
            print("Opção inválida.")
    except ValueError as erro:
        print("Entrada inválida:", erro)
