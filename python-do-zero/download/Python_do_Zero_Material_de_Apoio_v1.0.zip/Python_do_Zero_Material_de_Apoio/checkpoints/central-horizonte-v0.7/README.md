# Central Horizonte 0.7

Checkpoint do capítulo **13** de *Python do Zero — Mundo bit Byte*.

## O que esta versão representa

SQLite e CRUD. Este diretório é uma fotografia funcional do projeto naquele ponto da leitura; ele serve para conferência, retomada ou continuidade, não para substituir a construção proposta no capítulo.

## Como executar

1. Abra o terminal nesta pasta.
2. Use Python 3.10 ou superior.
3. Execute `python central.py`.

## Experimento de transação

Em uma base temporária e fictícia, execute `python scripts/testar_rollback.py`. O roteiro provoca uma falha entre duas escritas da mesma transação. O resultado correto informa os mesmos valores antes e depois e termina com `rollback confirmado`.

## Dados de prática

Use somente dados fictícios nos experimentos. Os exemplos NB-07, PC-12 e IMP-03 usados no livro são fictícios.

## Continuidade

Cada checkpoint preserva o repertório conquistado até aqui. Em migrações, mantenha a versão anterior intacta e trabalhe sempre sobre uma cópia da base.
