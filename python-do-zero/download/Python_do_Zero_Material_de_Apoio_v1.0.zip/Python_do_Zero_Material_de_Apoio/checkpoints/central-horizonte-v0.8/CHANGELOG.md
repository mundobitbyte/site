# CHANGELOG

## 0.8 — 2026-09-14

### Adicionado
- relaciona equipamentos e atendimentos
- mede dias usando datas ISO
- exporta CSV e lê JSON
- inclui base fictícia migrada para conferência isolada do checkpoint

### Limitações conhecidas
- estruturas procedurais ainda circulam entre interface e banco

### Migração
Evolução documentada a partir da 0.7; a versão anterior não é alterada.
