"""Migração real de uma cópia da estrutura 0.7 para a 0.8."""
import shutil
import sqlite3
from datetime import date
from pathlib import Path

RAIZ = Path(__file__).resolve().parents[1]
ORIGEM_PADRAO = RAIZ.parent / "central-horizonte-v0.7" / "dados" / "horizonte.db"
DESTINO_PADRAO = RAIZ / "dados" / "horizonte.db"


def migrar(origem=ORIGEM_PADRAO, destino=DESTINO_PADRAO):
    origem = Path(origem)
    destino = Path(destino)
    if not origem.exists():
        raise FileNotFoundError(f"Base 0.7 não encontrada: {origem}")
    destino.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(origem, destino)

    conexao = sqlite3.connect(destino)
    conexao.row_factory = sqlite3.Row
    try:
        antes = conexao.execute("SELECT COUNT(*) FROM atendimento").fetchone()[0]
        antigas = conexao.execute("SELECT id, patrimonio, descricao, prioridade, estado FROM atendimento ORDER BY id").fetchall()
        conexao.execute("PRAGMA foreign_keys = OFF")
        conexao.execute("ALTER TABLE atendimento RENAME TO atendimento_v07")
        conexao.executescript("""
            CREATE TABLE equipamento (
                id INTEGER PRIMARY KEY,
                patrimonio TEXT NOT NULL UNIQUE,
                tipo TEXT NOT NULL
            );
            CREATE TABLE atendimento (
                id INTEGER PRIMARY KEY,
                equipamento_id INTEGER NOT NULL,
                descricao TEXT NOT NULL,
                prioridade INTEGER NOT NULL CHECK (prioridade BETWEEN 1 AND 3),
                estado TEXT NOT NULL DEFAULT 'aberto',
                aberto_em TEXT NOT NULL,
                FOREIGN KEY (equipamento_id) REFERENCES equipamento(id)
            );
        """)
        patrimonio_para_id = {}
        for linha in antigas:
            patrimonio = linha["patrimonio"].strip().upper()
            if patrimonio not in patrimonio_para_id:
                cursor = conexao.execute("INSERT INTO equipamento (patrimonio, tipo) VALUES (?, ?)", (patrimonio, "não informado"))
                patrimonio_para_id[patrimonio] = cursor.lastrowid
            conexao.execute("""
                INSERT INTO atendimento (id, equipamento_id, descricao, prioridade, estado, aberto_em)
                VALUES (?, ?, ?, ?, ?, ?)
            """, (linha["id"], patrimonio_para_id[patrimonio], linha["descricao"], linha["prioridade"], linha["estado"], date.today().isoformat()))
        conexao.execute("DROP TABLE atendimento_v07")
        conexao.commit()
        depois = conexao.execute("SELECT COUNT(*) FROM atendimento").fetchone()[0]
        equipamentos = conexao.execute("SELECT COUNT(*) FROM equipamento").fetchone()[0]
        if depois != antes:
            raise RuntimeError("Contagem de atendimentos mudou durante a migração.")
        return {"atendimentos_antes": antes, "atendimentos_depois": depois, "equipamentos": equipamentos}
    except Exception:
        conexao.rollback()
        raise
    finally:
        conexao.close()


if __name__ == "__main__":
    print(migrar())
