"""Verifica configuração JSON e exportação CSV do checkpoint 0.8."""
import csv
import sys
from pathlib import Path


RAIZ = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(RAIZ))

from horizonte.equipamentos import carregar_config, exportar_csv  # noqa: E402


config = carregar_config(RAIZ / "config.json")
destino = RAIZ / config["exportacao"]
quantidade = exportar_csv(destino)

with destino.open(newline="", encoding="utf-8") as arquivo:
    linhas = list(csv.reader(arquivo))

print("Arquivo configurado:", config["exportacao"])
print("Cabeçalho:", " | ".join(linhas[0]))
print("Registros:", quantidade)
assert len(linhas) == quantidade + 1
print("CSV e JSON verificados")
