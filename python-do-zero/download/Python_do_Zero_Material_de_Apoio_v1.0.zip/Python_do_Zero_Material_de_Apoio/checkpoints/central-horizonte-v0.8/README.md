# Central Horizonte 0.8

Checkpoint do capítulo **15** de *Python do Zero — Mundo bit Byte*.

## O que esta versão representa

Relações, datas, consultas, CSV e JSON. Este diretório é uma fotografia funcional do projeto naquele ponto da leitura; ele serve para conferência, retomada ou continuidade, não para substituir a construção proposta no capítulo.

## Como executar

1. Abra o terminal nesta pasta.
2. Use Python 3.10 ou superior.
3. Execute `python central.py`.

Esta pasta já inclui uma base fictícia migrada, portanto o checkpoint pode ser aberto e conferido isoladamente. Para praticar a migração proposta no livro, trabalhe sobre uma cópia da base do checkpoint 0.7 e execute `python scripts/migrar_v07_v08.py`; o script recria a base 0.8 a partir dessa cópia.

## Dados de prática

Use somente dados fictícios nos experimentos. Os exemplos NB-07, PC-12 e IMP-03 usados no livro são fictícios.

## Continuidade

Cada checkpoint preserva o repertório conquistado até aqui. Em migrações, mantenha a versão anterior intacta e trabalhe sempre sobre uma cópia da base.
