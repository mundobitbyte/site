from datetime import date
from horizonte.equipamentos import BANCO, dias_em_aberto, exportar_csv, listar, RAIZ

print("Central Horizonte - versão 0.8")
if not BANCO.exists():
    print("Execute primeiro scripts/migrar_v07_v08.py sobre uma cópia da base 0.7.")
else:
    for item in listar():
        dias = dias_em_aberto(item["aberto_em"], date(2026, 9, 14)) if item["estado"] == "aberto" else "-"
        print(f"{item['patrimonio']} | {item['estado']} | dias em aberto: {dias}")
    destino = RAIZ / "atendimentos.csv"
    print(f"{exportar_csv(destino)} linhas exportadas para {destino.name}.")
