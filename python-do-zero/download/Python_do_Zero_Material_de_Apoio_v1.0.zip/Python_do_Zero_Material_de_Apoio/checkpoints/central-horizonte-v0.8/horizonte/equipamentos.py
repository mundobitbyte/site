import csv
import json
import sqlite3
from datetime import date, datetime
from pathlib import Path

RAIZ = Path(__file__).resolve().parent.parent
BANCO = RAIZ / "dados" / "horizonte.db"


def conectar(caminho=BANCO):
    caminho = Path(caminho)
    caminho.parent.mkdir(parents=True, exist_ok=True)
    conexao = sqlite3.connect(caminho)
    conexao.row_factory = sqlite3.Row
    conexao.execute("PRAGMA foreign_keys = ON")
    return conexao


def inicializar(caminho=BANCO):
    conexao = conectar(caminho)
    conexao.executescript("""
        CREATE TABLE IF NOT EXISTS equipamento (
            id INTEGER PRIMARY KEY,
            patrimonio TEXT NOT NULL UNIQUE,
            tipo TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS atendimento (
            id INTEGER PRIMARY KEY,
            equipamento_id INTEGER NOT NULL,
            descricao TEXT NOT NULL,
            prioridade INTEGER NOT NULL CHECK (prioridade BETWEEN 1 AND 3),
            estado TEXT NOT NULL DEFAULT 'aberto',
            aberto_em TEXT NOT NULL,
            FOREIGN KEY (equipamento_id) REFERENCES equipamento(id)
        );
    """)
    conexao.commit()
    conexao.close()


def listar(caminho=BANCO):
    conexao = conectar(caminho)
    linhas = conexao.execute("""
        SELECT a.id, e.patrimonio, e.tipo, a.descricao,
               a.prioridade, a.estado, a.aberto_em
        FROM atendimento AS a
        JOIN equipamento AS e ON e.id = a.equipamento_id
        ORDER BY a.prioridade, a.id
    """).fetchall()
    conexao.close()

    resultado = []
    for linha in linhas:
        resultado.append(dict(linha))
    return resultado


def dias_em_aberto(texto_iso, hoje=None):
    inicio = date.fromisoformat(texto_iso)
    if hoje is None:
        referencia = date.today()
    else:
        referencia = hoje
    return (referencia - inicio).days


def exportar_csv(destino, caminho=BANCO):
    linhas = listar(caminho)
    if not linhas:
        return 0

    with open(destino, "w", newline="", encoding="utf-8") as arquivo:
        escritor = csv.DictWriter(arquivo, fieldnames=linhas[0].keys())
        escritor.writeheader()
        escritor.writerows(linhas)
    return len(linhas)


def carregar_config(caminho=None):
    if caminho is None:
        alvo = RAIZ / "config.json"
    else:
        alvo = Path(caminho)
    return json.loads(alvo.read_text(encoding="utf-8"))


def instante_iso():
    return datetime.now().isoformat(timespec="seconds")
