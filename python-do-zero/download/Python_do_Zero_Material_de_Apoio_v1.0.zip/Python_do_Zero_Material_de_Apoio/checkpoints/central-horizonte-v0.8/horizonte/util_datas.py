from datetime import date

def dias_em_aberto(texto_iso, hoje=None):
    return ((hoje or date.today()) - date.fromisoformat(texto_iso)).days
