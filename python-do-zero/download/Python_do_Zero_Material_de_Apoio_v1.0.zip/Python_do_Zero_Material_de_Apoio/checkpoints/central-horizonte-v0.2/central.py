print("Central Horizonte")
print("Versão 0.2")
print()

patrimonio = input("Patrimônio: ").strip().upper()
descricao = input("Descrição: ").strip()
prioridade = int(input("Prioridade (1 a 3): ").strip())
estado = input("Estado: ").strip().lower()

print(f"{patrimonio} | {descricao} | prioridade {prioridade} | {estado}")
