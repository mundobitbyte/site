# Roteiro manual

1. Cadastre ` NB-07 `, `Não Liga`, `1`, `ABERTO`.
2. Confirme a normalização.
3. Repita e informe `alta` como prioridade; confirme a mensagem de erro.
