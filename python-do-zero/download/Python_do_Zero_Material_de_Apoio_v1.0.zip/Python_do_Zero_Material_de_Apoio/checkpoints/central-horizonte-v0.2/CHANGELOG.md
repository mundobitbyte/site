# CHANGELOG

## 0.2 — 2026-09-14

### Adicionado
- recebe um atendimento com input
- normaliza textos
- converte prioridade e informa ValueError

### Limitações conhecidas
- executa um cadastro e encerra
- não conserva dados

### Migração
Evolução documentada a partir da 0.1; a versão anterior não é alterada.
