# CHANGELOG

## 0.6 — 2026-09-14

### Adicionado
- trata ValueError no limite da entrada
- preserva traceback de falhas inesperadas
- registra casos manuais

### Limitações conhecidas
- ainda não há unittest
- dados continuam em memória

### Migração
Evolução documentada a partir da 0.5; a versão anterior não é alterada.
