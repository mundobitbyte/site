# Diário de diagnóstico

- Reprodução: prioridade recebeu `alta`.
- Evidência: `ValueError` na conversão para `int`.
- Hipótese: a entrada do terminal é texto.
- Correção: capturar `ValueError` no limite da entrada.
- Reteste: entrada inválida informa o problema; casos anteriores continuam funcionando.
