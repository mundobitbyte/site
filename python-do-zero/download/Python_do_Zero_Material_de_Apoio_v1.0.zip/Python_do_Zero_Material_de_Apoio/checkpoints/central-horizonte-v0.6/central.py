from horizonte.atendimentos import ATENDIMENTOS_EXEMPLO
from horizonte.consultas import buscar, filtrar, ordenar
from horizonte.regras import normalizar_descricao, normalizar_patrimonio, prioridade_valida
from horizonte.relatorios import resumo


def copiar_exemplos():
    copia = []
    for item in ATENDIMENTOS_EXEMPLO:
        copia.append(item.copy())
    return copia


def executar_central():
    atendimentos = copiar_exemplos()
    print("Central Horizonte - versão 0.6")
    opcao = ""
    while opcao != "0":
        print("\n1-Cadastrar 2-Listar 3-Buscar 4-Filtrar 5-Resumo 0-Sair")
        opcao = input("Opção: ").strip()
        if opcao == "1":
            patrimonio = normalizar_patrimonio(input("Patrimônio: "))
            descricao = normalizar_descricao(input("Descrição: "))
            try:
                prioridade = int(input("Prioridade (1 a 3): ").strip())
            except ValueError:
                print("A prioridade precisa ser um número inteiro.")
                continue
            if not prioridade_valida(prioridade):
                print("Prioridade inválida. Use 1, 2 ou 3.")
                continue
            atendimentos.append({"patrimonio": patrimonio, "descricao": descricao, "prioridade": prioridade, "estado": "aberto"})
            print("Atendimento cadastrado.")
        elif opcao == "2":
            for item in ordenar(atendimentos): print(item)
        elif opcao == "3":
            encontrado = buscar(atendimentos, input("Patrimônio: "))
            print(encontrado if encontrado is not None else "Patrimônio não encontrado.")
        elif opcao == "4":
            for item in filtrar(atendimentos, input("Estado: ").strip().lower()): print(item)
        elif opcao == "5":
            print(resumo(atendimentos))
        elif opcao != "0":
            print("Opção inválida.")


executar_central()
