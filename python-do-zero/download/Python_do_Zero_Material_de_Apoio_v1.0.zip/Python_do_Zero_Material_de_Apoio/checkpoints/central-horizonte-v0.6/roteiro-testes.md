# Roteiro manual

1. Execute o caso válido NB-07.
2. Informe `alta` como prioridade.
3. Busque patrimônio ausente.
4. Registre esperado, obtido e reteste.
