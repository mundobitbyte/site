# CHANGELOG

## 0.9 — 2026-09-14

### Adicionado
- representa dados com dataclasses
- separa serviço e repositório
- mantém a CLI

### Limitações conhecidas
- a interface continua no terminal

### Migração
Evolução documentada a partir da 0.8; a versão anterior não é alterada.
