# Central Horizonte 0.9

Checkpoint do capítulo **16** de *Python do Zero — Mundo bit Byte*.

## O que esta versão representa

Objetos, serviço e repositório. Este diretório é uma fotografia funcional do projeto naquele ponto da leitura; ele serve para conferência, retomada ou continuidade, não para substituir a construção proposta no capítulo.

## Como executar

1. Abra o terminal nesta pasta.
2. Use Python 3.10 ou superior.
3. Execute `python central.py`.

## Onde fica cada parte

- `horizonte/modelos.py` representa os dados;
- `horizonte/repositorio.py` contém o acesso ao SQLite;
- `horizonte/servicos.py` contém regras e casos de uso;
- `central.py` mantém a interface de terminal e faz a composição.

Para acompanhar a passagem da 0.8 para a 0.9, compare um arquivo por vez e execute novamente depois de cada comparação.

## Dados de prática

Use somente dados fictícios nos experimentos. Os exemplos NB-07, PC-12 e IMP-03 usados no livro são fictícios.

## Continuidade

Cada checkpoint preserva o repertório conquistado até aqui. Em migrações, mantenha a versão anterior intacta e trabalhe sempre sobre uma cópia da base.
