import sqlite3

from horizonte.repositorio import Repositorio
from horizonte.servicos import ServicoCentral


def construir(caminho=None):
    servico = ServicoCentral(Repositorio(caminho))
    servico.preparar()
    return servico


def executar(caminho=None):
    servico = construir(caminho)
    print("Central Horizonte")
    opcao = ""
    while opcao != "0":
        print("\n1-Equipamento 2-Atendimento 3-Listar atendimentos")
        print("4-Concluir 5-Mudar prioridade 0-Sair")
        opcao = input("Opção: ").strip()

        try:
            if opcao == "1":
                novo_id = servico.cadastrar_equipamento(
                    input("Patrimônio: "),
                    input("Tipo: "),
                )
                print("Equipamento #", novo_id)

            elif opcao == "2":
                novo_id = servico.abrir_atendimento(
                    int(input("ID equipamento: ")),
                    input("Descrição: "),
                    int(input("Prioridade: ")),
                )
                print("Atendimento #", novo_id)

            elif opcao == "3":
                for item in servico.listar_atendimentos():
                    print(item)

            elif opcao == "4":
                servico.concluir_atendimento(int(input("ID atendimento: ")))

            elif opcao == "5":
                servico.alterar_prioridade(
                    int(input("ID atendimento: ")),
                    int(input("Nova prioridade: ")),
                )

            elif opcao != "0":
                print("Opção inválida.")

        except ValueError as erro:
            print("Entrada ou regra inválida:", erro)
        except sqlite3.IntegrityError as erro:
            print("O banco recusou a operação:", erro)


if __name__ == "__main__":
    executar()
