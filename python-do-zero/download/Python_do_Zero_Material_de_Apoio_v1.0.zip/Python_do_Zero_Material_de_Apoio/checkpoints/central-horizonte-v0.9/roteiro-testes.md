# Dois movimentos

1. Converta uma linha em Atendimento e confira atributos.
2. Confirme que a CLI chama o serviço e que somente o repositório contém SQL.
