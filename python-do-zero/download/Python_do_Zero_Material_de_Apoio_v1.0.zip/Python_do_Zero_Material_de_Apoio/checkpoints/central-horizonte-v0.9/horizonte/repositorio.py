import sqlite3
from pathlib import Path

from .modelos import Atendimento, Equipamento


class Repositorio:
    def __init__(self, caminho=None):
        if caminho is None:
            self.caminho = Path(__file__).resolve().parent.parent / "dados" / "horizonte.db"
        else:
            self.caminho = Path(caminho)
        self.caminho.parent.mkdir(parents=True, exist_ok=True)

    def conectar(self):
        conexao = sqlite3.connect(self.caminho)
        conexao.row_factory = sqlite3.Row
        conexao.execute("PRAGMA foreign_keys = ON")
        return conexao

    def inicializar(self):
        conexao = self.conectar()
        conexao.executescript("""
            CREATE TABLE IF NOT EXISTS equipamento (
                id INTEGER PRIMARY KEY,
                patrimonio TEXT NOT NULL UNIQUE,
                tipo TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS atendimento (
                id INTEGER PRIMARY KEY,
                equipamento_id INTEGER NOT NULL,
                descricao TEXT NOT NULL,
                prioridade INTEGER NOT NULL CHECK (prioridade BETWEEN 1 AND 3),
                estado TEXT NOT NULL DEFAULT 'aberto',
                aberto_em TEXT NOT NULL,
                FOREIGN KEY (equipamento_id) REFERENCES equipamento(id)
            );
        """)
        conexao.commit()
        conexao.close()

    def cadastrar_equipamento(self, patrimonio, tipo):
        conexao = self.conectar()
        cursor = conexao.execute(
            "INSERT INTO equipamento (patrimonio, tipo) VALUES (?, ?)",
            (patrimonio, tipo),
        )
        conexao.commit()
        novo_id = cursor.lastrowid
        conexao.close()
        return novo_id

    def listar_equipamentos(self):
        conexao = self.conectar()
        linhas = conexao.execute(
            "SELECT id, patrimonio, tipo FROM equipamento ORDER BY patrimonio"
        ).fetchall()
        conexao.close()

        resultado = []
        for linha in linhas:
            resultado.append(Equipamento(**dict(linha)))
        return resultado

    def obter_equipamento(self, equipamento_id):
        conexao = self.conectar()
        linha = conexao.execute(
            "SELECT id, patrimonio, tipo FROM equipamento WHERE id = ?",
            (equipamento_id,),
        ).fetchone()
        conexao.close()
        if linha is None:
            return None
        return Equipamento(**dict(linha))

    def cadastrar_atendimento(self, equipamento_id, descricao, prioridade, aberto_em):
        conexao = self.conectar()
        cursor = conexao.execute("""
            INSERT INTO atendimento
            (equipamento_id, descricao, prioridade, estado, aberto_em)
            VALUES (?, ?, ?, 'aberto', ?)
        """, (equipamento_id, descricao, prioridade, aberto_em))
        conexao.commit()
        novo_id = cursor.lastrowid
        conexao.close()
        return novo_id

    def listar_atendimentos(self, estado=None):
        conexao = self.conectar()
        sql = """
            SELECT a.id, a.equipamento_id, e.patrimonio, a.descricao,
                   a.prioridade, a.estado, a.aberto_em
            FROM atendimento AS a
            JOIN equipamento AS e ON e.id = a.equipamento_id
        """
        parametros = ()
        if estado is not None:
            sql = sql + " WHERE a.estado = ?"
            parametros = (estado,)
        sql = sql + " ORDER BY a.prioridade, a.id"

        linhas = conexao.execute(sql, parametros).fetchall()
        conexao.close()

        resultado = []
        for linha in linhas:
            resultado.append(Atendimento(**dict(linha)))
        return resultado

    def atualizar_prioridade(self, atendimento_id, prioridade):
        conexao = self.conectar()
        cursor = conexao.execute(
            "UPDATE atendimento SET prioridade = ? WHERE id = ?",
            (prioridade, atendimento_id),
        )
        conexao.commit()
        quantidade = cursor.rowcount
        conexao.close()
        return quantidade

    def concluir_atendimento(self, atendimento_id):
        conexao = self.conectar()
        cursor = conexao.execute(
            "UPDATE atendimento SET estado = 'concluído' WHERE id = ?",
            (atendimento_id,),
        )
        conexao.commit()
        quantidade = cursor.rowcount
        conexao.close()
        return quantidade
