from datetime import date


class ServicoCentral:
    def __init__(self, repositorio):
        self.repositorio = repositorio

    def preparar(self):
        self.repositorio.inicializar()

    def cadastrar_equipamento(self, patrimonio, tipo):
        patrimonio = patrimonio.strip().upper()
        tipo = tipo.strip().lower()
        if not patrimonio:
            raise ValueError("Patrimônio é obrigatório.")
        if not tipo:
            raise ValueError("Tipo é obrigatório.")
        return self.repositorio.cadastrar_equipamento(patrimonio, tipo)

    def abrir_atendimento(self, equipamento_id, descricao, prioridade, aberto_em=None):
        if self.repositorio.obter_equipamento(equipamento_id) is None:
            raise ValueError("Equipamento inexistente.")
        if prioridade not in (1, 2, 3):
            raise ValueError("Prioridade deve estar entre 1 e 3.")
        descricao = descricao.strip()
        if not descricao:
            raise ValueError("Descrição é obrigatória.")
        if aberto_em is None:
            aberto_em = date.today().isoformat()
        return self.repositorio.cadastrar_atendimento(
            equipamento_id,
            descricao,
            prioridade,
            aberto_em,
        )

    def listar_atendimentos(self, estado=None):
        return self.repositorio.listar_atendimentos(estado)

    def listar_equipamentos(self):
        return self.repositorio.listar_equipamentos()

    def alterar_prioridade(self, atendimento_id, prioridade):
        if prioridade not in (1, 2, 3):
            raise ValueError("Prioridade deve estar entre 1 e 3.")
        quantidade = self.repositorio.atualizar_prioridade(atendimento_id, prioridade)
        if quantidade != 1:
            raise ValueError("Atendimento inexistente.")

    def concluir_atendimento(self, atendimento_id):
        quantidade = self.repositorio.concluir_atendimento(atendimento_id)
        if quantidade != 1:
            raise ValueError("Atendimento inexistente.")
