from dataclasses import dataclass


@dataclass(frozen=True)
class Equipamento:
    id: int | None
    patrimonio: str
    tipo: str


@dataclass(frozen=True)
class Atendimento:
    id: int | None
    equipamento_id: int
    patrimonio: str
    descricao: str
    prioridade: int
    estado: str
    aberto_em: str
