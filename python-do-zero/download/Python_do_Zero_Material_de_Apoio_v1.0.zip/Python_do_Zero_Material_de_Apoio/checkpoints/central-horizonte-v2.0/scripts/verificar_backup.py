"""Executa backup e restauração 2.0 somente em diretório temporário."""
import json
import sqlite3
import sys
import tempfile
from pathlib import Path


RAIZ = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(RAIZ))

from horizonte.backup import criar, hash_arquivo, restaurar  # noqa: E402
from horizonte.repositorio import Repositorio  # noqa: E402
from horizonte.servicos import ServicoCentral  # noqa: E402


with tempfile.TemporaryDirectory() as pasta:
    laboratorio = Path(pasta)
    origem = laboratorio / "origem" / "horizonte.db"
    servico = ServicoCentral(Repositorio(origem))
    servico.preparar()
    equipamento_id = servico.cadastrar_equipamento("NB-07", "notebook")
    servico.abrir_atendimento(equipamento_id, "não liga", 1, "2026-09-01")
    pessoa_id = servico.cadastrar_pessoa("Ana")
    servico.retirar(pessoa_id, equipamento_id, "2026-09-01", "2026-09-08")

    backup = criar(origem, laboratorio / "backups")
    restaurado = restaurar(backup, laboratorio / "restaurado")
    manifesto = json.loads(backup.with_suffix(".json").read_text(encoding="utf-8"))

    repo = Repositorio(restaurado)
    contagens = (
        len(repo.listar_equipamentos()),
        len(repo.listar_atendimentos()),
        len(repo.listar_pessoas()),
        len(repo.listar_emprestimos()),
    )
    with sqlite3.connect(restaurado) as conexao:
        falhas_fk = conexao.execute("PRAGMA foreign_key_check").fetchall()

    assert hash_arquivo(backup) == hash_arquivo(restaurado) == manifesto["sha256"]
    assert contagens == (1, 1, 1, 1)
    assert falhas_fk == []

    print("Backup:", backup.name)
    print("Manifesto: tamanho e SHA-256 conferidos")
    print("Restauração: 1 equipamento; 1 atendimento; 1 pessoa; 1 empréstimo")
    print("foreign_key_check: vazio")
    print("backup e restauração 2.0 verificados")
