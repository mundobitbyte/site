"""Amplia uma CÓPIA da base 1.2 preservando atendimento e equipamento."""
import shutil
import sqlite3
from pathlib import Path

RAIZ=Path(__file__).resolve().parents[1]
ORIGEM_PADRAO=RAIZ.parent/"central-horizonte-v1.2"/"dados"/"horizonte.db"
DESTINO_PADRAO=RAIZ/"dados"/"horizonte.db"


def migrar(origem=ORIGEM_PADRAO,destino=DESTINO_PADRAO):
    origem=Path(origem); destino=Path(destino)
    if not origem.exists(): raise FileNotFoundError(f"Base 1.2 não encontrada: {origem}")
    destino.parent.mkdir(parents=True,exist_ok=True); shutil.copy2(origem,destino)
    c=sqlite3.connect(destino)
    try:
        antes_at=c.execute("SELECT COUNT(*) FROM atendimento").fetchone()[0]
        antes_eq=c.execute("SELECT COUNT(*) FROM equipamento").fetchone()[0]
        c.executescript("""
        CREATE TABLE IF NOT EXISTS pessoa(id INTEGER PRIMARY KEY,nome TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS emprestimo(id INTEGER PRIMARY KEY,pessoa_id INTEGER NOT NULL,equipamento_id INTEGER NOT NULL,retirado_em TEXT NOT NULL,previsto_para TEXT NOT NULL,devolvido_em TEXT,FOREIGN KEY(pessoa_id) REFERENCES pessoa(id),FOREIGN KEY(equipamento_id) REFERENCES equipamento(id));
        """); c.commit()
        depois_at=c.execute("SELECT COUNT(*) FROM atendimento").fetchone()[0]
        depois_eq=c.execute("SELECT COUNT(*) FROM equipamento").fetchone()[0]
        if (antes_at,antes_eq)!=(depois_at,depois_eq): raise RuntimeError("Dados anteriores não foram preservados.")
        return {"atendimentos":depois_at,"equipamentos":depois_eq,"novas_tabelas":["pessoa","emprestimo"]}
    except Exception:
        c.rollback(); raise
    finally: c.close()

if __name__=="__main__": print(migrar())
