# CHANGELOG

## 2.0 — 2026-09-14

### Adicionado
- modela Pessoa e Empréstimo
- impede dois empréstimos abertos
- registra retirada, previsão, devolução e atraso
- trata ausência como SQLite NULL e Python None
- rejeita devolução anterior à data de retirada
- a GUI informa o ID da pessoa cadastrada e o preenche no formulário de empréstimo
- backup e restauração preservam e verificam as quatro entidades do domínio 2.0

### Limitações conhecidas
- extensões de nuvem, autenticação e rede não fazem parte do escopo

### Migração
Evolução documentada a partir da 1.2; a versão anterior não é alterada.
