import tempfile
import unittest
from datetime import date
from pathlib import Path
from horizonte.repositorio import Repositorio
from horizonte.servicos import ServicoCentral

class TestCentral20(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory(); self.db=Path(self.tmp.name)/"teste.db"
        self.repo=Repositorio(self.db); self.serv=ServicoCentral(self.repo); self.serv.preparar()
        self.eid=self.serv.cadastrar_equipamento("NB-07","notebook")
        self.aid=self.serv.abrir_atendimento(self.eid,"Não liga",1,"2026-09-01")
        self.pid=self.serv.cadastrar_pessoa("Ana")
    def tearDown(self): self.tmp.cleanup()
    def test_suporte_permanece(self):
        self.assertEqual(len(self.serv.listar_atendimentos()),1)
        self.serv.concluir_atendimento(self.aid); self.assertEqual(self.serv.listar_atendimentos()[0].estado,"concluído")
    def test_devolucao_nao_pode_anteceder_retirada(self):
        emp = self.serv.retirar(self.pid, self.eid, "2026-09-10", "2026-09-17")
        with self.assertRaises(ValueError):
            self.serv.devolver(emp, "2026-09-01")

    def test_conflito_e_devolucao(self):
        emp=self.serv.retirar(self.pid,self.eid,"2026-09-01","2026-09-08")
        with self.assertRaises(ValueError): self.serv.retirar(self.pid,self.eid,"2026-09-02","2026-09-09")
        self.assertEqual(len(self.serv.atrasados(date(2026,9,14))),1)
        self.serv.devolver(emp,"2026-09-14"); self.assertEqual(len(self.serv.atrasados(date(2026,9,14))),0)
if __name__=="__main__": unittest.main()
