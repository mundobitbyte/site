import sqlite3
import tkinter as tk
from tkinter import messagebox, ttk

from horizonte.repositorio import Repositorio
from horizonte.servicos import ServicoCentral


class JanelaCentral20(tk.Tk):
    def __init__(self, caminho=None):
        super().__init__()
        self.title("Central Horizonte 2.0")
        self.geometry("1080x650")
        self.repositorio = Repositorio(caminho)
        self.servico = ServicoCentral(self.repositorio)
        self.servico.preparar()
        self._montar()
        self.atualizar_tudo()

    def _montar(self):
        abas = ttk.Notebook(self)
        abas.pack(fill="both", expand=True, padx=12, pady=12)

        self.aba_equipamentos = ttk.Frame(abas, padding=10)
        self.aba_atendimentos = ttk.Frame(abas, padding=10)
        self.aba_emprestimos = ttk.Frame(abas, padding=10)
        abas.add(self.aba_equipamentos, text="Equipamentos")
        abas.add(self.aba_atendimentos, text="Atendimentos")
        abas.add(self.aba_emprestimos, text="Empréstimos")

        self._montar_equipamentos()
        self._montar_atendimentos()
        self._montar_emprestimos()

    def _montar_equipamentos(self):
        self.patrimonio = tk.StringVar()
        self.tipo = tk.StringVar(value="notebook")
        ttk.Label(self.aba_equipamentos, text="Patrimônio").grid(row=0, column=0, sticky="w")
        ttk.Entry(self.aba_equipamentos, textvariable=self.patrimonio).grid(row=1, column=0, sticky="ew")
        ttk.Label(self.aba_equipamentos, text="Tipo").grid(row=0, column=1, sticky="w")
        ttk.Entry(self.aba_equipamentos, textvariable=self.tipo).grid(row=1, column=1, sticky="ew")
        ttk.Button(self.aba_equipamentos, text="Cadastrar", command=self.cadastrar_equipamento).grid(row=1, column=2, padx=8)
        self.tabela_equipamentos = ttk.Treeview(
            self.aba_equipamentos,
            columns=("id", "patrimonio", "tipo"),
            show="headings",
        )
        for coluna, titulo in (("id", "ID"), ("patrimonio", "Patrimônio"), ("tipo", "Tipo")):
            self.tabela_equipamentos.heading(coluna, text=titulo)
        self.tabela_equipamentos.grid(row=2, column=0, columnspan=3, pady=12, sticky="nsew")
        self.aba_equipamentos.columnconfigure(0, weight=1)
        self.aba_equipamentos.columnconfigure(1, weight=1)
        self.aba_equipamentos.rowconfigure(2, weight=1)

    def _montar_atendimentos(self):
        self.at_equipamento_id = tk.StringVar()
        self.at_descricao = tk.StringVar()
        self.at_prioridade = tk.StringVar(value="2")
        ttk.Label(self.aba_atendimentos, text="ID equipamento").grid(row=0, column=0, sticky="w")
        ttk.Entry(self.aba_atendimentos, textvariable=self.at_equipamento_id).grid(row=1, column=0, sticky="ew")
        ttk.Label(self.aba_atendimentos, text="Descrição").grid(row=0, column=1, sticky="w")
        ttk.Entry(self.aba_atendimentos, textvariable=self.at_descricao).grid(row=1, column=1, sticky="ew")
        ttk.Label(self.aba_atendimentos, text="Prioridade").grid(row=0, column=2, sticky="w")
        ttk.Entry(self.aba_atendimentos, textvariable=self.at_prioridade, width=8).grid(row=1, column=2, sticky="w")
        ttk.Button(self.aba_atendimentos, text="Abrir", command=self.abrir_atendimento).grid(row=1, column=3, padx=8)
        self.tabela_atendimentos = ttk.Treeview(
            self.aba_atendimentos,
            columns=("id", "patrimonio", "descricao", "prioridade", "estado"),
            show="headings",
        )
        for coluna, titulo in (
            ("id", "ID"), ("patrimonio", "Patrimônio"), ("descricao", "Descrição"),
            ("prioridade", "Prioridade"), ("estado", "Estado"),
        ):
            self.tabela_atendimentos.heading(coluna, text=titulo)
        self.tabela_atendimentos.grid(row=2, column=0, columnspan=4, pady=12, sticky="nsew")
        ttk.Button(self.aba_atendimentos, text="Concluir", command=self.concluir_atendimento).grid(row=3, column=0, sticky="w")
        ttk.Button(self.aba_atendimentos, text="Prioridade 1", command=self.prioridade_1).grid(row=3, column=1, sticky="w")
        ttk.Button(self.aba_atendimentos, text="Prioridade 2", command=self.prioridade_2).grid(row=3, column=2, sticky="w")
        ttk.Button(self.aba_atendimentos, text="Prioridade 3", command=self.prioridade_3).grid(row=3, column=3, sticky="w")
        self.aba_atendimentos.columnconfigure(1, weight=1)
        self.aba_atendimentos.rowconfigure(2, weight=1)

    def _montar_emprestimos(self):
        self.pessoa_nome = tk.StringVar()
        self.emp_pessoa_id = tk.StringVar()
        self.emp_equipamento_id = tk.StringVar()
        self.emp_retirada = tk.StringVar()
        self.emp_previsao = tk.StringVar()
        ttk.Label(self.aba_emprestimos, text="Nova pessoa").grid(row=0, column=0, sticky="w")
        ttk.Entry(self.aba_emprestimos, textvariable=self.pessoa_nome).grid(row=1, column=0, sticky="ew")
        ttk.Button(self.aba_emprestimos, text="Cadastrar pessoa", command=self.cadastrar_pessoa).grid(row=1, column=1, sticky="w")
        ttk.Label(self.aba_emprestimos, text="ID pessoa").grid(row=2, column=0, sticky="w")
        ttk.Entry(self.aba_emprestimos, textvariable=self.emp_pessoa_id).grid(row=3, column=0, sticky="ew")
        ttk.Label(self.aba_emprestimos, text="ID equipamento").grid(row=2, column=1, sticky="w")
        ttk.Entry(self.aba_emprestimos, textvariable=self.emp_equipamento_id).grid(row=3, column=1, sticky="ew")
        ttk.Label(self.aba_emprestimos, text="Retirada AAAA-MM-DD").grid(row=2, column=2, sticky="w")
        ttk.Entry(self.aba_emprestimos, textvariable=self.emp_retirada).grid(row=3, column=2, sticky="ew")
        ttk.Label(self.aba_emprestimos, text="Previsão AAAA-MM-DD").grid(row=2, column=3, sticky="w")
        ttk.Entry(self.aba_emprestimos, textvariable=self.emp_previsao).grid(row=3, column=3, sticky="ew")
        ttk.Button(self.aba_emprestimos, text="Retirar", command=self.retirar).grid(row=3, column=4, padx=8)
        self.tabela_emprestimos = ttk.Treeview(
            self.aba_emprestimos,
            columns=("id", "pessoa", "equipamento", "retirada", "previsao", "devolucao"),
            show="headings",
        )
        for coluna, titulo in (
            ("id", "ID"), ("pessoa", "Pessoa"), ("equipamento", "Equipamento"),
            ("retirada", "Retirada"), ("previsao", "Previsão"), ("devolucao", "Devolução"),
        ):
            self.tabela_emprestimos.heading(coluna, text=titulo)
        self.tabela_emprestimos.grid(row=4, column=0, columnspan=5, pady=12, sticky="nsew")
        ttk.Button(self.aba_emprestimos, text="Devolver hoje", command=self.devolver_hoje).grid(row=5, column=0, sticky="w")
        self.aba_emprestimos.columnconfigure(0, weight=1)
        self.aba_emprestimos.columnconfigure(1, weight=1)
        self.aba_emprestimos.columnconfigure(2, weight=1)
        self.aba_emprestimos.columnconfigure(3, weight=1)
        self.aba_emprestimos.rowconfigure(4, weight=1)

    def _id_atendimento_selecionado(self):
        selecionados = self.tabela_atendimentos.selection()
        if not selecionados:
            raise ValueError("Selecione um atendimento.")
        return int(self.tabela_atendimentos.item(selecionados[0], "values")[0])

    def _id_emprestimo_selecionado(self):
        selecionados = self.tabela_emprestimos.selection()
        if not selecionados:
            raise ValueError("Selecione um empréstimo.")
        return int(self.tabela_emprestimos.item(selecionados[0], "values")[0])

    def cadastrar_equipamento(self):
        try:
            self.servico.cadastrar_equipamento(self.patrimonio.get(), self.tipo.get())
        except ValueError as erro:
            messagebox.showerror("Equipamento", str(erro)); return
        except sqlite3.IntegrityError:
            messagebox.showerror("Equipamento", "Patrimônio já cadastrado."); return
        self.patrimonio.set("")
        self.atualizar_tudo()

    def abrir_atendimento(self):
        try:
            self.servico.abrir_atendimento(
                int(self.at_equipamento_id.get()),
                self.at_descricao.get(),
                int(self.at_prioridade.get()),
            )
        except ValueError as erro:
            messagebox.showerror("Atendimento", str(erro)); return
        self.at_descricao.set("")
        self.atualizar_tudo()

    def concluir_atendimento(self):
        try:
            self.servico.concluir_atendimento(self._id_atendimento_selecionado())
        except ValueError as erro:
            messagebox.showerror("Atendimento", str(erro)); return
        self.atualizar_tudo()

    def _mudar_prioridade(self, prioridade):
        try:
            self.servico.alterar_prioridade(self._id_atendimento_selecionado(), prioridade)
        except ValueError as erro:
            messagebox.showerror("Atendimento", str(erro)); return
        self.atualizar_tudo()

    def prioridade_1(self): self._mudar_prioridade(1)
    def prioridade_2(self): self._mudar_prioridade(2)
    def prioridade_3(self): self._mudar_prioridade(3)

    def cadastrar_pessoa(self):
        try:
            novo_id = self.servico.cadastrar_pessoa(self.pessoa_nome.get())
        except ValueError as erro:
            messagebox.showerror("Pessoa", str(erro)); return
        self.pessoa_nome.set("")
        self.emp_pessoa_id.set(str(novo_id))
        messagebox.showinfo("Pessoa", f"Pessoa cadastrada com ID {novo_id}.")
        self.atualizar_tudo()

    def retirar(self):
        try:
            self.servico.retirar(
                int(self.emp_pessoa_id.get()),
                int(self.emp_equipamento_id.get()),
                self.emp_retirada.get(),
                self.emp_previsao.get(),
            )
        except (ValueError, sqlite3.IntegrityError) as erro:
            messagebox.showerror("Empréstimo", str(erro)); return
        self.atualizar_tudo()

    def devolver_hoje(self):
        from datetime import date
        try:
            self.servico.devolver(self._id_emprestimo_selecionado(), date.today().isoformat())
        except ValueError as erro:
            messagebox.showerror("Empréstimo", str(erro)); return
        self.atualizar_tudo()

    def atualizar_tudo(self):
        self.tabela_equipamentos.delete(*self.tabela_equipamentos.get_children())
        self.tabela_atendimentos.delete(*self.tabela_atendimentos.get_children())
        self.tabela_emprestimos.delete(*self.tabela_emprestimos.get_children())

        for equipamento in self.servico.listar_equipamentos():
            self.tabela_equipamentos.insert("", "end", values=(equipamento.id, equipamento.patrimonio, equipamento.tipo))
        for atendimento in self.servico.listar_atendimentos():
            self.tabela_atendimentos.insert("", "end", values=(atendimento.id, atendimento.patrimonio, atendimento.descricao, atendimento.prioridade, atendimento.estado))
        for emprestimo in self.servico.listar_emprestimos():
            if emprestimo.devolvido_em is None:
                devolucao = "Em aberto"
            else:
                devolucao = emprestimo.devolvido_em
            self.tabela_emprestimos.insert("", "end", values=(emprestimo.id, emprestimo.pessoa_nome, emprestimo.patrimonio, emprestimo.retirado_em, emprestimo.previsto_para, devolucao))


if __name__ == "__main__":
    JanelaCentral20().mainloop()
