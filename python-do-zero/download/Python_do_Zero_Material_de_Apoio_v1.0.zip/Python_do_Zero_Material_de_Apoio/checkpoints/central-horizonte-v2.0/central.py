import sqlite3

from horizonte.repositorio import Repositorio
from horizonte.servicos import ServicoCentral

repositorio = Repositorio()
servico = ServicoCentral(repositorio)
servico.preparar()

print("Central Horizonte 2.0 - suporte + empréstimos")
opcao = ""
while opcao != "0":
    print("\n1-Equipamento 2-Atendimento 3-Listar atendimentos")
    print("4-Pessoa 5-Retirar 6-Devolver 7-Listar empréstimos 0-Sair")
    opcao = input("Opção: ").strip()

    try:
        if opcao == "1":
            novo_id = servico.cadastrar_equipamento(
                input("Patrimônio: "),
                input("Tipo: "),
            )
            print("Equipamento #", novo_id)

        elif opcao == "2":
            novo_id = servico.abrir_atendimento(
                int(input("ID equipamento: ")),
                input("Descrição: "),
                int(input("Prioridade: ")),
            )
            print("Atendimento #", novo_id)

        elif opcao == "3":
            for atendimento in servico.listar_atendimentos():
                print(atendimento)

        elif opcao == "4":
            novo_id = servico.cadastrar_pessoa(input("Nome: "))
            print("Pessoa #", novo_id)

        elif opcao == "5":
            novo_id = servico.retirar(
                int(input("ID pessoa: ")),
                int(input("ID equipamento: ")),
                input("Retirada AAAA-MM-DD: "),
                input("Previsão AAAA-MM-DD: "),
            )
            print("Empréstimo #", novo_id)

        elif opcao == "6":
            servico.devolver(
                int(input("ID empréstimo: ")),
                input("Devolução AAAA-MM-DD: "),
            )

        elif opcao == "7":
            for emprestimo in servico.listar_emprestimos():
                print(emprestimo)

        elif opcao != "0":
            print("Opção inválida.")

    except ValueError as erro:
        print("Entrada ou regra inválida:", erro)
    except sqlite3.IntegrityError as erro:
        print("O banco recusou a operação:", erro)
