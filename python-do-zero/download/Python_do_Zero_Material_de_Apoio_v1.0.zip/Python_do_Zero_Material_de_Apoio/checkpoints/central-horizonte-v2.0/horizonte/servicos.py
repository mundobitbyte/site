from datetime import date


class ServicoCentral:
    def __init__(self, repositorio):
        self.repositorio = repositorio

    def preparar(self):
        self.repositorio.inicializar()

    def cadastrar_equipamento(self, patrimonio, tipo):
        patrimonio = patrimonio.strip().upper()
        tipo = tipo.strip().lower()
        if not patrimonio or not tipo:
            raise ValueError("Patrimônio e tipo são obrigatórios.")
        return self.repositorio.cadastrar_equipamento(patrimonio, tipo)

    def listar_equipamentos(self):
        return self.repositorio.listar_equipamentos()

    def abrir_atendimento(self, equipamento_id, descricao, prioridade, aberto_em=None):
        if self.repositorio.obter_equipamento(equipamento_id) is None:
            raise ValueError("Equipamento inexistente.")
        if prioridade not in (1, 2, 3):
            raise ValueError("Prioridade deve estar entre 1 e 3.")
        descricao = descricao.strip()
        if not descricao:
            raise ValueError("Descrição é obrigatória.")
        if aberto_em is None:
            aberto_em = date.today().isoformat()
        return self.repositorio.cadastrar_atendimento(
            equipamento_id,
            descricao,
            prioridade,
            aberto_em,
        )

    def listar_atendimentos(self, estado=None):
        return self.repositorio.listar_atendimentos(estado)

    def alterar_prioridade(self, atendimento_id, prioridade):
        if prioridade not in (1, 2, 3):
            raise ValueError("Prioridade deve estar entre 1 e 3.")
        quantidade = self.repositorio.atualizar_prioridade(atendimento_id, prioridade)
        if quantidade != 1:
            raise ValueError("Atendimento inexistente.")

    def concluir_atendimento(self, atendimento_id):
        quantidade = self.repositorio.concluir_atendimento(atendimento_id)
        if quantidade != 1:
            raise ValueError("Atendimento inexistente.")

    def cadastrar_pessoa(self, nome):
        nome = nome.strip()
        if not nome:
            raise ValueError("Nome é obrigatório.")
        return self.repositorio.cadastrar_pessoa(nome)

    def listar_pessoas(self):
        return self.repositorio.listar_pessoas()

    def retirar(self, pessoa_id, equipamento_id, retirado_em, previsto_para):
        retirada = date.fromisoformat(retirado_em)
        previsao = date.fromisoformat(previsto_para)
        if previsao < retirada:
            raise ValueError("Previsão não pode anteceder a retirada.")
        if self.repositorio.obter_equipamento(equipamento_id) is None:
            raise ValueError("Equipamento inexistente.")
        if self.repositorio.equipamento_emprestado(equipamento_id):
            raise ValueError("Equipamento já possui empréstimo aberto.")
        return self.repositorio.retirar(
            pessoa_id,
            equipamento_id,
            retirado_em,
            previsto_para,
        )

    def devolver(self, emprestimo_id, devolvido_em):
        devolucao = date.fromisoformat(devolvido_em)
        emprestimo = next(
            (item for item in self.repositorio.listar_emprestimos() if item.id == emprestimo_id),
            None,
        )
        if emprestimo is None or emprestimo.devolvido_em is not None:
            raise ValueError("Empréstimo inexistente ou já devolvido.")
        retirada = date.fromisoformat(emprestimo.retirado_em)
        if devolucao < retirada:
            raise ValueError("Devolução não pode anteceder a retirada.")
        quantidade = self.repositorio.devolver(emprestimo_id, devolvido_em)
        if quantidade != 1:
            raise ValueError("Empréstimo inexistente ou já devolvido.")

    def listar_emprestimos(self):
        return self.repositorio.listar_emprestimos()

    def atrasados(self, hoje=None):
        if hoje is None:
            referencia = date.today()
        else:
            referencia = hoje
        resultado = []
        for emprestimo in self.repositorio.listar_emprestimos():
            if emprestimo.devolvido_em is None:
                previsao = date.fromisoformat(emprestimo.previsto_para)
                if previsao < referencia:
                    resultado.append(emprestimo)
        return resultado
