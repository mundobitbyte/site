from dataclasses import dataclass


@dataclass(frozen=True)
class Equipamento:
    id: int | None
    patrimonio: str
    tipo: str


@dataclass(frozen=True)
class Atendimento:
    id: int | None
    equipamento_id: int
    patrimonio: str
    descricao: str
    prioridade: int
    estado: str
    aberto_em: str


@dataclass(frozen=True)
class Pessoa:
    id: int | None
    nome: str


@dataclass(frozen=True)
class Emprestimo:
    id: int | None
    pessoa_id: int
    pessoa_nome: str
    equipamento_id: int
    patrimonio: str
    retirado_em: str
    previsto_para: str
    devolvido_em: str | None
