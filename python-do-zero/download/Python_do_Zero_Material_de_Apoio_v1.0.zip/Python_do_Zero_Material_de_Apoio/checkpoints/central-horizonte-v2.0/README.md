# Central Horizonte 2.0

Checkpoint do capítulo **21** de *Python do Zero — Mundo bit Byte*.

## O que esta versão representa

Pessoas, empréstimos e preservação do suporte. Este diretório é uma fotografia funcional do projeto naquele ponto da leitura; ele serve para conferência, retomada ou continuidade, não para substituir a construção proposta no capítulo.

## Como executar

1. Abra o terminal nesta pasta.
2. Use Python 3.10 ou superior.
3. Execute `python central.py`.

Para abrir a interface gráfica, execute `python app.py`. Ao cadastrar uma pessoa, a GUI informa o novo ID e o preenche no campo do empréstimo. Para executar a suíte automática, use `python -m unittest discover -v`. Para testar a migração 1.2 → 2.0 em uma extração nova do pacote, prepare primeiro a base de origem:

1. Abra a pasta `central-horizonte-v1.2`.
2. Execute `python central.py`. Quando o menu aparecer, você pode cadastrar dados fictícios para preservar no teste ou apenas escolher `0` para sair. Essa primeira execução cria `dados/horizonte.db`.
3. Volte para a pasta `central-horizonte-v2.0`.
4. Execute `python scripts/migrar_v12_v20.py`. O script copia a base 1.2 para a pasta 2.0 e amplia a cópia, mantendo o checkpoint 1.2 intacto.

Para verificar backup e restauração da versão 2.0 sem alterar a base de trabalho, execute `python scripts/verificar_backup.py`. O roteiro preserva e confere equipamento, atendimento, pessoa e empréstimo.

## Dados de prática

Use somente dados fictícios nos experimentos. Os exemplos NB-07, PC-12 e IMP-03 usados no livro são fictícios.

## Continuidade

Cada checkpoint preserva o repertório conquistado até aqui. Em migrações, mantenha a versão anterior intacta e trabalhe sempre sobre uma cópia da base.
