# Central Horizonte 2.0

Checkpoint do capítulo **21** de *Python do Zero — Mundo bit Byte*.

## O que esta versão representa

Pessoas, empréstimos e preservação do suporte. Este diretório é uma fotografia funcional do projeto naquele ponto da leitura; ele serve para conferência, retomada ou continuidade, não para substituir a construção proposta no capítulo.

## Como executar

1. Abra o terminal nesta pasta.
2. Use Python 3.10 ou superior.
3. Execute `python central.py`.

Para abrir a interface gráfica, execute `python app.py`. Ao cadastrar uma pessoa, a GUI informa o novo ID e o preenche no campo do empréstimo. Para executar a suíte automática, use `python -m unittest discover -v`. A migração 1.2 → 2.0 deve ser feita sobre uma cópia da base com `python scripts/migrar_v12_v20.py`.

## Dados de prática

Use somente dados fictícios nos experimentos. Os exemplos NB-07, PC-12 e IMP-03 usados no livro são fictícios.

## Continuidade

Cada checkpoint preserva o repertório conquistado até aqui. Em migrações, mantenha a versão anterior intacta e trabalhe sempre sobre uma cópia da base.
