ATENDIMENTOS_EXEMPLO = [
    {"patrimonio": "NB-07", "descricao": "não liga", "prioridade": 1, "estado": "aberto"},
    {"patrimonio": "PC-12", "descricao": "sem acesso à rede", "prioridade": 2, "estado": "aberto"},
    {"patrimonio": "IMP-03", "descricao": "papel preso", "prioridade": 3, "estado": "concluído"},
]
