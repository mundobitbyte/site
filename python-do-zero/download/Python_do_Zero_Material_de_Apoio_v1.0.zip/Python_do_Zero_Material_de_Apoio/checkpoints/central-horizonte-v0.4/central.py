atendimentos = [
    {"patrimonio": "NB-07", "descricao": "não liga", "prioridade": 1, "estado": "aberto"},
    {"patrimonio": "PC-12", "descricao": "sem acesso à rede", "prioridade": 2, "estado": "aberto"},
    {"patrimonio": "IMP-03", "descricao": "papel preso", "prioridade": 3, "estado": "concluído"},
]

print("Central Horizonte - versão 0.4")
opcao = ""

while opcao != "0":
    print("\n1-Cadastrar 2-Listar 3-Buscar 4-Filtrar 5-Resumo 0-Sair")
    opcao = input("Opção: ").strip()

    if opcao == "1":
        patrimonio = input("Patrimônio: ").strip().upper()
        descricao = input("Descrição: ").strip()
        prioridade = int(input("Prioridade (1 a 3): ").strip())
        if prioridade in (1, 2, 3):
            atendimentos.append({
                "patrimonio": patrimonio,
                "descricao": descricao,
                "prioridade": prioridade,
                "estado": "aberto",
            })
            print("Atendimento cadastrado.")
        else:
            print("Prioridade inválida. Use 1, 2 ou 3.")

    elif opcao == "2":
        # Ordenação didática sem lambda: primeiro prioridade 1, depois 2 e 3.
        for prioridade_atual in (1, 2, 3):
            for atendimento in atendimentos:
                if atendimento["prioridade"] == prioridade_atual:
                    print(atendimento)

    elif opcao == "3":
        procurado = input("Patrimônio: ").strip().upper()
        encontrado = None
        for atendimento in atendimentos:
            if atendimento["patrimonio"] == procurado:
                encontrado = atendimento
        if encontrado is None:
            print("Patrimônio não encontrado.")
        else:
            print(encontrado)

    elif opcao == "4":
        estado_procurado = input("Estado: ").strip().lower()
        quantidade = 0
        for atendimento in atendimentos:
            if atendimento["estado"] == estado_procurado:
                print(atendimento)
                quantidade = quantidade + 1
        print(f"Encontrados: {quantidade}")

    elif opcao == "5":
        abertos = 0
        for atendimento in atendimentos:
            if atendimento["estado"] == "aberto":
                abertos = abertos + 1
        print(f"{len(atendimentos)} atendimentos; {abertos} abertos")

    elif opcao != "0":
        print("Opção inválida.")
