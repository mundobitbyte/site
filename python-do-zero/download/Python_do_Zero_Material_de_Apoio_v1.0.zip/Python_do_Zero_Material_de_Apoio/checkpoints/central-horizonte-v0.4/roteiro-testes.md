# Roteiro manual

Liste a massa, busque PC-12, filtre abertos e confirme 3 atendimentos e 2 abertos. Depois cadastre um quarto item e confira que os dicionários permanecem distintos.
