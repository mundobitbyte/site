# CHANGELOG

## 0.4 — 2026-09-14

### Adicionado
- guarda vários dicionários em lista
- lista, busca, filtra, ordena e resume

### Limitações conhecidas
- dados somem ao encerrar
- código ainda cresce em um arquivo

### Migração
Evolução documentada a partir da 0.3; a versão anterior não é alterada.
