<?php
require_once dirname(__DIR__, 2) . "/src/autenticacao.php";
require_once dirname(__DIR__, 2) . "/src/banco.php";
require_once dirname(__DIR__, 2) . "/vendor/autoload.php";

iniciarSessaoSegura();
exigirAutenticacao();
header("Cache-Control: no-store");

if (($_SERVER["REQUEST_METHOD"] ?? "GET") !== "POST") {
    header("Allow: POST");
    http_response_code(405);
    exit("Método não permitido.");
}

if (!tokenCsrfValido($_POST["csrf_token"] ?? "")) {
    http_response_code(403);
    exit("Não foi possível confirmar a exclusão.");
}

$assuntosPermitidos = ["", "duvida", "encomenda", "sugestao"];

$id = filter_var(
    $_POST["id"] ?? "",
    FILTER_VALIDATE_INT,
    ["options" => ["min_range" => 1]]
);

$confirmacao = $_POST["confirmacao"] ?? "";
$confirmacao = is_string($confirmacao) ? $confirmacao : "";

$assuntoRetorno = $_POST["assunto_retorno"] ?? "";
$assuntoRetorno = is_string($assuntoRetorno) &&
    in_array($assuntoRetorno, $assuntosPermitidos, true)
        ? $assuntoRetorno
        : "";

if ($id === false || $confirmacao !== "excluir") {
    $_SESSION["aviso_admin"] = [
        "tipo" => "erro",
        "texto" => "A exclusão recebida não é válida."
    ];
} else {
    try {
        $pdo = conectarBanco();
        $excluiu = excluirMensagemRespondida($pdo, $id);

        if ($excluiu) {
            $_SESSION["aviso_admin"] = [
                "tipo" => "sucesso",
                "texto" => "Mensagem excluída com sucesso."
            ];
        } else {
            $_SESSION["aviso_admin"] = [
                "tipo" => "erro",
                "texto" => "A mensagem não existe ou ainda não pode ser excluída."
            ];
        }
    } catch (PDOException $erro) {
        error_log($erro->getMessage());
        $_SESSION["aviso_admin"] = [
            "tipo" => "erro",
            "texto" => "Não foi possível excluir a mensagem agora."
        ];
    }
}

$destino = "painel.php";

if ($assuntoRetorno !== "") {
    $destino .= "?assunto=" . rawurlencode($assuntoRetorno);
}

header("Location: " . $destino, true, 303);
exit;
