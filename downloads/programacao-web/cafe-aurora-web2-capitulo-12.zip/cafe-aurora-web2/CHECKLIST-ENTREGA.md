# Café Aurora — checklist de entrega do Web II

Marque um item somente depois de conferir a evidência.

## Antes da publicação

- [ ] `composer install` concluiu sem erro e gerou `composer.lock`.
- [ ] `composer check` aprovou o ambiente e os quatro testes.
- [ ] O fluxo público e o painel foram testados também pelo navegador.
- [ ] O repositório não contém banco, credencial, backup, cache ou `vendor/`.
- [ ] Existe um backup recente e a restauração foi ensaiada.

## Servidor PHP

- [ ] O serviço oferece PHP 8.5, PDO e `pdo_sqlite`.
- [ ] A raiz pública aponta somente para a pasta `public/`.
- [ ] O banco e `dados/administrador.php` ficam fora da raiz pública.
- [ ] A pasta do banco é persistente e gravável pelo processo PHP.
- [ ] HTTPS está ativo em todo o site.
- [ ] `display_errors` está desativado e `log_errors` está ativo.
- [ ] O servidor possui um procedimento documentado para consultar os logs.

## Primeira preparação

- [ ] `CAFE_AURORA_DB_PATH` aponta para o local persistente escolhido.
- [ ] `CAFE_AURORA_BACKUP_DIR` aponta para uma pasta protegida e persistente.
- [ ] `php src/verificar-ambiente.php` retorna código zero.
- [ ] `php src/inicializar-banco.php` prepara a estrutura.
- [ ] `php src/criar-administrador.php` cria uma credencial exclusiva.
- [ ] A senha não foi enviada ao Git nem registrada no checklist.
- [ ] `composer install --no-dev --optimize-autoloader` instala a versão de produção.

## Teste de aceitação

- [ ] As páginas públicas abrem sem erro no endereço final.
- [ ] Uma mensagem válida é registrada uma única vez.
- [ ] Entradas inválidas são recusadas com orientação compreensível.
- [ ] Login incorreto falha e login correto abre o painel.
- [ ] Filtro, mudança de estado e PRG funcionam.
- [ ] Somente uma mensagem respondida e confirmada pode ser excluída.
- [ ] Atualizar a página não repete a última alteração.
- [ ] Sair encerra a sessão e protege novamente o painel.
- [ ] O fluxo essencial funciona por teclado e em tela estreita.

## Operação e passagem do projeto

- [ ] Há responsável definido por logs, atualizações e backups.
- [ ] A frequência e a retenção dos backups estão registradas.
- [ ] Uma cópia protegida do backup existe fora do servidor.
- [ ] A restauração foi testada sem apagar a única cópia válida.
- [ ] Limites conhecidos e melhorias futuras estão documentados.
- [ ] Outra pessoa consegue instalar, testar e operar o sistema pelas instruções.
