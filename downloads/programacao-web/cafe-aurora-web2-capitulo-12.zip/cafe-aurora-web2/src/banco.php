<?php
function caminhoBanco(): string
{
    $caminhoConfigurado = getenv("CAFE_AURORA_DB_PATH");

    if (
        is_string($caminhoConfigurado) &&
        trim($caminhoConfigurado) !== ""
    ) {
        return trim($caminhoConfigurado);
    }

    return dirname(__DIR__) . "/dados/cafe-aurora.sqlite";
}

function conectarBanco(): PDO
{
    return new PDO(
        "sqlite:" . caminhoBanco(),
        null,
        null,
        [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC
        ]
    );
}
