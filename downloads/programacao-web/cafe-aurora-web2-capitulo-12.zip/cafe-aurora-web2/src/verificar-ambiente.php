<?php
require_once __DIR__ . "/banco.php";

if (PHP_SAPI !== "cli") {
    http_response_code(404);
    exit;
}

$pastaBanco = dirname(caminhoBanco());

$verificacoes = [
    "PHP 8.5 ou superior" => version_compare(PHP_VERSION, "8.5.0", ">="),
    "extensão PDO ativa" => extension_loaded("PDO"),
    "driver pdo_sqlite ativo" => extension_loaded("pdo_sqlite"),
    "pasta do banco existente" => is_dir($pastaBanco),
    "pasta do banco gravável" => is_dir($pastaBanco) && is_writable($pastaBanco)
];

$falhas = 0;

foreach ($verificacoes as $descricao => $aprovada) {
    $situacao = $aprovada ? "OK" : "FALHOU";
    echo "[$situacao] $descricao" . PHP_EOL;

    if (!$aprovada) {
        $falhas++;
    }
}

echo PHP_EOL;

if ($falhas === 0) {
    echo "Ambiente básico aprovado." . PHP_EOL;
    exit(0);
}

echo "$falhas verificação(ões) precisam de correção." . PHP_EOL;
exit(1);
