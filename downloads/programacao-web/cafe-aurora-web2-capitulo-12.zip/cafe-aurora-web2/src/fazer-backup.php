<?php
require_once __DIR__ . "/banco.php";

if (PHP_SAPI !== "cli") {
    http_response_code(404);
    exit;
}

if (!extension_loaded("pdo_sqlite")) {
    fwrite(STDERR, "O driver pdo_sqlite não está ativo." . PHP_EOL);
    exit(1);
}

$origem = caminhoBanco();

if (!is_file($origem)) {
    fwrite(
        STDERR,
        "Banco não encontrado. Execute primeiro src/inicializar-banco.php." .
        PHP_EOL
    );
    exit(1);
}

$pastaConfigurada = getenv("CAFE_AURORA_BACKUP_DIR");
$pastaBackup = is_string($pastaConfigurada) && trim($pastaConfigurada) !== ""
    ? trim($pastaConfigurada)
    : dirname(__DIR__) . "/backups";

if (!is_dir($pastaBackup) && !mkdir($pastaBackup, 0775, true)) {
    fwrite(STDERR, "Não foi possível criar a pasta de backups." . PHP_EOL);
    exit(1);
}

$destino = $pastaBackup .
    "/cafe-aurora-" .
    date("Ymd-His") .
    ".sqlite";

if (is_file($destino)) {
    fwrite(STDERR, "Já existe um backup com este horário." . PHP_EOL);
    exit(1);
}

try {
    $pdo = conectarBanco();
    $destinoSql = $pdo->quote($destino);

    if ($destinoSql === false) {
        throw new RuntimeException("O destino do backup não pôde ser preparado.");
    }

    $pdo->exec("VACUUM INTO $destinoSql");
    $tamanhoBackup = is_file($destino) ? filesize($destino) : false;

    if ($tamanhoBackup === false || $tamanhoBackup === 0) {
        throw new RuntimeException("O arquivo de backup não foi confirmado.");
    }

    echo "Backup criado com sucesso:" . PHP_EOL;
    echo $destino . PHP_EOL;
} catch (Throwable $erro) {
    fwrite(
        STDERR,
        "Não foi possível criar o backup: " .
        $erro->getMessage() .
        PHP_EOL
    );
    exit(1);
}
