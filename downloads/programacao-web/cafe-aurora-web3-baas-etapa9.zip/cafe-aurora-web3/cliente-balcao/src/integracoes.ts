import { httpsCallable } from "firebase/functions";
import { doc,updateDoc } from "firebase/firestore";
import { funcoes,banco } from "./servico.js";
import { conferirConfiguracao } from "./atendimento.js";
import { elemento } from "./tela.js";

document.querySelector("#alterar-por-funcao")?.addEventListener("click", async () => {
  const retorno=elemento("#retorno-funcao");
  try {
    const minutos=elemento<HTMLInputElement>("#minutos").value;
    const dados=conferirConfiguracao({nomeNegocio:elemento<HTMLInputElement>("#nome").value,pedidosAbertos:elemento<HTMLSelectElement>("#aberto").value==='1',tempoEstimado:minutos.trim()===''?null:Number(minutos)});
    await httpsCallable(funcoes,"alterarAtendimentoSeguro")(dados);
    retorno.textContent="Função confirmou a alteração. Confira a consulta e o histórico do emulador.";
  } catch { retorno.textContent="A função não confirmou a alteração. Confira identidade, dados e logs."; }
});

