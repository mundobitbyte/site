<?php
$caminho = dirname(__DIR__) . "/dados/administrador.php";

fwrite(STDOUT, "Usuário administrativo: ");
$usuario = trim((string) fgets(STDIN));

fwrite(STDOUT, "Senha (mínimo de 12 caracteres): ");
$senha = rtrim((string) fgets(STDIN), "\r\n");

if ($usuario === "" || strlen($usuario) > 60) {
    fwrite(STDERR, "Informe um usuário com até 60 caracteres." . PHP_EOL);
    exit(1);
}

if (strlen($senha) < 12) {
    fwrite(STDERR, "A senha precisa ter pelo menos 12 caracteres." . PHP_EOL);
    exit(1);
}

$configuracao = [
    "usuario" => $usuario,
    "senha_hash" => password_hash($senha, PASSWORD_DEFAULT)
];

$conteudo = "<?php\nreturn " . var_export($configuracao, true) . ";\n";
$gravado = file_put_contents($caminho, $conteudo, LOCK_EX);

if ($gravado === false) {
    fwrite(STDERR, "Não foi possível criar a credencial." . PHP_EOL);
    exit(1);
}

echo "Administrador criado. A senha não foi gravada em texto aberto." . PHP_EOL;
