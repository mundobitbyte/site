<?php
function conectarBanco(): PDO
{
    $caminhoBanco = dirname(__DIR__) . "/dados/cafe-aurora.sqlite";

    return new PDO(
        "sqlite:" . $caminhoBanco,
        null,
        null,
        [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC
        ]
    );
}
