<?php
require_once __DIR__ . "/banco.php";

if (!extension_loaded("pdo_sqlite")) {
    fwrite(STDERR, "O driver pdo_sqlite não está ativo." . PHP_EOL);
    exit(1);
}

$pdo = null;

try {
    $pdo = conectarBanco();
    $pdo->beginTransaction();

    $sql = "
        CREATE TABLE IF NOT EXISTS mensagens (
            id INTEGER PRIMARY KEY,
            nome TEXT NOT NULL CHECK (length(nome) >= 2),
            email TEXT NOT NULL,
            telefone TEXT,
            assunto TEXT NOT NULL
                CHECK (assunto IN ('duvida', 'encomenda', 'sugestao')),
            mensagem TEXT NOT NULL
                CHECK (length(mensagem) BETWEEN 10 AND 500),
            criada_em TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
            status TEXT NOT NULL DEFAULT 'nova'
                CHECK (status IN ('nova', 'em_atendimento', 'respondida')),
            atualizada_em TEXT
        )
    ";

    $pdo->exec($sql);

    $colunas = $pdo->query("PRAGMA table_info(mensagens)")->fetchAll();
    $nomesColunas = array_column($colunas, "name");

    if (!in_array("status", $nomesColunas, true)) {
        $pdo->exec(
            "ALTER TABLE mensagens
             ADD COLUMN status TEXT NOT NULL DEFAULT 'nova'
             CHECK (status IN ('nova', 'em_atendimento', 'respondida'))"
        );
    }

    if (!in_array("atualizada_em", $nomesColunas, true)) {
        $pdo->exec(
            "ALTER TABLE mensagens
             ADD COLUMN atualizada_em TEXT"
        );
    }

    $pdo->commit();

    $quantidade = (int) $pdo
        ->query("SELECT COUNT(*) FROM mensagens")
        ->fetchColumn();

    echo "Banco e tabela preparados com sucesso." . PHP_EOL;
    echo "Mensagens cadastradas: $quantidade" . PHP_EOL;
} catch (PDOException $erro) {
    if ($pdo instanceof PDO && $pdo->inTransaction()) {
        $pdo->rollBack();
    }

    fwrite(
        STDERR,
        "Não foi possível preparar o banco: " .
        $erro->getMessage() .
        PHP_EOL
    );
    exit(1);
}
