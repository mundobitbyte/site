<?php
function excluirMensagemRespondida(PDO $pdo, int $id): bool
{
    $comando = $pdo->prepare(
        "DELETE FROM mensagens
         WHERE id = :id
           AND status = 'respondida'"
    );

    $comando->execute(["id" => $id]);

    return $comando->rowCount() === 1;
}
