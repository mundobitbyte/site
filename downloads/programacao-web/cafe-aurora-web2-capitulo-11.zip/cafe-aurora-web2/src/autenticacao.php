<?php
function iniciarSessaoSegura(): void
{
    if (session_status() === PHP_SESSION_ACTIVE) {
        return;
    }

    session_set_cookie_params([
        "httponly" => true,
        "secure" => !empty($_SERVER["HTTPS"]),
        "samesite" => "Lax"
    ]);
    session_start();
}

function caminhoAdministrador(): string
{
    return dirname(__DIR__) . "/dados/administrador.php";
}

function carregarAdministrador(): ?array
{
    $caminho = caminhoAdministrador();

    if (!is_file($caminho)) {
        return null;
    }

    $administrador = require $caminho;

    if (!is_array($administrador) ||
        !isset($administrador["usuario"], $administrador["senha_hash"]) ||
        !is_string($administrador["usuario"]) ||
        !is_string($administrador["senha_hash"])) {
        return null;
    }

    return $administrador;
}

function administradorAutenticado(): bool
{
    return ($_SESSION["administrador_autenticado"] ?? false) === true;
}

function exigirAutenticacao(): void
{
    if (administradorAutenticado()) {
        return;
    }

    header("Location: entrar.php", true, 303);
    exit;
}

function obterTokenCsrf(): string
{
    if (!isset($_SESSION["csrf_admin"]) ||
        !is_string($_SESSION["csrf_admin"])) {
        $_SESSION["csrf_admin"] = bin2hex(random_bytes(32));
    }

    return $_SESSION["csrf_admin"];
}

function tokenCsrfValido(mixed $tokenRecebido): bool
{
    return is_string($tokenRecebido) &&
        hash_equals(obterTokenCsrf(), $tokenRecebido);
}
