<?php
declare(strict_types=1);

use PHPUnit\Framework\TestCase;

final class ExclusaoMensagemTest extends TestCase
{
    public function testExcluiUmaMensagemRespondida(): void
    {
        $pdo = $this->criarBancoTeste();

        $excluiu = excluirMensagemRespondida($pdo, 3);

        self::assertTrue($excluiu);
        self::assertSame(0, $this->quantidadeMensagem($pdo, 3));
    }

    public function testNaoExcluiUmaMensagemNova(): void
    {
        $pdo = $this->criarBancoTeste();

        $excluiu = excluirMensagemRespondida($pdo, 1);

        self::assertFalse($excluiu);
        self::assertSame(1, $this->quantidadeMensagem($pdo, 1));
    }

    public function testNaoExcluiUmaMensagemEmAtendimento(): void
    {
        $pdo = $this->criarBancoTeste();

        $excluiu = excluirMensagemRespondida($pdo, 2);

        self::assertFalse($excluiu);
        self::assertSame(1, $this->quantidadeMensagem($pdo, 2));
    }

    public function testExcluiSomenteOIdInformado(): void
    {
        $pdo = $this->criarBancoTeste();

        $excluiu = excluirMensagemRespondida($pdo, 3);

        self::assertTrue($excluiu);
        self::assertSame(1, $this->quantidadeMensagem($pdo, 4));
    }

    private function criarBancoTeste(): PDO
    {
        $pdo = new PDO(
            "sqlite::memory:",
            null,
            null,
            [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC
            ]
        );

        $pdo->exec(
            "CREATE TABLE mensagens (
                id INTEGER PRIMARY KEY,
                status TEXT NOT NULL
            )"
        );

        $pdo->exec(
            "INSERT INTO mensagens (id, status) VALUES
             (1, 'nova'),
             (2, 'em_atendimento'),
             (3, 'respondida'),
             (4, 'respondida')"
        );

        return $pdo;
    }

    private function quantidadeMensagem(PDO $pdo, int $id): int
    {
        $consulta = $pdo->prepare(
            "SELECT COUNT(*) FROM mensagens WHERE id = :id"
        );
        $consulta->execute(["id" => $id]);

        return (int) $consulta->fetchColumn();
    }
}
