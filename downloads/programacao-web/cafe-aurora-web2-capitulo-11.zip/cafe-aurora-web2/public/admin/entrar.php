<?php
require_once dirname(__DIR__, 2) . "/src/autenticacao.php";

iniciarSessaoSegura();
header("Cache-Control: no-store");

if (administradorAutenticado()) {
    header("Location: painel.php", true, 303);
    exit;
}

$administrador = carregarAdministrador();
$erro = "";
$enviado = ($_SERVER["REQUEST_METHOD"] ?? "GET") === "POST";

if ($enviado) {
    $usuario = $_POST["usuario"] ?? "";
    $senha = $_POST["senha"] ?? "";

    if (!tokenCsrfValido($_POST["csrf_token"] ?? "")) {
        http_response_code(403);
        $erro = "Não foi possível confirmar o acesso. Atualize a página.";
    } elseif ($administrador === null) {
        $erro = "O administrador ainda não foi configurado.";
    } else {
        $usuarioCorreto = is_string($usuario) &&
            hash_equals($administrador["usuario"], trim($usuario));
        $senhaCorreta = is_string($senha) &&
            password_verify($senha, $administrador["senha_hash"]);

        if ($usuarioCorreto && $senhaCorreta) {
            session_regenerate_id(true);
            $_SESSION["administrador_autenticado"] = true;
            $_SESSION["csrf_admin"] = bin2hex(random_bytes(32));
            header("Location: painel.php", true, 303);
            exit;
        }

        $erro = "Usuário ou senha inválidos.";
    }
}

$csrfToken = obterTokenCsrf();
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="robots" content="noindex, nofollow">
  <title>Área administrativa — Café Aurora</title>
  <link rel="stylesheet" href="../css/styles.css">
</head>
<body>
  <a class="skip-link" href="#conteudo">Pular para o conteúdo</a>
  <header>
    <p><a href="../index.php">Café Aurora</a></p>
    <p>Área administrativa</p>
  </header>
  <main id="conteudo" tabindex="-1" class="admin-conteudo">
    <h1>Entrar</h1>

    <?php if ($administrador === null): ?>
      <div class="resumo-erros" role="alert">
        <strong>Administrador não configurado.</strong>
        <p>Execute <code>php src/criar-administrador.php</code> no terminal.</p>
      </div>
    <?php endif; ?>

    <?php if ($erro !== ""): ?>
      <p class="resumo-erros" role="alert"><?= htmlspecialchars($erro, ENT_QUOTES | ENT_SUBSTITUTE, "UTF-8") ?></p>
    <?php endif; ?>

    <form method="post" class="formulario-login">
      <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrfToken, ENT_QUOTES, "UTF-8") ?>">
      <p>
        <label for="usuario">Usuário</label>
        <input id="usuario" name="usuario" autocomplete="username" required>
      </p>
      <p>
        <label for="senha">Senha</label>
        <input id="senha" name="senha" type="password" autocomplete="current-password" required>
      </p>
      <button type="submit" <?= $administrador === null ? "disabled" : "" ?>>Entrar</button>
    </form>
  </main>
  <footer><p>&copy; 2026 Café Aurora. Projeto educacional fictício.</p></footer>
</body>
</html>
