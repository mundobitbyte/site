<?php
require_once dirname(__DIR__, 2) . "/src/autenticacao.php";
require_once dirname(__DIR__, 2) . "/src/banco.php";

iniciarSessaoSegura();
exigirAutenticacao();
header("Cache-Control: no-store");

if (($_SERVER["REQUEST_METHOD"] ?? "GET") !== "POST") {
    header("Allow: POST");
    http_response_code(405);
    exit("Método não permitido.");
}

if (!tokenCsrfValido($_POST["csrf_token"] ?? "")) {
    http_response_code(403);
    exit("Não foi possível confirmar a alteração.");
}

$statusPermitidos = ["nova", "em_atendimento", "respondida"];
$assuntosPermitidos = ["", "duvida", "encomenda", "sugestao"];

$idRecebido = $_POST["id"] ?? "";
$id = filter_var(
    $idRecebido,
    FILTER_VALIDATE_INT,
    ["options" => ["min_range" => 1]]
);

$status = $_POST["status"] ?? "";
$status = is_string($status) ? $status : "";

$assuntoRetorno = $_POST["assunto_retorno"] ?? "";
$assuntoRetorno = is_string($assuntoRetorno) &&
    in_array($assuntoRetorno, $assuntosPermitidos, true)
        ? $assuntoRetorno
        : "";

if ($id === false || !in_array($status, $statusPermitidos, true)) {
    $_SESSION["aviso_admin"] = [
        "tipo" => "erro",
        "texto" => "A alteração recebida não é válida."
    ];
} else {
    try {
        $pdo = conectarBanco();
        $comando = $pdo->prepare(
            "UPDATE mensagens
             SET status = :status,
                 atualizada_em = CURRENT_TIMESTAMP
             WHERE id = :id"
        );
        $comando->execute([
            "status" => $status,
            "id" => $id
        ]);

        if ($comando->rowCount() === 1) {
            $_SESSION["aviso_admin"] = [
                "tipo" => "sucesso",
                "texto" => "Andamento atualizado com sucesso."
            ];
        } else {
            $_SESSION["aviso_admin"] = [
                "tipo" => "erro",
                "texto" => "A mensagem informada não foi encontrada."
            ];
        }
    } catch (PDOException $erro) {
        error_log($erro->getMessage());
        $_SESSION["aviso_admin"] = [
            "tipo" => "erro",
            "texto" => "Não foi possível atualizar o andamento agora."
        ];
    }
}

$destino = "painel.php";

if ($assuntoRetorno !== "") {
    $destino .= "?assunto=" . rawurlencode($assuntoRetorno);
}

header("Location: " . $destino, true, 303);
exit;
