<?php
require_once dirname(__DIR__, 2) . "/src/autenticacao.php";

iniciarSessaoSegura();

if (($_SERVER["REQUEST_METHOD"] ?? "GET") !== "POST" ||
    !tokenCsrfValido($_POST["csrf_token"] ?? "")) {
    http_response_code(403);
    exit("Não foi possível confirmar a saída.");
}

$_SESSION = [];

if (ini_get("session.use_cookies")) {
    $parametros = session_get_cookie_params();
    setcookie(session_name(), "", time() - 42000, $parametros["path"],
        $parametros["domain"], $parametros["secure"], $parametros["httponly"]);
}

session_destroy();
header("Location: entrar.php", true, 303);
exit;
