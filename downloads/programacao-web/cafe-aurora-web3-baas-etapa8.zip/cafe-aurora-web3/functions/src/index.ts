import { initializeApp } from "firebase-admin/app";
import { getFirestore, FieldValue } from "firebase-admin/firestore";
import { getMessaging } from "firebase-admin/messaging";
import { onCall, HttpsError, type CallableRequest } from "firebase-functions/v2/https";
import { onDocumentUpdated } from "firebase-functions/v2/firestore";
import { createHash } from "node:crypto";
import { conferir, mudou, conferirPedido, conferirRascunho } from "./regras";

initializeApp();
const banco = getFirestore();
const limites = { region: "us-central1", maxInstances: 1, concurrency: 10, timeoutSeconds: 20 };
function operador(p: CallableRequest<unknown>): string {
  if (!p.auth) throw new HttpsError("unauthenticated", "Entre no Café.");
  if (p.auth.token.operador !== true) throw new HttpsError("permission-denied", "Esta ação é do operador.");
  return p.auth.uid;
}
export const alterarAtendimentoSeguro = onCall(limites, async p => {
  operador(p);
  let dados;
  try { dados = conferir(p.data); }
  catch { throw new HttpsError("invalid-argument", "Confira os dados do atendimento."); }
  await banco.doc("atendimento/atual").set(dados);
  return { confirmado: true };
});

export const registrarMudanca = onDocumentUpdated({ ...limites, document: "atendimento/atual" }, async evento => {
  if (!evento.data) return;
  let antes, depois;
  try { antes = conferir(evento.data.before.data()); depois = conferir(evento.data.after.data()); }
  catch { console.warn("Evento com configuração inválida foi ignorado."); return; }
  if (!mudou(antes, depois)) return;
  // Mesmo evento pode chegar novamente. O identificador determinístico evita outra gravação.
  const id = createHash("sha256").update(evento.id).digest("hex");
  try { await banco.doc(`historico/${id}`).create({ eventoId: evento.id, antes, depois, registradoEm: FieldValue.serverTimestamp() }); }
  catch (erro) { if (!(typeof erro === "object" && erro !== null && "code" in erro && erro.code === 6)) throw erro; }
});

