const filtros = document.querySelector("[data-filtros]");
const botoesFiltro = document.querySelectorAll("[data-filtro]");
const produtos = document.querySelectorAll("[data-categoria]");
const statusFiltro = document.querySelector("[data-status-filtro]");

if (filtros && botoesFiltro.length && produtos.length && statusFiltro) {
  function filtrarProdutos(categoria) {
    let quantidadeVisivel = 0;

    produtos.forEach(function (produto) {
      const deveMostrar = categoria === "todos" ||
        produto.dataset.categoria === categoria;

      produto.hidden = !deveMostrar;
      if (deveMostrar) quantidadeVisivel += 1;
    });

    const complemento = quantidadeVisivel === 1 ? "produto encontrado" : "produtos encontrados";
    statusFiltro.textContent = `${quantidadeVisivel} ${complemento}.`;
  }

  botoesFiltro.forEach(function (botao) {
    botao.addEventListener("click", function () {
      botoesFiltro.forEach(function (item) {
        item.setAttribute("aria-pressed", "false");
      });

      botao.setAttribute("aria-pressed", "true");
      filtrarProdutos(botao.dataset.filtro);
    });
  });

  filtros.hidden = false;
  filtrarProdutos("todos");
}

const mensagem = document.querySelector("#mensagem");
const contador = document.querySelector("#contador-mensagem");

if (mensagem && contador) {
  mensagem.addEventListener("input", function () {
    const quantidade = mensagem.value.length;
    contador.textContent = `${quantidade} de 500 caracteres`;
  });
}
