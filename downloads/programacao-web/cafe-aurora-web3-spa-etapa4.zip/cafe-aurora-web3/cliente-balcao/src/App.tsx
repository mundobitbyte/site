import {useState,useRef} from "react";
import {obterAtendimento} from "./atendimento.js";
import type {Atendimento as Dados} from "./atendimento.js";
import {Atendimento} from "./componentes/Atendimento.js";
import {Cardapio} from "./componentes/Cardapio.js";
import {lerProdutos} from "./servicos/api.js";
import type {Produto} from "./servicos/api.js";
export function App(){
 const [produtos,setProdutos]=useState<Produto[]>([]);
 const [avisoProdutos,setAvisoProdutos]=useState("");

 const [dados,setDados]=useState<Dados|null>(null);
 const [consultando,setConsultando]=useState(false);
 const [aviso,setAviso]=useState("Consulte para confirmar o atendimento.");
 const consultaAtiva=useRef(false);
  async function consultar() {
    if (consultaAtiva.current) return;
    const foco = document.activeElement;
    consultaAtiva.current = true; setConsultando(true); setDados(null); setAviso("Consultando o atendimento…");
    try { setDados(await obterAtendimento()); setAviso("Atendimento consultado agora."); }
    catch { setAviso("Não foi possível consultar. Tente novamente."); }
    finally {
      consultaAtiva.current = false; setConsultando(false);
      requestAnimationFrame(() => { if (foco instanceof HTMLButtonElement && document.activeElement === document.body) foco.focus({ preventScroll: true }); });
    }
  }

 async function carregarProdutos(){setProdutos([]);setAvisoProdutos("Consultando…");try{setProdutos(await lerProdutos());setAvisoProdutos("");}catch{setAvisoProdutos("Cardápio não confirmado. Tente novamente.");}}
 return <><h1>Café Aurora · Balcão</h1><Atendimento dados={dados} consultando={consultando} aviso={aviso} aoConsultar={()=>void consultar()}/><button onClick={()=>void carregarProdutos()}>Consultar cardápio</button><p role="status">{avisoProdutos}</p><Cardapio produtos={produtos} busca="" categoria="todas" aoBuscar={()=>{}} aoCategorizar={()=>{}}/></>;
}
