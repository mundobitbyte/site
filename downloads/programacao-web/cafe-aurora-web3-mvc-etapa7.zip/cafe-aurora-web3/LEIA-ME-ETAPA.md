# Café Aurora — O Café cabe na rotina do celular

Referência final da etapa 7, percurso Servidor com Laravel.

Compare em outra pasta. Preserve a sua solução, banco, mensagens e credenciais. Não extraia sobre dados de trabalho sem cópia.
O site apresenta as instruções; a aplicação é executada no computador do estudante.

PHP 8.5 e Node 24. Use o terminal Laragon preparado no Windows. Em cliente-balcao, execute npm ci e npm run build. A saída é public/js/balcao/main.js, ausente do ZIP.
Na raiz: copie .env.example para .env somente se não existir; composer install --no-interaction --no-plugins; php artisan key:generate somente na preparação inicial.
Pare o servidor antigo e inicie php artisan serve --host=localhost --port=8000.
Sem banco: php src/inicializar-banco.php. Depois: php artisan migrate. Preserve um banco existente; nunca use migrate:fresh nesta sequência.
Operador local: php artisan cafe:operador operador@example.test, com senha escolhida no terminal.
Importação inicial do catálogo: php artisan cafe:importar-cardapio. Não sobrescreve edições.

Alterou PHP: nova consulta. Alterou TypeScript/React: novo build e recarregamento. Configurações de ambiente e servidores só são retomados quando necessário.
Este checkpoint não inclui .env, banco SQLite, credenciais, vendor, node_modules ou JavaScript gerado. Consulte a aula para os testes e resultados esperados.
