<?php
namespace App\Http\Controllers;
use App\Http\Requests\AtualizarAtendimentoRequest;
use App\Models\AtendimentoAtual;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\RedirectResponse;
use Illuminate\Contracts\View\View;

class AtendimentoController
{
    public function mostrar(): View
    {
        return view('atendimento', ['atendimento'=>AtendimentoAtual::findOrFail(1)]);
    }
    public function publico(): JsonResponse
    {
        return response()->json(AtendimentoAtual::findOrFail(1)->mensagens())->header('Cache-Control','no-store');
    }
}
