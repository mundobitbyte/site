<?php
require_once dirname(__DIR__) . "/src/repositorio-mensagens.php";

if (!extension_loaded("pdo_sqlite")) {
    fwrite(STDERR, "O driver pdo_sqlite não está ativo." . PHP_EOL);
    exit(1);
}

function verificar(bool $condicao, string $mensagem): void
{
    if (!$condicao) {
        throw new RuntimeException($mensagem);
    }
}

function testar(string $descricao, callable $teste): bool
{
    try {
        $teste();
        echo "[OK] $descricao" . PHP_EOL;
        return true;
    } catch (Throwable $erro) {
        echo "[FALHOU] $descricao" . PHP_EOL;
        echo "  " . $erro->getMessage() . PHP_EOL;
        return false;
    }
}

function criarBancoTeste(): PDO
{
    $pdo = new PDO(
        "sqlite::memory:",
        null,
        null,
        [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC
        ]
    );

    $pdo->exec(
        "CREATE TABLE mensagens (
            id INTEGER PRIMARY KEY,
            status TEXT NOT NULL
        )"
    );

    $pdo->exec(
        "INSERT INTO mensagens (id, status) VALUES
         (1, 'nova'),
         (2, 'em_atendimento'),
         (3, 'respondida'),
         (4, 'respondida')"
    );

    return $pdo;
}

function quantidadeMensagem(PDO $pdo, int $id): int
{
    $consulta = $pdo->prepare(
        "SELECT COUNT(*) FROM mensagens WHERE id = :id"
    );
    $consulta->execute(["id" => $id]);

    return (int) $consulta->fetchColumn();
}

$casos = [
    "exclui uma mensagem respondida" => function (): void {
        $pdo = criarBancoTeste();

        $excluiu = excluirMensagemRespondida($pdo, 3);

        verificar(
            $excluiu,
            "A mensagem respondida deveria ser excluída."
        );
        verificar(
            quantidadeMensagem($pdo, 3) === 0,
            "O registro respondido ainda está no banco."
        );
    },
    "não exclui uma mensagem nova" => function (): void {
        $pdo = criarBancoTeste();

        $excluiu = excluirMensagemRespondida($pdo, 1);

        verificar(
            !$excluiu,
            "Uma mensagem nova foi aceita para exclusão."
        );
        verificar(
            quantidadeMensagem($pdo, 1) === 1,
            "A mensagem nova desapareceu do banco."
        );
    },
    "não exclui uma mensagem em atendimento" => function (): void {
        $pdo = criarBancoTeste();

        $excluiu = excluirMensagemRespondida($pdo, 2);

        verificar(
            !$excluiu,
            "Uma mensagem em atendimento foi aceita para exclusão."
        );
        verificar(
            quantidadeMensagem($pdo, 2) === 1,
            "A mensagem em atendimento desapareceu do banco."
        );
    },
    "exclui somente o ID informado" => function (): void {
        $pdo = criarBancoTeste();

        excluirMensagemRespondida($pdo, 3);

        verificar(
            quantidadeMensagem($pdo, 3) === 0,
            "O registro escolhido não foi excluído."
        );
        verificar(
            quantidadeMensagem($pdo, 4) === 1,
            "Outra mensagem respondida também foi excluída."
        );
    }
];

$falhas = 0;

foreach ($casos as $descricao => $caso) {
    if (!testar($descricao, $caso)) {
        $falhas++;
    }
}

$total = count($casos);
echo PHP_EOL . "$total teste(s), $falhas falha(s)." . PHP_EOL;

exit($falhas === 0 ? 0 : 1);
