const filtros = document.querySelector("[data-filtros]");
const botoesFiltro = document.querySelectorAll("[data-filtro]");
const cardsProdutos = document.querySelectorAll("[data-categoria]");
const statusFiltro = document.querySelector("[data-status-filtro]");

if (filtros && botoesFiltro.length && cardsProdutos.length && statusFiltro) {
  function filtrarProdutos(categoria) {
    let quantidadeVisivel = 0;

    cardsProdutos.forEach(function (produto) {
      const deveMostrar = categoria === "todos" ||
        produto.dataset.categoria === categoria;

      produto.hidden = !deveMostrar;
      if (deveMostrar) quantidadeVisivel += 1;
    });

    const complemento = quantidadeVisivel === 1 ? "produto encontrado" : "produtos encontrados";
    statusFiltro.textContent = `${quantidadeVisivel} ${complemento}.`;
  }

  botoesFiltro.forEach(function (botao) {
    botao.addEventListener("click", function () {
      botoesFiltro.forEach(function (item) {
        item.setAttribute("aria-pressed", "false");
      });

      botao.setAttribute("aria-pressed", "true");
      filtrarProdutos(botao.dataset.filtro);
    });
  });

  filtros.hidden = false;
  filtrarProdutos("todos");
}

const mensagem = document.querySelector("#mensagem");
const contador = document.querySelector("#contador-mensagem");

if (mensagem && contador) {
  mensagem.addEventListener("input", function () {
    const quantidade = mensagem.value.length;
    contador.textContent = `${quantidade} de 500 caracteres`;
  });
}

const produtos = [
  { id: "cafe-coado", nome: "Café coado", categoria: "bebida", preco: 8 },
  { id: "pao-artesanal", nome: "Pão artesanal", categoria: "comida", preco: 12 },
  { id: "bolo-laranja", nome: "Bolo de laranja", categoria: "comida", preco: 9 }
];

console.table(produtos);

const pedido = document.querySelector("[data-pedido]");
const itensPedido = document.querySelectorAll("[data-item-pedido]");
const resumoPedido = document.querySelector("[data-resumo-pedido]");
const limparPedido = document.querySelector("[data-limpar-pedido]");

if (pedido && itensPedido.length && resumoPedido && limparPedido) {
  function formatarPreco(valor) {
    return valor.toLocaleString("pt-BR", {
      style: "currency",
      currency: "BRL"
    });
  }

  function calcularPedido() {
    let quantidade = 0;
    let total = 0;

    for (const item of itensPedido) {
      if (!item.checked) continue;

      const produto = produtos.find(function (produto) {
        return produto.id === item.value;
      });

      if (!produto) continue;
      quantidade += 1;
      total += produto.preco;
    }

    resumoPedido.textContent = quantidade === 0
      ? "Nenhum produto selecionado."
      : `${quantidade} ${quantidade === 1 ? "item" : "itens"} — ${formatarPreco(total)}`;
  }

  itensPedido.forEach(function (item) {
    item.addEventListener("change", calcularPedido);
  });

  limparPedido.addEventListener("click", function () {
    itensPedido.forEach(function (item) {
      item.checked = false;
    });
    calcularPedido();
  });

  pedido.hidden = false;
  limparPedido.hidden = false;
  calcularPedido();
}
