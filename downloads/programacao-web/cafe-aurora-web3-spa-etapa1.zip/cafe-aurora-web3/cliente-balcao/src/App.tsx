interface OrientacaoProps { titulo: string; texto: string }
function Orientacao({titulo,texto}:OrientacaoProps){return <section><h2>{titulo}</h2><p>{texto}</p></section>;}
export function App(){return <><h1>Café Aurora · Balcão</h1><Orientacao titulo="Antes de retirar" texto="Consulte o atendimento para confirmar a abertura dos pedidos e o prazo informado pela equipe."/></>;}
