# Café Aurora — A regra fica no serviço

Referência final da etapa 3, percurso Serviços com Firebase.

Compare em outra pasta. Preserve a sua solução, banco, mensagens e credenciais. Não extraia sobre dados de trabalho sem cópia.
O site apresenta as instruções; a aplicação é executada no computador do estudante.

Node 22 e Java 21. Instale npm ci na raiz e em cliente-balcao; faça npm run build --prefix cliente-balcao.
Primeira execução na raiz: npm run emuladores. Em outro terminal na mesma raiz: npm run preparar. Abra http://localhost:5000 e http://localhost:4000. O projeto demo é local; não há deploy ou contratação de nuvem nesta preparação.
Encerre com Ctrl+C e aguarde a exportação para dados-emuladores. Nas próximas sessões use npm run retomar. Não publique nem inclua essa pasta de dados na entrega. Se conferir outra pasta limpa, ela começa com npm run emuladores; não leva seus dados particulares.
O PHP do Web II permanece na cópia preservada e não é executado pelo Hosting estático.

Alterou PHP: nova consulta. Alterou TypeScript/React: novo build e recarregamento. Configurações de ambiente e servidores só são retomados quando necessário.
Este checkpoint não inclui .env, banco SQLite, credenciais, vendor, node_modules ou JavaScript gerado. Consulte a aula para os testes e resultados esperados.
