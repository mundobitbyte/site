import { before,after,test } from 'node:test';
import { readFile } from 'node:fs/promises';
import { initializeTestEnvironment,assertSucceeds,assertFails } from '@firebase/rules-unit-testing';
import { doc,setDoc,getDoc,deleteDoc } from 'firebase/firestore';
import { ref,uploadBytes,deleteObject } from 'firebase/storage';
let ambiente;
const dados={nomeNegocio:'Café Aurora',pedidosAbertos:true,tempoEstimado:30};
before(async()=>{ambiente=await initializeTestEnvironment({projectId:'demo-cafe-aurora-web3',firestore:{rules:await readFile('firestore.rules','utf8')}});await ambiente.withSecurityRulesDisabled(c=>setDoc(doc(c.firestore(),'atendimento/atual'),dados));});
after(async()=>{await ambiente?.cleanup();});
test('visitante consulta, mas não escreve; identidade sem papel não autoriza',async()=>{
 const anon=ambiente.unauthenticatedContext().firestore();const leitor=ambiente.authenticatedContext('leitor',{operador:false}).firestore();
 await assertSucceeds(getDoc(doc(anon,'atendimento/atual')));
 for(const b of [anon,leitor])await assertFails(setDoc(doc(b,'atendimento/atual'),dados));
});
test('operador grava somente contrato válido e não apaga atendimento',async()=>{
 const b=ambiente.authenticatedContext('operador',{operador:true}).firestore();const r=doc(b,'atendimento/atual');
 for(const prazo of [null,0,240])await assertSucceeds(setDoc(r,{...dados,tempoEstimado:prazo}));
 for(const prazo of [-1,241,'30'])await assertFails(setDoc(r,{...dados,tempoEstimado:prazo}));
 await assertFails(setDoc(r,{...dados,nomeNegocio:'   '}));await assertFails(setDoc(r,{...dados,segredo:'extra'}));await assertFails(deleteDoc(r));
 await assertFails(getDoc(doc(b,'historico/qualquer')));
});
test('inscrição é escrita pelo dono, nunca listada pelo cliente',async()=>{
 const eu=ambiente.authenticatedContext('eu').firestore();const outro=ambiente.authenticatedContext('outro').firestore();
 await assertSucceeds(setDoc(doc(eu,'inscricoes/eu'),{token:'token-ficticio'}));
 await assertFails(getDoc(doc(eu,'inscricoes/eu')));await assertFails(setDoc(doc(outro,'inscricoes/eu'),{token:'troca'}));
 await assertSucceeds(deleteDoc(doc(eu,'inscricoes/eu')));
});
