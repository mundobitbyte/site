# Origem

Base: cafe-aurora-web3-capitulo-1.zip
SHA-256: 2f18a3f2b850697b68eb2da8025e4dbf40c37b74bf159364773415b115719cdc
Etapa: Capítulo 2, Aula 5.
Prazo de referência: 30 minutos, pedidos abertos.
