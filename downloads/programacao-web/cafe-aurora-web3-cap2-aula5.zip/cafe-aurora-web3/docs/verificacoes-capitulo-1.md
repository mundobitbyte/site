# Conferência do capítulo 1

Origem da minha cópia: ...

- [ ] Abri o balcão pelo servidor PHP local.
- [ ] Identifiquei quem prepara a informação.
- [ ] Alterei somente o prazo em src/atendimento.php e recarreguei as duas páginas.
- [ ] Testei atendimento aberto e encerrado.
- [ ] Expliquei por que a aba aberta não muda sozinha.
- [ ] Conferi o fluxo de mensagem fictícia do Web II.

Registre ação, resultado esperado, observado e eventual correção.
