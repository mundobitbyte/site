<?php
require_once __DIR__ . "/banco.php";

if (!extension_loaded("pdo_sqlite")) {
    fwrite(STDERR, "O driver pdo_sqlite não está ativo." . PHP_EOL);
    exit(1);
}

try {
    $pdo = conectarBanco();

    $sql = "
        CREATE TABLE IF NOT EXISTS mensagens (
            id INTEGER PRIMARY KEY,
            nome TEXT NOT NULL CHECK (length(nome) >= 2),
            email TEXT NOT NULL,
            telefone TEXT,
            assunto TEXT NOT NULL
                CHECK (assunto IN ('duvida', 'encomenda', 'sugestao')),
            mensagem TEXT NOT NULL
                CHECK (length(mensagem) BETWEEN 10 AND 500),
            criada_em TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
        )
    ";

    $pdo->exec($sql);

    $quantidade = (int) $pdo
        ->query("SELECT COUNT(*) FROM mensagens")
        ->fetchColumn();

    echo "Banco e tabela preparados com sucesso." . PHP_EOL;
    echo "Mensagens cadastradas: $quantidade" . PHP_EOL;
} catch (PDOException $erro) {
    fwrite(
        STDERR,
        "Não foi possível preparar o banco: " .
        $erro->getMessage() .
        PHP_EOL
    );
    exit(1);
}
