@extends('layout')
@section('titulo','Atendimento')
@section('conteudo')
<h1>{{ $dados['nomeNegocio'] }}</h1><p>{{ $dados['mensagemStatus'] }}</p><p>{{ $dados['mensagemTempo'] }}</p>
@endsection
