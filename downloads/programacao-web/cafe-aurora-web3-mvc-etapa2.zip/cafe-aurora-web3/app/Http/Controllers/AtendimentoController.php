<?php
namespace App\Http\Controllers;
class AtendimentoController {
 public function mostrar(){require_once base_path('src/atendimento.php');return view('atendimento',['dados'=>obterAtendimento()]);}
 public function publico(){require_once base_path('src/atendimento.php');return response()->json(obterAtendimento())->header('Cache-Control','no-store');}
}
