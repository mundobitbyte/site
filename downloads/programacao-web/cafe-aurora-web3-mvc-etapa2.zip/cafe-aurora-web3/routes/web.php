<?php
use Illuminate\Support\Facades\Route;
Route::get('/',fn()=>view('inicio-legado'));
Route::get('/atendimento',[\App\Http\Controllers\AtendimentoController::class,'mostrar']);
Route::get('/api/atendimento',[\App\Http\Controllers\AtendimentoController::class,'publico']);
Route::get('/api/atendimento.php',[\App\Http\Controllers\AtendimentoController::class,'publico']);
