@extends('layout')
@section('titulo','Atendimento')
@section('conteudo')
<h1>{{ $atendimento->nome }}</h1>
@php($dados=$atendimento->mensagens())
<p>{{ $dados['mensagemStatus'] }}</p><p>{{ $dados['mensagemTempo'] }}</p>
@endsection
