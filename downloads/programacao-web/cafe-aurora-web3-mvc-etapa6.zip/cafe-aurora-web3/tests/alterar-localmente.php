<?php
require_once dirname(__DIR__).'/src/repositorio-atendimento.php';
$aviso=new AvisoAtendimento('Café Aurora',true,47);
salvarConfiguracaoAtendimento(conectarBanco(),$aviso);
echo 'Alteração local gravada.',PHP_EOL;
