import { obterAtendimento } from "./dados.js";
import { elemento, apresentar, retirarAviso, comPrazo } from "./tela.js";
import "./operador.js";
if(document.querySelector("#consultar-atendimento")){
const botao = elemento<HTMLButtonElement>("#consultar-atendimento");
const retorno = elemento("#retorno-consulta");
let revisao = 0;
botao.addEventListener("click", async () => {
  const atual = ++revisao;
  botao.disabled = true; retirarAviso(); retorno.textContent = "Consultando o serviço…";
  try { const dados = await comPrazo(obterAtendimento()); if (atual === revisao) { apresentar(dados); retorno.textContent = "Consulta confirmada pelo serviço."; } }
  catch { if (atual === revisao) { retirarAviso(); retorno.textContent = "Não foi possível confirmar. Confira os emuladores e tente novamente."; } }
  finally { if (atual === revisao) { botao.disabled = false; botao.focus(); } }
});


window.addEventListener("offline",()=>{++revisao;botao.disabled=false;retirarAviso();retorno.textContent="Sem conexão. Consulte novamente quando ela voltar.";});
}
