# Café Aurora — Capítulo 2, fim da Aula 1

Referência para conferir em outra pasta. Preserve a sua solução e suas escolhas.
Base: checkpoint final do Capítulo 1. Sem banco de dados, credenciais, vendor ou node_modules.

Na raiz da aplicação, inicie: php -d opcache.enable=0 -S localhost:8000 -t public
Abra http://localhost:8000/balcao.php e http://localhost:8000/api/atendimento.php.

Os comandos são explicados na aula correspondente. O servidor embutido é para desenvolvimento local.
Para mensagens/painel, retome a preparação de banco e administrador ensinada no Web II/Capítulo 1.
