# Origem da referência

Base: cafe-aurora-web2-capitulo-12.zip

SHA-256 da base: eebb4717c8614eebf958de9533086363127c05723421d011769445654dccdf25

Etapa: Aula 1 — intermediário
