<?php
require_once dirname(__DIR__, 2) . "/src/autenticacao.php";
require_once dirname(__DIR__, 2) . "/src/banco.php";

iniciarSessaoSegura();
exigirAutenticacao();
header("Cache-Control: no-store");

function escaparPainel(string $valor): string
{
    return htmlspecialchars($valor, ENT_QUOTES | ENT_SUBSTITUTE, "UTF-8");
}

$assuntosPermitidos = [
    "" => "Todos",
    "duvida" => "Dúvida",
    "encomenda" => "Encomenda",
    "sugestao" => "Sugestão"
];

$assunto = $_GET["assunto"] ?? "";
$assunto = is_string($assunto) && array_key_exists($assunto, $assuntosPermitidos)
    ? $assunto
    : "";

try {
    $pdo = conectarBanco();

    if ($assunto === "") {
        $consulta = $pdo->query(
            "SELECT id, nome, email, telefone, assunto, mensagem, criada_em
             FROM mensagens
             ORDER BY criada_em DESC, id DESC
             LIMIT 50"
        );
    } else {
        $consulta = $pdo->prepare(
            "SELECT id, nome, email, telefone, assunto, mensagem, criada_em
             FROM mensagens
             WHERE assunto = :assunto
             ORDER BY criada_em DESC, id DESC
             LIMIT 50"
        );
        $consulta->execute(["assunto" => $assunto]);
    }

    $mensagens = $consulta->fetchAll();
    $erroConsulta = "";
} catch (PDOException $erro) {
    error_log($erro->getMessage());
    $mensagens = [];
    $erroConsulta = "Não foi possível consultar as mensagens agora.";
}

$csrfToken = obterTokenCsrf();
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="robots" content="noindex, nofollow">
  <title>Mensagens recebidas — Café Aurora</title>
  <link rel="stylesheet" href="../css/styles.css">
</head>
<body>
  <a class="skip-link" href="#conteudo">Pular para o conteúdo</a>
  <header class="cabecalho-admin">
    <div>
      <p><a href="../index.php">Café Aurora</a></p>
      <p>Área administrativa</p>
    </div>
    <form method="post" action="sair.php">
      <input type="hidden" name="csrf_token" value="<?= escaparPainel($csrfToken) ?>">
      <button type="submit">Sair</button>
    </form>
  </header>
  <main id="conteudo" tabindex="-1" class="admin-conteudo">
    <h1>Mensagens recebidas</h1>
    <p>São mostrados, no máximo, os 50 registros mais recentes.</p>

    <form method="get" class="filtro-servidor">
      <label for="assunto">Filtrar por assunto</label>
      <select id="assunto" name="assunto">
        <?php foreach ($assuntosPermitidos as $valor => $rotulo): ?>
          <option value="<?= escaparPainel($valor) ?>" <?= $assunto === $valor ? "selected" : "" ?>><?= escaparPainel($rotulo) ?></option>
        <?php endforeach; ?>
      </select>
      <button type="submit">Aplicar filtro</button>
    </form>

    <?php if ($erroConsulta !== ""): ?>
      <p class="resumo-erros" role="alert"><?= escaparPainel($erroConsulta) ?></p>
    <?php elseif ($mensagens === []): ?>
      <p class="mensagem-sucesso">Nenhuma mensagem encontrada para este filtro.</p>
    <?php else: ?>
      <p role="status"><?= count($mensagens) ?> mensagem(ns) encontrada(s).</p>
      <div class="tabela-responsiva">
        <table class="tabela-mensagens">
          <caption>Mensagens do formulário de contato</caption>
          <thead>
            <tr><th scope="col">Data</th><th scope="col">Contato</th><th scope="col">Assunto</th><th scope="col">Mensagem</th></tr>
          </thead>
          <tbody>
            <?php foreach ($mensagens as $registro): ?>
              <tr>
                <td><?= escaparPainel($registro["criada_em"]) ?></td>
                <td>
                  <strong><?= escaparPainel($registro["nome"]) ?></strong><br>
                  <a href="mailto:<?= escaparPainel($registro["email"]) ?>"><?= escaparPainel($registro["email"]) ?></a>
                  <?php if ($registro["telefone"] !== null): ?><br><?= escaparPainel($registro["telefone"]) ?><?php endif; ?>
                </td>
                <td><?= escaparPainel($assuntosPermitidos[$registro["assunto"]] ?? "Outro") ?></td>
                <td class="texto-mensagem"><?= nl2br(escaparPainel($registro["mensagem"])) ?></td>
              </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    <?php endif; ?>
  </main>
  <footer><p>&copy; 2026 Café Aurora. Projeto educacional fictício.</p></footer>
</body>
</html>
