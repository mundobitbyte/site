import {useState} from "react";
export function App(){
 const [mostrar,setMostrar]=useState(false);
 return <><h1>Café Aurora · Balcão</h1><button type="button" aria-expanded={mostrar} aria-controls="orientacao" onClick={()=>setMostrar(!mostrar)}>Como consultar?</button><div id="orientacao" hidden={!mostrar}><p>O prazo pode mudar. Abrir esta orientação só muda a apresentação; atualizar a consulta pede o aviso atual à cozinha.</p></div></>;
}
