import {initializeApp} from "firebase/app";
import {getFirestore,connectFirestoreEmulator} from "firebase/firestore";
import {modo,configuracao} from "./ambiente.js";
if(modo==="local" && !["localhost","127.0.0.1"].includes(location.hostname))throw new Error("Abra pelo endereço do emulador local.");
export const app=initializeApp(configuracao);
export const banco=getFirestore(app);
if(modo==="local")connectFirestoreEmulator(banco,"127.0.0.1",8080);
