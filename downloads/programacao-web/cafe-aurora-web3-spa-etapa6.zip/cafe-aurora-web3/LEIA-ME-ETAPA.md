# Café Aurora — O balcão ganha caminhos

Referência final da etapa 6, percurso Interface com React.

Compare em outra pasta. Preserve a sua solução, banco, mensagens e credenciais. Não extraia sobre dados de trabalho sem cópia.
O site apresenta as instruções; a aplicação é executada no computador do estudante.

PHP 8.5 e Node 24. Use o terminal Laragon preparado no Windows. Em cliente-balcao, execute npm ci e npm run build. A saída é public/js/balcao/main.js, ausente do ZIP.
Na raiz: php -d opcache.enable=0 -S localhost:8000 -t public. Abra http://localhost:8000/balcao.php.
Preparo PHP na raiz: php src/inicializar-banco.php, php src/inicializar-atendimento.php e php src/inicializar-cardapio.php, um comando por vez.

Alterou PHP: nova consulta. Alterou TypeScript/React: novo build e recarregamento. Configurações de ambiente e servidores só são retomados quando necessário.
Este checkpoint não inclui .env, banco SQLite, credenciais, vendor, node_modules ou JavaScript gerado. Consulte a aula para os testes e resultados esperados.
