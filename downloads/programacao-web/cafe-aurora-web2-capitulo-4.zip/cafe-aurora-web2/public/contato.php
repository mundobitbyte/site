<?php
session_start();

function tamanhoTexto(string $texto): int
{
    if (function_exists("mb_strlen")) {
        return mb_strlen($texto);
    }

    return strlen($texto);
}

function escapar(string $valor): string
{
    return htmlspecialchars($valor, ENT_QUOTES | ENT_SUBSTITUTE, "UTF-8");
}

function textoPost(string $campo): string
{
    $valor = $_POST[$campo] ?? "";
    return is_string($valor) ? trim($valor) : "";
}

$mensagemTemporaria = $_SESSION["mensagem_temporaria"] ?? "";
unset($_SESSION["mensagem_temporaria"]);

$formularioEnviado = ($_SERVER["REQUEST_METHOD"] ?? "GET") === "POST";
$erros = [];
$assuntosPermitidos = [
    "duvida" => "Dúvida",
    "encomenda" => "Encomenda",
    "sugestao" => "Sugestão"
];

$nome = textoPost("nome");
$email = textoPost("email");
$telefone = textoPost("telefone");
$assunto = textoPost("assunto");
$mensagem = textoPost("mensagem");

if ($formularioEnviado) {
    if (tamanhoTexto($nome) < 2) {
        $erros["nome"] = "Informe um nome com pelo menos 2 caracteres.";
    }

    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $erros["email"] = "Informe um endereço de e-mail válido.";
    }

    if (!array_key_exists($assunto, $assuntosPermitidos)) {
        $erros["assunto"] = "Escolha um assunto disponível.";
    }

    $tamanhoMensagem = tamanhoTexto($mensagem);
    if ($tamanhoMensagem < 10 || $tamanhoMensagem > 500) {
        $erros["mensagem"] = "Escreva uma mensagem entre 10 e 500 caracteres.";
    }

    if ($erros === []) {
        $_SESSION["mensagem_temporaria"] = "Mensagem recebida e validada. Nesta demonstração, ela ainda não foi armazenada nem enviada.";
        header("Location: contato.php", true, 303);
        exit;
    }
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="description" content="Veja o endereço, o horário e as formas de contato do Café Aurora.">
  <title>Contato — Café Aurora</title>
  <link rel="stylesheet" href="css/styles.css">
</head>
<body>
  <a class="skip-link" href="#conteudo">Pular para o conteúdo</a>
  <header>
    <p><a href="index.php">Café Aurora</a></p>
    <nav aria-label="Navegação principal">
      <ul>
        <li><a href="index.php">Início</a></li>
        <li><a href="cardapio.php">Cardápio</a></li>
        <li><a href="sobre.html">Sobre</a></li>
        <li><a href="contato.php" aria-current="page">Contato</a></li>
      </ul>
    </nav>
  </header>
  <main id="conteudo" tabindex="-1">
    <h1>Contato e localização</h1>
    <section aria-labelledby="onde">
      <h2 id="onde">Onde estamos</h2>
      <address>
        <p>Rua das Flores, 123 — Centro</p>
        <p>Telefone: <a href="tel:+551100000000">(11) 0000-0000</a></p>
        <p>E-mail: <a href="mailto:contato@cafeaurora.example">contato@cafeaurora.example</a></p>
      </address>
      <figure>
        <img src="img/fachada-cafe.webp" alt="Fachada clara do Café Aurora com porta verde, janelas de madeira, plantas e mesas externas" width="960" height="640" loading="lazy">
        <figcaption>Reconheça nossa entrada pela porta verde.</figcaption>
      </figure>
    </section>
    <section aria-labelledby="horarios">
      <h2 id="horarios">Horário de atendimento</h2>
      <ul>
        <li>Segunda a sexta: das 8h às 19h</li>
        <li>Sábado: das 8h às 18h</li>
        <li>Domingo: fechado</li>
      </ul>
    </section>
    <section aria-labelledby="fale-conosco">
      <h2 id="fale-conosco">Fale conosco</h2>
      <p id="orientacao-formulario">Os campos identificados como obrigatórios devem ser preenchidos. Nesta demonstração, os dados são validados, mas ainda não são armazenados nem enviados por e-mail.</p>

      <?php if ($mensagemTemporaria !== ""): ?>
        <div class="mensagem-sucesso" role="status">
          <strong><?= escapar($mensagemTemporaria) ?></strong>
        </div>
      <?php elseif ($formularioEnviado): ?>
        <div class="resumo-erros" role="alert">
          <strong>Revise os campos indicados:</strong>
          <ul>
            <?php foreach ($erros as $campo => $erro): ?>
              <li><a href="#<?= escapar($campo) ?>"><?= escapar($erro) ?></a></li>
            <?php endforeach; ?>
          </ul>
        </div>
      <?php endif; ?>

      <form class="formulario-grade" action="contato.php" method="post" aria-describedby="orientacao-formulario">
        <fieldset>
          <legend>Seus dados</legend>
          <p>
            <label for="nome">Nome completo (obrigatório)</label><br>
            <input type="text" id="nome" name="nome" value="<?= escapar($nome) ?>" autocomplete="name" minlength="2"<?= isset($erros["nome"]) ? ' aria-invalid="true" aria-describedby="erro-nome"' : "" ?> required>
            <?php if (isset($erros["nome"])): ?>
              <span class="erro-campo" id="erro-nome"><?= escapar($erros["nome"]) ?></span>
            <?php endif; ?>
          </p>
          <p>
            <label for="email">E-mail (obrigatório)</label><br>
            <input type="email" id="email" name="email" value="<?= escapar($email) ?>" autocomplete="email"<?= isset($erros["email"]) ? ' aria-invalid="true" aria-describedby="erro-email"' : "" ?> required>
            <?php if (isset($erros["email"])): ?>
              <span class="erro-campo" id="erro-email"><?= escapar($erros["email"]) ?></span>
            <?php endif; ?>
          </p>
          <p>
            <label for="telefone">Telefone (opcional)</label><br>
            <span id="ajuda-telefone">Inclua o código de área.</span><br>
            <input type="tel" id="telefone" name="telefone" value="<?= escapar($telefone) ?>" autocomplete="tel" aria-describedby="ajuda-telefone">
          </p>
        </fieldset>
        <fieldset>
          <legend>Sua mensagem</legend>
          <p>
            <label for="assunto">Assunto (obrigatório)</label><br>
            <select id="assunto" name="assunto"<?= isset($erros["assunto"]) ? ' aria-invalid="true" aria-describedby="erro-assunto"' : "" ?> required>
              <option value=""<?= $assunto === "" ? " selected" : "" ?> disabled>Selecione uma opção</option>
              <?php foreach ($assuntosPermitidos as $valor => $rotulo): ?>
                <option value="<?= escapar($valor) ?>"<?= $assunto === $valor ? " selected" : "" ?>><?= escapar($rotulo) ?></option>
              <?php endforeach; ?>
            </select>
            <?php if (isset($erros["assunto"])): ?>
              <span class="erro-campo" id="erro-assunto"><?= escapar($erros["assunto"]) ?></span>
            <?php endif; ?>
          </p>
          <p>
            <label for="mensagem">Mensagem (obrigatória)</label><br>
            <span id="ajuda-mensagem">Escreva entre 10 e 500 caracteres.</span><br>
            <textarea id="mensagem" name="mensagem" rows="6" minlength="10" maxlength="500" aria-describedby="ajuda-mensagem contador-mensagem<?= isset($erros["mensagem"]) ? " erro-mensagem" : "" ?>"<?= isset($erros["mensagem"]) ? ' aria-invalid="true"' : "" ?> required><?= escapar($mensagem) ?></textarea>
            <span id="contador-mensagem" class="contador-mensagem">0 de 500 caracteres</span>
            <?php if (isset($erros["mensagem"])): ?>
              <span class="erro-campo" id="erro-mensagem"><?= escapar($erros["mensagem"]) ?></span>
            <?php endif; ?>
          </p>
        </fieldset>
        <button type="submit">Enviar mensagem</button>
      </form>
    </section>
  </main>
  <footer><p>&copy; 2026 Café Aurora. Projeto educacional fictício.</p></footer>
  <script src="js/script.js" defer></script>
</body>
</html>
