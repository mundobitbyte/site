"""Testes da Central Horizonte."""
